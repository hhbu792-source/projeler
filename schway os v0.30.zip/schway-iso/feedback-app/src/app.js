const { invoke } = window.__TAURI__.core;
const $ = id => document.getElementById(id);
const f = $('f'), msg = $('msg');
const DESC = { bug: 'Çalışmayan ya da bozuk bir şey.', oneri: 'Olmasını istediğin bir şey.', elestiri: 'Beğenmediğin ya da değişmesi gereken bir şey.' };
f.addEventListener('change', e => { if (e.target.name === 'category') $('cdesc').textContent = DESC[e.target.value]; });

invoke('get_config').then(c => {
  $('srv').value = c.serverUrl;
  $('sys').textContent = 'Gönderilecek: ' + c.system + ' · uygulama ' + c.version;
});

$('gear').onclick = () => {
  const showCfg = $('cfg').hidden;
  $('cfg').hidden = !showCfg; f.hidden = showCfg;
  $('gear').textContent = showCfg ? 'Geri' : 'Ayar';
};
$('save').onclick = async () => {
  try { await invoke('set_server', { url: $('srv').value }); $('cmsg').className = 'ok'; $('cmsg').textContent = 'Kaydedildi.'; }
  catch (e) { $('cmsg').className = 'err'; $('cmsg').textContent = String(e); }
};
f.addEventListener('submit', async e => {
  e.preventDefault();
  const d = new FormData(f);
  msg.className = ''; msg.textContent = 'Gönderiliyor…';
  try {
    await invoke('send_feedback', { category: d.get('category'), message: d.get('message'), contact: d.get('contact') || '' });
    f.reset(); $('cdesc').textContent = DESC.bug; msg.className = 'ok'; msg.textContent = 'Teşekkürler, iletildi.';
  } catch (err) { msg.className = 'err'; msg.textContent = String(err); }
});
