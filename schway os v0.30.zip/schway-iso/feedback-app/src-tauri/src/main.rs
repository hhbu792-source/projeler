#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde_json::{json, Value};
use std::{fs, path::{Path, PathBuf}, time::Duration};
use tauri::{AppHandle, Manager};

const DEFAULT_URL: &str = "http://localhost:3000";
const SYSTEM_CFG: &str = "/etc/schway/feedback.json";

fn read_url(p: &Path) -> Option<String> {
    let v: Value = serde_json::from_str(&fs::read_to_string(p).ok()?).ok()?;
    v.get("serverUrl")?.as_str().map(String::from)
}

fn user_cfg(app: &AppHandle) -> Option<PathBuf> {
    app.path().app_config_dir().ok().map(|d| d.join("ayarlar.json"))
}

// Öncelik: kullanıcı ayarı > /etc/schway/feedback.json > localhost
fn server_url(app: &AppHandle) -> String {
    user_cfg(app)
        .and_then(|p| read_url(&p))
        .or_else(|| read_url(Path::new(SYSTEM_CFG)))
        .unwrap_or_else(|| DEFAULT_URL.to_string())
}

fn system_info() -> String {
    if let Ok(s) = fs::read_to_string("/etc/os-release") {
        for line in s.lines() {
            if let Some(v) = line.strip_prefix("PRETTY_NAME=") {
                return v.trim_matches('"').to_string();
            }
        }
    }
    "Linux".to_string()
}

#[tauri::command]
fn get_config(app: AppHandle) -> Value {
    json!({
        "serverUrl": server_url(&app),
        "system": system_info(),
        "version": env!("CARGO_PKG_VERSION")
    })
}

#[tauri::command]
fn set_server(app: AppHandle, url: String) -> Result<(), String> {
    let u = url.trim().trim_end_matches('/').to_string();
    if !(u.starts_with("http://") || u.starts_with("https://")) || u.len() < 9 {
        return Err("Adres http:// veya https:// ile başlamalı.".to_string());
    }
    let p = user_cfg(&app).ok_or_else(|| "Ayar klasörü bulunamadı.".to_string())?;
    if let Some(dir) = p.parent() {
        fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    fs::write(p, json!({ "serverUrl": u }).to_string()).map_err(|e| e.to_string())
}

#[tauri::command]
async fn send_feedback(app: AppHandle, category: String, message: String, contact: String) -> Result<(), String> {
    let url = format!("{}/api/feedback", server_url(&app));
    let body = json!({
        "category": category,
        "message": message,
        "contact": contact,
        "source": "app",
        "version": env!("CARGO_PKG_VERSION"),
        "system": system_info()
    });
    tauri::async_runtime::spawn_blocking(move || {
        let agent = ureq::AgentBuilder::new().timeout(Duration::from_secs(10)).build();
        match agent.post(&url).send_json(body) {
            Ok(_) => Ok(()),
            Err(ureq::Error::Status(code, resp)) => {
                let msg = resp
                    .into_json::<Value>()
                    .ok()
                    .and_then(|v| v.get("error").and_then(|e| e.as_str()).map(String::from));
                Err(msg.unwrap_or_else(|| format!("Sunucu hata döndürdü ({}).", code)))
            }
            Err(_) => Err("Sunucuya ulaşılamadı. Ayarlardan adresi kontrol edin.".to_string()),
        }
    })
    .await
    .map_err(|e| e.to_string())?
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![get_config, set_server, send_feedback])
        .run(tauri::generate_context!())
        .expect("Geri Bildirim uygulaması başlatılamadı");
}
