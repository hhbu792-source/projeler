# Schway Geri Bildirim (Tauri)

Tauri 2 + düz HTML/JS. Electron'a göre çok küçüktür (sistemin WebKitGTK'sını kullanır).

Geliştirme (Arch): `sudo pacman -S rust webkit2gtk-4.1 gtk3 base-devel`, sonra

    cd src-tauri && cargo run          # geliştirme
    cd src-tauri && cargo build --release --features custom-protocol

ISO için paket: `repo/schway-feedback/PKGBUILD` (`build-extras.sh` derleyip yerel depoya koyar).
İlk açılışta Ayar düğmesinden merkez sunucu adresini girin ya da `/etc/schway/feedback.json` içine yazın.
