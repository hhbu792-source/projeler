// İndirme düğmesi şimdilik çalışmıyor; yalnızca bilgi satırını gösterir.
document.getElementById('dl').addEventListener('click', function () {
  document.getElementById('dl-note').hidden = false;
});
