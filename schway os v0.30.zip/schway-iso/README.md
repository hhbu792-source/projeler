# Schway OS

Arch tabanlı, hafif (düşük RAM), oyun için hızlı (Zen kernel, otomatik oyun modu), Windows uygulamalarını
çalıştırabilen (Wine/Proton), kendi koyu arayüzü (Quickshell) olan bir Linux dağıtımı.

## Hızlı başlangıç (Arch kurmadan, GitHub ile)
1. Bu klasörü GitHub'a yükle (`master` dalı hazır):
   `git remote add origin https://github.com/KULLANICI/DEPO.git` ve `git push -u origin master`
2. Depodaki **Actions** sekmesinde "Build Schway ISO" çalışır (ilk seferde ~20-40 dk; Calamares AUR'dan derlenir).
3. Bitince `schway-iso` çıktısından ISO'yu indir, Ventoy USB'ye kopyala, USB'den aç.
4. Hata olursa özet sayfasındaki son 80 satırı (ya da `build-log`) paylaş.
Yerelde derlemek için (Arch'ta): `bash build-calamares.sh` (Bibata imleci de derler) sonra `sudo bash build-iso.sh --lite`.

## Açılışta
Canlı ISO'da karşılama ekranı kendiliğinden açılır: gelişmiş oyun modu, zapret ve paket setlerini (oyun/Wine, ofis, sunucu, ek uygulamalar) seçebilir, diskleri görüp GParted ile bölümleyip kurulumu başlatabilir ya da canlı denemeye devam edebilirsin (seçimler kurulan sisteme aktarılır). Parolasız otomatik giriş (kullanıcı `schway`), Hyprland, üst şerit, dock (Geri Bildirim dahil), masaüstü simgeleri. Ses ve parlaklık tuşlarında ekranda gösterge (OSD) çıkar. Uygulama/servis
otomatik başlatması yok (ağ, earlyoom, saat eşitleme hariç). Canlı ortamda panelde "Schway'i Kur" düğmesi çıkar. Uygulama panelinde "Geri Bildirim" ile hata/öneri/eleştiri gönderilebilir.

## Kısayollar
Super+D / Super+Space uygulama paneli, Super+A hızlı ayarlar, Super+W karşılama, Super+I ayarlar, Super+S güvenlik (antivirüs), Super+L ekranı kilitle, Super+G oyun modu, Super+F1 geri bildirim,
Super+Enter terminal, Super+E dosyalar (Schway Dosyalar; yedek: Super+Alt+E Thunar), Ctrl+Shift+Esc görev yöneticisi, Super+B Firefox, Super+Q kapat, Super+F tam ekran, Print ekran görüntüsü.

## Komutlar
| Komut | Ne yapar |
|---|---|
| `schway-install` | Calamares kurulum aracı (canlı ortamda) |
| `schway-drivers [--detect]` | Ekran kartı / Wi-Fi / Bluetooth sürücüleri |
| `schway-server start\|stop\|status` | ssh, docker, nginx, postgresql |
| `sudo schway-dpi-setup` | zapret (Türksat Kablonet hazır ayarı, otomatik test) |
| `schway-game on\|off\|toggle` | Oyun modu (Steam/Wine oyunlarında kendiliğinden) |
| `schway-game advanced on\|off\|status` | Gelişmiş oyun modu (oyun modundayken CPU performance) |
| `schway-partition` | GParted ile disk bölümleme (canlı ortamda) |
| `schway-sets list\|install <set>` | Paket setleri: gaming, office, server, apps |
| `schway-settings ...` | Ayarlar uygulamasının arka ucu (Super+I) |
| `schway-disks` | Disk ve bölüm listesi (karşılama ekranı kullanır) |
| `schway-theme accent <renk>` | Vurgu rengi (GTK, Qt, terminal, panel) |
| `schway-snapshot create\|list\|rollback` | btrfs anlık görüntüleri (pacman öncesi otomatik, GRUB menüsünden de açılır) |
| `schway-update [--configs\|set-repo URL]` | Güncelleme |
| `schway-apps install all` | Spotify, Prism (Minecraft), Bottles, ProtonUp-Qt |
| `schway-winfonts` | Kendi Windows bölümünden yazı tipleri |
| `schway-ram` | Bellek özeti (hedef: boşta < 600 MB) |
| `schway-defender ...` | Virüs ve tehdit koruması (ClamAV): `status`, `scan quick\|full\|custom <yol>`, `cancel`, `update`, `realtime on\|off`, `threats`, `quarantine list\|restore\|delete\|clear`, `history`, `exclude`, `config` |
| `schway-harden on\|off\|status` | Sudo parolası (parola belirler, kurcalama koruması) |
| `schway-feedback` | Geri Bildirim uygulaması (Tauri; adres: `/etc/schway/feedback.json`) |
| `schway-store` | Mağaza: Flathub'da ara, kur, kaldır, güncelle (`gui` ile pencere) |
| `schway-lock` | Ekranı kilitler (parola belirlenmemişse kilitlemez) |
| `schway-debug` | Hata raporu (~/schway-debug.txt) |

## Schway Güvenlik (antivirüs)
Windows Güvenlik tarzı, ClamAV tabanlı koruma; sisteme üç yerden gömülü: **uygulama** (Super+S, uygulama panelinde ve dock'ta
"Schway Güvenlik": ana sayfa, hızlı/tam/özel tarama ve canlı ilerleme, etkin tehditler, karantina, geçmiş, ayarlar, güvenlik duvarı),
**ayarlar** (Ayarlar > Virüs ve Tehdit Koruması, hızlı ayarlarda "Güvenlik" karosu) ve **sistem** (üst şeritte yalnızca dikkat gerekince
çıkan kalkan simgesi, bildirimler, `schway-defender` komutu, systemd hizmetleri).
- Gerçek zamanlı koruma: `schway-defender-rt.service` (clamd + clamonacc). İndirilenler, Masaüstü, Belgeler, /tmp ve /var/tmp izlenir;
  Steam/Wine/oyun klasörleri bilerek dışarıda. Açıkken ~1 GB RAM yer, bu yüzden ilk girişte yalnızca RAM >= 7 GB ise kendiliğinden açılır.
- Zamanlanmış tarama: `schway-defender-scan.timer` (günlük denetler, Ayarlar'daki sıklığa göre hızlı/tam tarar; oyun modunda ertelenir).
- Tanımlar: derleme sırasında ISO'ya gömülür (+~300 MB, internetsiz de çalışır; `SCHWAY_NO_DEFS=1 sudo bash build-iso.sh` ile atlanır, derleyen makinede `clamav` kurulur). Kurulu sistemde `clamav-freshclam.service` günceller; canlı ISO'da RAM dolmasın diye güncelleme kapalı.
- Thunar'da dosya/klasöre sağ tık > "Schway Güvenlik ile tara"; takılan USB/harici disk bağlanınca otomatik taranır (udiskie kancası, Ayarlar'dan kapatılır); tehdit bildirimine tıklayınca uygulama açılır.
- Karantina `/var/lib/schway-defender/quarantine` (kök-only, geri alınabilir). Ayar `/etc/schway/defender.conf`, dışlamalar `/etc/schway/defender.exclude`.

## Dosyalar (Super+E) ve Görev Yöneticisi (Ctrl+Shift+Esc)
İkisi de ayrı bir Quickshell sürecidir (`schway-files gui`, `schway-tasks gui`): bir hata masaüstü kabuğunu etkilemez. Arka uçları `schway-files` ve `schway-tasks` (Python) komut satırından da çalışır.

**Dosyalar:** yerler (ev, klasörler, takılı diskler, çöp), adres çubuğu (tıkla ya da Ctrl+L), arama (alt klasörlerde), sıralama, Ctrl/Shift ile çoklu seçim, kes/kopyala/yapıştır, yeniden adlandır (F2), yeni klasör/dosya, çöp kutusu (FreeDesktop biçimi: geri yükle, boşalt), gizli dosyalar (Ctrl+H), kalıcı sil (Shift+Delete, onaylı). Var olan dosyanın üzerine yazmaz (`ad (2)`). Ev klasörü, Belgeler/İndirilenler gibi ana klasörler, `/` ve ev dışındaki sistem dosyaları değiştirilemez. **Çöp kutusu:** ev için `~/.local/share/Trash`, takılı diskler (USB vb.) için diskin kendi `.Trash-UID` klasörü (FreeDesktop biçimi; disk çıkarılınca çöpü de onunla gider); Çöp Kutusu görünümü hepsini birleşik gösterir. **Sağ tık menüsü** (satır ya da boş alan), **önizleme paneli** (Boşluk ya da araç çubuğu: metin, resim, klasör, bilgi), **sürükle-bırak** (klasör satırına ya da kenar çubuğundaki yere bırak = taşı, Ctrl ile bırak = kopyala, Çöp Kutusu'na bırak = çöpe at). **Varsayılan klasör uygulaması:** yeni kullanıcılar için klasörler Schway Dosyalar ile açılır (`mimeapps.list`); Dosyalar açılamazsa (qs yok, tema yok ya da açılışta çökerse) `schway-files` kendiliğinden Thunar'a geçer, Thunar paketi kurulu kalır (Super+Alt+E). Dock'taki pin Thunar yerine Dosyalar'dır; bağımsız Quickshell pencereleri `org.quickshell` app_id'si bildirdiği için dock pencereleri başlığa göre de eşler. **Sınırlar:** takılı disk çöpü yalnızca `/proc/self/mountinfo`'da görünen ve `/run/media`, `/media`, `/mnt` altındaki bağlama noktaları içindir; önizleme PDF/video içeriğini göstermez (yalnızca bilgi); sürükle-bırak yalnızca pencere içindedir (başka uygulamaya sürükleme yok); mevcut kullanıcıların `mimeapps.list` dosyası değiştirilmez (`xdg-mime default schway-files.desktop inode/directory`).

**Görev Yöneticisi:** *İşlemler* (anlık işlemci/bellek, arama, sıralama; yalnızca senin işlemlerin ya da tümü; sonlandır/zorla kapat; sistem için kritik işlemler ek onay ister, PID 1 ve çekirdek iş parçacıkları kapatılamaz), *Performans* (işlemci, bellek, takas grafikleri), *Hizmetler* (çalışan/açılışta başlayan hizmetler, bellek kullanımı, başlat/durdur ve "açılışta başlasın" anahtarı). Hizmet değiştirmek yönetici onayı (parola) ister; `services.policy`'deki zorunlu hizmetler (NetworkManager, dbus, systemd-*, polkit...) arka uçta da kilitlidir.

## Açılışta yalnızca gerekenler (hizmet politikası)
Tek kaynak: `airootfs/usr/share/schway/services.policy`. `build-iso.sh` bu dosyadaki `remove` satırlarını uygular ve politikada olmayan etkin hizmet kalırsa derlemede uyarır (`SCHWAY_STRICT_SERVICES=1` ile derlemeyi durdurur). Açılışta çalışanlar: NetworkManager, systemd-resolved, systemd-timesyncd, earlyoom, Schway ilk açılış/sürücü/güvenlik varsayılanları. Kaldırılanlar (Arch `releng` profilinden geliyordu, gerçek profil dosyalarıyla doğrulandı): **sshd** (releng `PermitRootLogin yes` + parola girişiyle açıyordu ve kurulu sisteme de kopyalanıyordu; artık kapalı gelir, `sudo schway-server` ile açılınca kök girişi kapalıdır), ModemManager (NetworkManager gerekirse kendisi başlatır), pcscd, systemd-time-wait-sync, cloud-init paketi, iwd, reflector, systemd-networkd. Docker/nginx/PostgreSQL/Bluetooth/UFW/Schway Güvenlik ek korumaları varsayılan kapalıdır ya da donanıma/isteğe göre açılır. Sanal makine konuk araçları yalnızca ilgili sanallaştırmada çalışır (gerçek donanımda hiç başlamaz).

## Arayüzü görmek / test etmek (geliştirici)
Gerçek Quickshell/Hyprland olmadan arayüzü çizmek için: `pip install PySide6-Essentials`, ardından `python3 tests/qml/shots/run_shots.py airootfs/etc/skel/.config/quickshell busy 0,2,4 /tmp/shots Security`; Görev Yöneticisi ve Dosyalar için `python3 tests/qml/shots/render_apps.py /tmp/shots`; arayüz komutlarının gerçek arka uçta çalıştığını denetleyen sözleşme testi: `python3 tests/qml/shots/contract_apps.py` (senaryolar: `ok`, `busy`, `threat`; ikinci uygulama için son argüman `Settings`, sayfa `9`). Duvar kâğıdı/bulanıklık çizilmez; yalnızca yerleşim, metin ve renk içindir. Yazı tipleri için IBM Plex ve Symbols Nerd Font kurulu olmalı.

## Fidye yazılımı koruması (erken uyarı)
`schway-defender-ransom.service` (RAM şartı yok, `MemoryMax=64M`; ilk girişte açılır, Ayarlar > Virüs ve Tehdit Koruması'ndan kapatılır). Belgeler, Masaüstü ve Resimler'e kullanıcıya ait gizli tuzak dosya (`.~schway-canary.docx`) koyar ve izler:
- tuzak dosya değişir ya da silinirse uyarı verir (dosya onarılır),
- 10 sn içinde 40'tan çok dosya değişirse, 5 ya da daha çok şüpheli uzantılı (`.locked`, `.encrypted`, `.wncry`...) dosya çıkarsa ya da 2 fidye notu adlı dosya (`*decrypt*`...) çıkarsa uyarı verir.
- Uyarı bildirim, Geçmiş kaydı (`ransom`) ve üst şeritteki/ana sayfadaki "Dikkat gerekiyor" durumu olarak görünür (24 saat). `schway-defender ransom status|plant|check`.
- **Sınır:** engellemez ve hangi programın yaptığını bilmez; yalnızca erken uyarıdır. Kendi toplu işlemlerin (büyük bir klasörü taşımak/kopyalamak) yanlış alarm verebilir; eşik `SD_RANSOM_MAX` ile değişir. Gerçek ISO'da denenmedi (olay izleme `inotifywait` ile testlerde denendi).

## Antivirüs: ek özellikler
- **İzin ver:** Etkin tehdit satırında "İzin ver" aynı içerikli dosyayı (SHA-256) bir daha uyarmaz; dosya değişirse yeniden taranır. Liste Koruma ayarları'nda, `schway-defender allowed list|remove`. Parola ister.
- **Tarama saati:** Koruma ayarları'ndan seçilir (systemd zamanlayıcısına yazılır).
- **Sistem dosyası bütünlüğü:** `pacman -Qkk` ile paket dosyalarının içerik/boyut değişimi ve eksik dosya denetimi (`schway-defender integrity`). /etc, /var, /home, önbellek ve .pyc gürültüsü ayıklanır. Schway paket dosyalarının üstüne kendi dosyalarını koyduğu için bazı satırlar beklenen olabilir.
- **YARA ve ek imza kaynakları:** ClamAV `/var/lib/clamav` içindeki `.yar` dosyalarını yükler; `schway-rules.yar` (8 tutucu kural: ters kabuk, webshell, madenci, fidye notu, cron indirici, PowerShell indirici, mimikatz; gerçek ClamAV motorunda örneklerle denendi) ile gelir, kendi kuralını oraya koyabilirsin. Ek imza kaynağı: `schway-defender sources add <https-adres>` (freshclam DatabaseCustomURL; yalnızca güvendiğin kaynakları ekle, adresleri sağlayıcının belgesinden doğrula).
- **Web koruması:** `schway-defender web on|off|status|update|add|remove|allow|unallow|list|check [alan]`. Bilinen zararlı alan adlarını (abuse.ch URLhaus, CC0) `/etc/hosts` içindeki yönetilen blokta `0.0.0.0`/`::` adresine yönlendirir; tüm uygulamalar için geçerli, günlük zamanlayıcıyla güncellenir, kendi hosts satırlarına dokunmaz. Elle engelleme/izin listeleri: `/etc/schway/web.block`, `/etc/schway/web.allow`. **Sınır:** alan adı bazlı; IP ile bağlanmayı, joker alt alan adlarını ve tarayıcının kendi DNS-over-HTTPS'ini engellemez, sayfa içeriğini taramaz. Varsayılan açık.
- **Çalıştırma öncesi engelleme:** `sudo schway-defender prevent on|off|status` (varsayılan **kapalı**). `schway-execguard` (Python, fanotify `FAN_OPEN_EXEC_PERM`) home, /tmp, /var/tmp, /dev/shm, USB (/run/media, /media, /mnt) altından çalıştırılan dosyayı çalışmadan önce clamd ile tarar; tehdit varsa çalıştırma reddedilir ("Operation not permitted"), dosya karantinaya alınır ve bildirim gelir. Sistem klasörleri taranmaz; Steam/Wine/Flatpak klasörleri ve dışlama listesi atlanır; oyun modunda durur; tarama sonucu önbelleğe alınır. **Güvenli hata davranışı:** clamd yok/hata/zaman aşımı/kuyruk dolu/servis çöktü ya da durdu → çalıştırmaya izin verilir (çekirdek bekleyenleri kendisi serbest bırakır). Açınca gerçek zamanlı korumayı (clamd, ~1 GB RAM) da açar. Çekirdek testleri gerçek fanotify ile geçti; **gerçek ISO/donanımda, çok sayıda bağlama noktasıyla (Btrfs alt birimleri, USB) ve ağır iş yükünde (derleme, oyun) denenmedi**, bu yüzden varsayılan kapalı.
- **Sudo ile aç/kapa:** `sudo schway-defender ransom on|off`, `web on|off`, `prevent on|off`. Kapatma ve ayar komutları parola ister (sudoers'ta parolasız olan tek ekleme `web update`).

## Kurulum otomatik başlar
ISO açılınca canlı oturum otomatik giriş yapar, karşılama menüsü açılır (kurulum seçimleri: ek uygulamalar, zapret, oyun modu). Menü kapanınca
("Kurulumu başlat" ya da kapatma/Esc) Calamares kendiliğinden başlar; bir açılışta bir kez. Canlı sistemi yalnızca denemek için açılış satırına
`schway.noauto` ekle. Karşılama menüsünü atlayıp doğrudan kuruluma geçmek için açılış satırına `schway.direct` ekle (kurulum seçimleri varsayılan kalır). Parola kurulumdan sonraki ilk girişte bir pencereyle belirlenir. Gerçek ISO'da denenmedi.

## Sudo parolası (kurcalama koruması)
Parolasız sudo, kötü amaçlı bir programın antivirüsü sessizce kapatmasına izin verirdi. Kurulu sistemde ilk girişte bir kez parola belirletilir
(parola penceresi / `schway-harden on`; sonradan Ayarlar > Kullanıcılar ve Hesaplar'dan açılıp kapatılır) ve sudo parola ister. Canlı ISO'da kapalıdır (hesabın parolası yok).
- Parolasız kalanlar (dar liste, `/usr/share/schway/sudoers-installed`): tarama başlatma, virüs tanımı güncelleme, algılanan tehdidi karantinaya alma, oyun modunda CPU yöneticisi.
- Parola isteyenler: antivirüsü kapatma/ayar/dışlama, taramayı iptal, karantinadan silme/geri yükleme, güvenlik duvarı, saat dilimi, kapak eylemi, anlık görüntü, sunucu servisleri, genel `sudo`.
- Grafik oturumda parola pencereyi hyprpolkitagent açar (birkaç dakika hatırlar); terminalde sudo kendi istemini gösterir.
- Ayarlar'ın yönetici işlemleri serbest komut çalıştırmaz: `schway-priv` her fiilin argümanını doğrular.
- Sınır: kullanıcı hesabı altında çalışan bir program sahte parola penceresi gösterip seni kandırabilir; bu koruma onu engellemez.

## Web ve geri bildirim
`site/` tanıtım sitesi (statik, indirme düğmesi şimdilik kapalı), `feedback-center/` geri bildirim merkezi (Node.js; `/admin` IP listesine ek olarak yönetici anahtarı ister, ayrıntı `feedback-center/README.md`), `feedback-app/` Geri Bildirim uygulaması (Tauri 2). ISO'ya `repo/schway-feedback/PKGBUILD` ile paketlenip girer (`build-extras.sh` derler); derlenemezse ISO uygulamasız hazırlanır.

## Testler
`bash tests/run.sh` (Node 18+, isteğe bağlı shellcheck): bash söz dizimi, shellcheck, JSON, paket listeleri, systemd birimleri, Hyprland kısayolu/IPC/komut tutarlılığı, QML parantez dengesi, .desktop ve README komut tablosu, Calamares kancaları (LUKS dahil), boşta kalma/kilit yapılandırması, `schway-lock` kapısı ve geri bildirim sunucusu. GitHub'da her push'ta `Test` iş akışı çalışır. Bunlar gerçek ISO'nun yerini tutmaz; derleme ve donanım denemesi ayrıca gerekir.

## Klasörler
`airootfs/` ISO'ya giren dosyalar (ayarlar `etc/skel`, araçlar `usr/local/bin`), `packages.extra` / `packages.full`
paket listeleri, `build-iso.sh` / `build-calamares.sh` derleme, `repo/` kendi paket deposu, `ci/` ve `.github/` otomasyon.

## Bilinen sınırlar (dürüst liste)
- Schway Güvenlik (antivirüs) gerçek ISO'da denenmedi: arka uç (`schway-defender`) ClamAV ile test dosyası (EICAR benzeri imza) üzerinde sınandı,
  QML arayüzü Quickshell'de çalıştırılıp görülmedi. ClamAV imza tabanlıdır; bilinmeyen/yeni zararlıları, fidyeyazılımın davranışını ya da
  tarayıcı korumasını yakalamaz. USB otomatik taraması ve Thunar sağ tık menüsü de gerçek makinede denenmedi (komut tarafı test edildi). Gerçek zamanlı koruma engellemez, yalnızca algılar ve karantinaya alır (dosya kısa süre erişilebilir olabilir).
- Henüz gerçek bir ISO derlenip donanımda denenmedi; ilk derlemede hata çıkması beklenir.
- Plymouth, anlık görüntüden önyükleme (grub-btrfs) ve Bibata imleci eklendi ama gerçek donanımda denenmedi.
  Plymouth yalnızca kurulu sistemde çalışır (canlı ISO'da yok). Bibata AUR'dan derlenir; derlenemezse Adwaita kalır.
- Qt5 koyu teması (`qt5ct` + Fusion, Qt6 ile aynı palet ve vurgu rengi) eklendi ama gerçek donanımda denenmedi.
- Tauri'ye yalnızca Geri Bildirim uygulaması geçti (derlenip denenmedi). Ayarlar, karşılama vb. hâlâ Quickshell/QML; Monitör, Mağaza yok. Tanıtım sitesi (`site/`) var ama indirme düğmesi bilerek kapalı.
- Geri Bildirim uygulaması (Tauri) ve merkez sunucusu gerçek ISO'da denenmedi. Tauri sistemin WebKitGTK'sını kullanır, ek yükü küçüktür.
- `/etc/schway/feedback.json` içindeki merkez adresi yer tutucudur (`localhost:3000`); yayına alınca gerçek adres yazılmalı.
- Geri bildirim merkezi kendisi HTTPS konuşmaz: yönetici anahtarı ve IP listesi vardır ama internete açılacaksa mutlaka ters vekil (Nginx + HTTPS) arkasına konmalıdır (`feedback-center/nginx.conf.example`).
- Şifreli disk (LUKS), kilit ekranı (hyprlock), kurulumdaki kullanıcı sayfası ve Mağaza gerçek donanımda/ISO'da denenmedi (kancalar ve betikler sahte dosyalarla, Mağaza arayüzü sahte Quickshell ile sınandı). Canlı oturumda hesap `schway` ve otomatik giriş açıktır (bilerek); kurulu sistemde kullanıcı kurulumda seçilir.
- Güvenlik duvarı varsayılan olarak gelen bağlantıları reddeder: KDE Connect, LocalSend, Steam Uzaktan Oynatma, torrent gelen portu gibi şeyler için kural eklemek gerekir (`sudo ufw allow <port>`). Docker, kendi kurallarıyla güvenlik duvarını atlayabilir.
- İndirme koruması yalnızca İndirilenler klasörünü ve riskli dosya türlerini bekletir; tüm sistemi engellemez (fanotify engelleme hâlâ yok). Torrent gibi dosyayı sürekli açan istemcilerin içeriği riskli türdeyse bekletme onları aksatabilir; `schway-defender exclude` ile dışlanır.
- Mağaza yalnızca Flathub (Flatpak) uygulamalarını gösterir; sistem paketleri (pacman) ve Arch AUR için ayrı arayüz yok. Kurulu sistemde ilk girişte bir parola belirlenir ve sudo parola ister (aşağıda *Sudo parolası*); canlı ISO parolasız kalır.
