#!/bin/bash
# Schway ISO derleme (Arch Linux üzerinde, root ile):
#   sudo bash build-iso.sh          -> tam ISO (Wine, Steam, LibreOffice dahil, ~4.5 GB)
#   sudo bash build-iso.sh --lite   -> bunlar hariç (~2.5 GB)
set -e
[ "$EUID" -eq 0 ] || { echo "root ile çalıştır: sudo bash build-iso.sh"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)
LITE=0; [ "$1" = "--lite" ] && LITE=1

pacman -S --needed --noconfirm archiso
WORK="$HERE/work"; PROFILE="$WORK/profile"
rm -rf "$WORK"; mkdir -p "$WORK"
: > "$WORK/ours.txt"
cp -r /usr/share/archiso/configs/releng "$PROFILE"
sed -i '/^CheckSpace/d' "$PROFILE/pacman.conf"

# --- Zen kernel: linux yerine linux-zen ---
# (kernel modülü getiren paketleri de çıkar, yoksa linux geri gelir)
sed -i '/^linux$/d; /^broadcom-wl$/d; /^virtualbox-guest-utils-nox$/d' "$PROFILE/packages.x86_64"
echo "linux-zen" >> "$PROFILE/packages.x86_64"
PRE="$PROFILE/airootfs/etc/mkinitcpio.d"
mv "$PRE/linux.preset" "$PRE/linux-zen.preset"
sed -i 's/vmlinuz-linux/vmlinuz-linux-zen/g; s/initramfs-linux/initramfs-linux-zen/g' "$PRE/linux-zen.preset"
grep -rlE 'vmlinuz-linux|initramfs-linux' "$PROFILE/syslinux" "$PROFILE/grub" "$PROFILE/efiboot" 2>/dev/null \
    | xargs -r sed -i 's/vmlinuz-linux/vmlinuz-linux-zen/g; s/initramfs-linux\.img/initramfs-linux-zen.img/g'

# --- Paketler ---
grep -v '^#' "$HERE/packages.extra" | grep -v '^$' | tee -a "$WORK/ours.txt" >> "$PROFILE/packages.x86_64"
if [ "$LITE" = "0" ]; then
    sed -i '/^#\[multilib\]/,/^#Include/ s/^#//' "$PROFILE/pacman.conf"
    grep -v '^#' "$HERE/packages.full" | grep -v '^$' | tee -a "$WORK/ours.txt" >> "$PROFILE/packages.x86_64"
fi

# --- Calamares (yerel depodan) ---
if [ -f "$HERE/localrepo/schway-local.db.tar.gz" ]; then
    cat >> "$PROFILE/pacman.conf" << EOT

[schway-local]
SigLevel = Optional TrustAll
Server = file://$HERE/localrepo
EOT
    printf "calamares\nckbcomp\n" | tee -a "$WORK/ours.txt" >> "$PROFILE/packages.x86_64"
    if ls "$HERE"/localrepo/bibata-cursor-theme-bin-*.pkg.tar.* >/dev/null 2>&1; then
        echo "bibata-cursor-theme-bin" | tee -a "$WORK/ours.txt" >> "$PROFILE/packages.x86_64"
    fi
    if ls "$HERE"/localrepo/schway-feedback-*.pkg.tar.* >/dev/null 2>&1; then
        echo "schway-feedback" | tee -a "$WORK/ours.txt" >> "$PROFILE/packages.x86_64"
    fi
else
    echo "UYARI: localrepo yok, kurulum aracı (Calamares) ISO'ya EKLENMEYECEK."
    echo "       Önce normal kullanıcıyla: bash build-calamares.sh"
fi

# --- Bizim eklediğimiz paketlerden depoda olmayanları ele (tek paket tüm derlemeyi bozmasın) ---
DBP="$WORK/db"; mkdir -p "$DBP/sync" "$DBP/local"
PC="pacman --config $PROFILE/pacman.conf --dbpath $DBP"
: > "$WORK/missing.txt"
if $PC -Sy >/dev/null 2>&1; then
    while read -r p; do
        [ -z "$p" ] && continue
        if ! $PC -Si "$p" >/dev/null 2>&1; then
            echo "UYARI: depoda bulunamadi, ISO'dan cikarildi: $p"
            echo "$p" >> "$WORK/missing.txt"
            grep -vxF "$p" "$PROFILE/packages.x86_64" > "$WORK/pk.tmp" && mv "$WORK/pk.tmp" "$PROFILE/packages.x86_64"
        fi
    done < <(sort -u "$WORK/ours.txt")
else
    echo "UYARI: paket veritabani esitlenemedi, paket denetimi atlandi"
fi

# --- Schway dosyalarını üstüne bindir ---
cp -a "$HERE/airootfs/." "$PROFILE/airootfs/"

# --- ClamAV virüs tanımlarını ISO'ya göm: ilk açılışta internet gerekmeden Schway Güvenlik çalışır (+~300 MB). Atlamak için: SCHWAY_NO_DEFS=1 sudo bash build-iso.sh ---
if [ "${SCHWAY_NO_DEFS:-0}" != 1 ]; then
    pacman -S --needed --noconfirm clamav
    DEFS="$HERE/.clamav-defs"; mkdir -p "$DEFS"       # önbellek: sonraki derlemelerde yalnızca fark iner
    printf 'DatabaseDirectory %s\nDatabaseMirror database.clamav.net\nDatabaseOwner root\n' "$DEFS" > "$WORK/freshclam-build.conf"
    if freshclam --config-file="$WORK/freshclam-build.conf" --datadir="$DEFS" && compgen -G "$DEFS/*.c?d" >/dev/null; then
        mkdir -p "$PROFILE/airootfs/var/lib/clamav"
        cp -a "$DEFS"/*.c?d "$PROFILE/airootfs/var/lib/clamav/"
        echo "Virüs tanımları ISO'ya gömüldü: $(du -sh "$PROFILE/airootfs/var/lib/clamav" | cut -f1)"
    else
        echo "UYARI: virüs tanımları indirilemedi; ISO tanımsız olur, ilk kurulumdan sonra internetle indirilir."
    fi
fi

# --- Geri Bildirim uygulaması (Tauri) derlenemediyse başlatıcısını da çıkar ---
if ! grep -qx 'schway-feedback' "$PROFILE/packages.x86_64"; then
    echo "UYARI: schway-feedback paketi yok, Geri Bildirim uygulaması ISO'ya girmeyecek."
    rm -f "$PROFILE/airootfs/usr/share/applications/schway-feedback.desktop" \
          "$PROFILE/airootfs/usr/share/icons/hicolor/256x256/apps/schway-feedback.png"
fi

# --- Bibata imleci ISO'ya girmediyse (derlenemedi/depoda yok) Adwaita'ya dön ---
if ! grep -qx 'bibata-cursor-theme-bin' "$PROFILE/packages.x86_64"; then
    echo "UYARI: Bibata imleç paketi yok, imleç Adwaita olarak ayarlanıyor."
    grep -rlI 'Bibata-Modern-Ice' "$PROFILE/airootfs/etc/skel" "$PROFILE/airootfs/usr/local/bin" 2>/dev/null \
        | xargs -r sed -i 's/Bibata-Modern-Ice/Adwaita/g'
fi

# --- Varsayılan tema dosyalarını (GTK, Qt, terminal) vurgu rengiyle üret ---
SCHWAY_TPL="$HERE/airootfs/usr/share/schway/theme" HOME="$PROFILE/airootfs/etc/skel" \
    bash "$HERE/airootfs/usr/local/bin/schway-theme" accent blue --build

# --- Servisler: usr/share/schway/services.policy tek kaynaktır (açılışta yalnızca gerekenler çalışır) ---
POLICY="$HERE/airootfs/usr/share/schway/services.policy"
SYSD="$PROFILE/airootfs/etc/systemd/system"
# `remove` satırları: releng'in açtığı, istemediğimiz hizmetleri .wants klasörlerinden sil
while read -r kind unit _; do
    [ "$kind" = remove ] || continue
    find "$SYSD" -path '*.wants/*' -name "$unit" -delete
done < <(grep -vE '^[[:space:]]*(#|$)' "$POLICY")
rm -rf "$SYSD/cloud-init.target.wants"
# `package-remove` satırları: paket listesinden çıkar
while read -r kind pkg _; do
    [ "$kind" = package-remove ] && sed -i "/^$pkg\$/d" "$PROFILE/packages.x86_64"
done < <(grep -vE '^[[:space:]]*(#|$)' "$POLICY")
# releng'in "PermitRootLogin yes / PasswordAuthentication yes" ayarı kurulu sisteme de kopyalanırdı; yerine 10-schway.conf geçerli
rm -f "$PROFILE/airootfs/etc/ssh/sshd_config.d/10-archiso.conf"
W="$PROFILE/airootfs/etc/systemd/system/multi-user.target.wants"
mkdir -p "$W"
for s in NetworkManager earlyoom; do
    ln -sf /usr/lib/systemd/system/$s.service "$W/$s.service"
done
ln -sf /etc/systemd/system/schway-firstboot.service "$W/schway-firstboot.service"
ln -sf /etc/systemd/system/schway-drivers-firstboot.service "$W/schway-drivers-firstboot.service"
# Schway Güvenlik: tanım güncelleyici (kurulu sistemde) ve zamanlanmış tarama denetimi. Gerçek zamanlı koruma RAM'e göre ilk girişte açılır.
ln -sf /usr/lib/systemd/system/clamav-freshclam.service "$W/clamav-freshclam.service"
ln -sf /etc/systemd/system/schway-defender-init.service "$W/schway-defender-init.service"
mkdir -p "$PROFILE/airootfs/etc/systemd/system/timers.target.wants"
ln -sf /etc/systemd/system/schway-defender-scan.timer "$PROFILE/airootfs/etc/systemd/system/timers.target.wants/schway-defender-scan.timer"
# Denetim: politikada olmayan, açılışta etkin hizmet kaldıysa uyar (SCHWAY_STRICT_SERVICES=1 ile derlemeyi durdurur)
UNEXPECTED=$(find "$SYSD" -path '*.wants/*' \( -type l -o -type f \) -printf '%f\n' | sort -u | while read -r u; do
    grep -vE '^[[:space:]]*(#|$)' "$POLICY" | awk '$1=="boot"||$1=="inherit"||$1=="conditional"||$1=="ondemand"||$1=="liveonly"{print $2}' | grep -qxF "$u" || echo "$u"
done)
if [ -n "$UNEXPECTED" ]; then
    echo "UYARI: services.policy'de olmayan etkin hizmetler (karar ver: boot/remove): $(echo $UNEXPECTED)"
    [ "${SCHWAY_STRICT_SERVICES:-0}" = 1 ] && { echo "SCHWAY_STRICT_SERVICES=1: derleme durduruldu."; exit 1; }
fi
# Saat dilimi İstanbul, saat otomatik eşitlenir (timesyncd)
mkdir -p "$PROFILE/airootfs/etc/systemd/system/sysinit.target.wants"
ln -sf /usr/lib/systemd/system/systemd-timesyncd.service "$PROFILE/airootfs/etc/systemd/system/sysinit.target.wants/systemd-timesyncd.service"
ln -sf /usr/share/zoneinfo/Europe/Istanbul "$PROFILE/airootfs/etc/localtime"

# --- Kimlik ve izinler ---
sed -i "s/^iso_name=.*/iso_name=\"schway\"/; s/^iso_label=.*/iso_label=\"SCHWAY_$(date +%Y%m)\"/; s/^iso_publisher=.*/iso_publisher=\"Schway\"/; s/^iso_application=.*/iso_application=\"Schway\"/" "$PROFILE/profiledef.sh"
# Çalıştırma izni: usr/local/bin altındaki HER dosya 755 (listeyi elle tutmak yeni betikleri unutturuyordu:
# schway-settings, schway-sets, schway-disks listede yoktu; Windows'ta git exec bitini de kaybettirir).
PERMS="$WORK/perms.txt"; : > "$PERMS"
for f in "$HERE"/airootfs/usr/local/bin/*; do
    [ -f "$f" ] && printf '  ["/usr/local/bin/%s"]="0:0:755"\n' "$(basename "$f")" >> "$PERMS"
done
printf '  ["/etc/sudoers.d/schway"]="0:0:440"\n' >> "$PERMS"
sed -i "/^file_permissions=(/r $PERMS" "$PROFILE/profiledef.sh"
grep -rl "Arch Linux" "$PROFILE/syslinux" "$PROFILE/grub" "$PROFILE/efiboot" 2>/dev/null | xargs -r sed -i 's/Arch Linux/Schway/g'

mkarchiso -v -w "$WORK/w" -o "$HERE/out" "$PROFILE"
echo
echo "ISO hazır: $HERE/out/"
ls -lh "$HERE/out/"
[ -s "$WORK/missing.txt" ] && { echo; echo "Atlanan paketler:"; cat "$WORK/missing.txt"; }
