'use strict';
// Çalıştır: node --test test.js   (Node 18+, bağımlılık yok)
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sfb-'));
const cfgPath = path.join(dir, 'config.json');
fs.writeFileSync(cfgPath, JSON.stringify({
  port: 0, allowedIps: ['127.0.0.1', '::1', '10.0.0.0/8'], trustProxy: false,
  maxMessageLength: 100, maxReports: 3, rateLimitPerMinute: 1000
}));
process.env.SCHWAY_FB_CONFIG = cfgPath;
process.env.SCHWAY_FB_DATA = path.join(dir, 'data');
process.env.SCHWAY_FB_TOKEN = 'test-token-test-token-test-token';
const { server, ipAllowed } = require('./server.js');

let port;
test.before(() => new Promise(r => server.listen(0, '127.0.0.1', () => { port = server.address().port; r(); })));
test.after(() => { server.close(); fs.rmSync(dir, { recursive: true, force: true }); });

function call(method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? null : (typeof body === 'string' ? body : JSON.stringify(body));
    const req = http.request({ host: '127.0.0.1', port, method, path: p, headers: Object.assign(data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}, headers) }, res => {
      let t = ''; res.on('data', c => t += c); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: t }));
    });
    req.on('error', reject); if (data) req.write(data); req.end();
  });
}
const AUTH = { Authorization: 'Bearer test-token-test-token-test-token' };

test('ipAllowed: tek IP ve CIDR', () => {
  assert.ok(ipAllowed('127.0.0.1'));
  assert.ok(ipAllowed('::ffff:10.1.2.3'));
  assert.ok(!ipAllowed('11.0.0.1'));
});

test('geri bildirim gönderme: geçerli, geçersiz kategori, kısa mesaj, bozuk JSON, dizi gövde', async () => {
  assert.strictEqual((await call('POST', '/api/feedback', { category: 'bug', message: 'Bir hata buldum burada' })).status, 201);
  assert.strictEqual((await call('POST', '/api/feedback', { category: 'x', message: 'Bir hata buldum burada' })).status, 400);
  assert.strictEqual((await call('POST', '/api/feedback', { category: 'bug', message: 'kısa' })).status, 400);
  assert.strictEqual((await call('POST', '/api/feedback', '{bozuk')).status, 400);
  assert.strictEqual((await call('POST', '/api/feedback', '[1,2]')).status, 400);
});

test('yönetim ucu anahtarsız 401, yanlış anahtarla 401, doğru anahtarla 200', async () => {
  assert.strictEqual((await call('GET', '/api/reports')).status, 401);
  assert.strictEqual((await call('GET', '/api/reports', undefined, { Authorization: 'Bearer yanlis' })).status, 401);
  const ok = await call('GET', '/api/reports', undefined, AUTH);
  assert.strictEqual(ok.status, 200);
  assert.ok(JSON.parse(ok.text).reports.length >= 1);
});

test('X-Admin-Token başlığı da kabul edilir', async () => {
  const r = await call('GET', '/api/reports', undefined, { 'X-Admin-Token': 'test-token-test-token-test-token' });
  assert.strictEqual(r.status, 200);
});

test('güvenlik başlıkları var, yönetim ucunda CORS yok', async () => {
  const r = await call('GET', '/api/reports', undefined, AUTH);
  assert.match(r.headers['content-security-policy'], /default-src 'self'/);
  assert.strictEqual(r.headers['x-frame-options'], 'DENY');
  assert.strictEqual(r.headers['access-control-allow-origin'], undefined);
  const f = await call('POST', '/api/feedback', { category: 'oneri', message: 'Güzel bir öneri metni' });
  assert.strictEqual(f.headers['access-control-allow-origin'], '*');
});

test('rapor sayısı maxReports ile sınırlı', async () => {
  for (let i = 0; i < 6; i++) await call('POST', '/api/feedback', { category: 'bug', message: 'Tekrar tekrar mesaj ' + i });
  const { reports } = JSON.parse((await call('GET', '/api/reports', undefined, AUTH)).text);
  assert.strictEqual(reports.length, 3);
});

test('okundu işaretleme ve silme', async () => {
  const { reports } = JSON.parse((await call('GET', '/api/reports', undefined, AUTH)).text);
  const id = reports[0].id;
  assert.strictEqual((await call('POST', '/api/reports/' + id + '/read', '', AUTH)).status, 200);
  assert.strictEqual((await call('DELETE', '/api/reports/' + id, undefined, AUTH)).status, 200);
  assert.strictEqual((await call('DELETE', '/api/reports/' + id, undefined, AUTH)).status, 404);
});

test('statik dosyada yol geçişi (path traversal) engellenir', async () => {
  const r = await call('GET', '/fonts/..%2f..%2fserver.js');
  assert.strictEqual(r.status, 404);
});

test('10 hatalı denemeden sonra 429', async () => {
  let last;
  for (let i = 0; i < 12; i++) last = await call('GET', '/api/reports', undefined, { Authorization: 'Bearer kotu' + i });
  assert.strictEqual(last.status, 429);
  // engel varken doğru anahtar da geçmez (kaba kuvvet koruması)
  assert.strictEqual((await call('GET', '/api/reports', undefined, AUTH)).status, 429);
});
