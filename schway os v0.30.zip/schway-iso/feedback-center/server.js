'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const cfg = JSON.parse(fs.readFileSync(process.env.SCHWAY_FB_CONFIG || path.join(__dirname, 'config.json'), 'utf8'));
const DATA_DIR = process.env.SCHWAY_FB_DATA || path.join(__dirname, 'data');
const MAX_REPORTS = Number(cfg.maxReports) > 0 ? Number(cfg.maxReports) : 5000;
const DB = path.join(DATA_DIR, 'reports.json');
const PUB = path.join(__dirname, 'public');
const CATS = { bug: 'Şikayet / Bug', oneri: 'Öneri', elestiri: 'Eleştiri' };
const SOURCES = ['web', 'app'];

fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });

// ---- yönetici anahtarı: config.adminToken doluysa o, boşsa ilk açılışta üretilip data/admin-token'a yazılır ----
function loadAdminToken() {
  if (process.env.SCHWAY_FB_TOKEN) return process.env.SCHWAY_FB_TOKEN;
  if (cfg.adminToken) return String(cfg.adminToken);
  const f = path.join(DATA_DIR, 'admin-token');
  try { const t = fs.readFileSync(f, 'utf8').trim(); if (t.length >= 24) return t; } catch (_) {}
  const t = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(f, t + '\n', { mode: 0o600 });
  console.log('Yönetici anahtarı üretildi: ' + f);
  return t;
}
const ADMIN_TOKEN = loadAdminToken();
const sha = v => crypto.createHash('sha256').update(String(v)).digest();
function tokenOk(given) {
  if (!given) return false;
  return crypto.timingSafeEqual(sha(given), sha(ADMIN_TOKEN));
}
let reports = [];
try { reports = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch (_) {}
function save() {
  const tmp = DB + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(reports, null, 2));
  fs.renameSync(tmp, DB);
}

// ---- IP yardımcıları ----
function normIp(ip) {
  ip = String(ip || '').trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  return ip;
}
function v4ToInt(ip) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !(n >= 0 && n <= 255))) return null;
  return ((p[0] << 24) >>> 0) + (p[1] << 16) + (p[2] << 8) + p[3];
}
function ipAllowed(ip) {
  ip = normIp(ip);
  return cfg.allowedIps.some(rule => {
    rule = normIp(rule);
    if (!rule.includes('/')) return rule === ip;
    const [base, bits] = rule.split('/');
    const a = v4ToInt(ip), b = v4ToInt(base), n = Number(bits);
    if (a === null || b === null || !(n >= 0 && n <= 32)) return false;
    const mask = n === 0 ? 0 : (~0 << (32 - n)) >>> 0;
    return ((a & mask) >>> 0) === ((b & mask) >>> 0);
  });
}
function clientIp(req) {
  if (cfg.trustProxy) {
    const xf = req.headers['x-forwarded-for'];
    if (xf) return normIp(xf.split(',')[0]);
  }
  return normIp(req.socket.remoteAddress);
}

// ---- basit hız sınırı ----
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > cfg.rateLimitPerMinute;
}
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (!v.some(t => n - t < 60000)) hits.delete(k); }, 60000).unref();

// ---- yönetici girişi deneme sınırı (kaba kuvvete karşı): 10 başarısız deneme / 10 dk ----
const fails = new Map();
function authBlocked(ip) {
  const now = Date.now();
  const arr = (fails.get(ip) || []).filter(t => now - t < 600000);
  fails.set(ip, arr);
  return arr.length >= 10;
}
function authFail(ip) { const a = fails.get(ip) || []; a.push(Date.now()); fails.set(ip, a); }
setInterval(() => { const n = Date.now(); for (const [k, v] of fails) if (!v.some(t => n - t < 600000)) fails.delete(k); }, 60000).unref();

// ---- yardımcılar ----
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
};
function send(res, code, body, type, extra) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(code, Object.assign({
    'Content-Type': type || (isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8'),
    'Cache-Control': 'no-store'
  }, SEC_HEADERS, extra || {}));
  res.end(isObj ? JSON.stringify(body) : body);
}
// Yalnızca geri bildirim gönderme ucu başka kaynaktan çağrılabilir; yönetim ucu asla.
const CORS_POST = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
function readBody(req, max = 20000) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > max) { reject(new Error('big')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.woff2': 'font/woff2' };
function serveStatic(res, file) {
  const full = path.join(PUB, file);
  if (!full.startsWith(PUB + path.sep) || !fs.existsSync(full)) return send(res, 404, 'Bulunamadı');
  send(res, 200, fs.readFileSync(full), MIME[path.extname(full)] || 'application/octet-stream');
}
const clean = (s, n) => String(s || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, n);

// ---- sunucu ----
const server = http.createServer(async (req, res) => {
  const ip = clientIp(req);
  let url;
  try { url = new URL(req.url, 'http://x'); } catch (_) { return send(res, 400, 'Geçersiz istek.'); }
  const p = url.pathname;
  if (cfg.trustProxy && req.headers['x-forwarded-proto'] === 'https') SEC_HEADERS['Strict-Transport-Security'] = 'max-age=31536000';

  if (req.method === 'OPTIONS') return send(res, 204, '', null, p === '/api/feedback' ? CORS_POST : {});

  // Herkese açık: form ve gönderme
  if (req.method === 'GET' && (p === '/' || p === '/index.html')) return serveStatic(res, 'index.html');
  if (req.method === 'GET' && ['/style.css', '/form.js', '/logo.png', '/fonts.css'].includes(p)) return serveStatic(res, p.slice(1));
  if (req.method === 'GET' && /^\/fonts\/ibm-plex-sans-[a-z-]+-(400|500|600)-normal\.woff2$/.test(p)) return serveStatic(res, p.slice(1));

  if (req.method === 'POST' && p === '/api/feedback') {
    if (limited(ip)) return send(res, 429, { error: 'Çok sık gönderiyorsunuz, biraz bekleyin.' }, null, CORS_POST);
    let data;
    try { data = JSON.parse(await readBody(req)); } catch (_) { return send(res, 400, { error: 'Geçersiz istek.' }, null, CORS_POST); }
    if (!data || typeof data !== 'object' || Array.isArray(data)) return send(res, 400, { error: 'Geçersiz istek.' }, null, CORS_POST);
    const category = clean(data.category, 20);
    const message = clean(data.message, cfg.maxMessageLength);
    if (!CATS[category]) return send(res, 400, { error: 'Kategori geçersiz.' }, null, CORS_POST);
    if (message.length < 5) return send(res, 400, { error: 'Mesaj en az 5 karakter olmalı.' }, null, CORS_POST);
    const source = SOURCES.includes(data.source) ? data.source : 'web';
    const r = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      category, message, source,
      contact: clean(data.contact, 120),
      version: clean(data.version, 40),
      system: clean(data.system, 120),
      read: false
    };
    reports.unshift(r);
    if (reports.length > MAX_REPORTS) reports.length = MAX_REPORTS;   // disk dolmasın: en eskiler düşer
    save();
    return send(res, 201, { ok: true }, null, CORS_POST);
  }

  // Kısıtlı: yönetim sayfası ve raporlar
  if (p === '/admin' || p.startsWith('/api/reports') || p === '/admin.js') {
    if (!ipAllowed(ip)) return send(res, 403, 'Bu sayfaya bu IP adresinden erişilemez.');
    // Sayfanın kendisi (anahtarsız) yalnızca giriş kutusunu içerir; veriye ancak anahtarla ulaşılır.
    if (req.method === 'GET' && p === '/admin') return serveStatic(res, 'admin.html');
    if (req.method === 'GET' && p === '/admin.js') return serveStatic(res, 'admin.js');
    if (authBlocked(ip)) return send(res, 429, { error: 'Çok fazla hatalı deneme. 10 dakika sonra tekrar deneyin.' });
    const bearer = String(req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
    if (!tokenOk(bearer || req.headers['x-admin-token'])) { authFail(ip); return send(res, 401, { error: 'Yönetici anahtarı gerekli.' }); }
    if (req.method === 'GET' && p === '/api/reports') {
      const cat = url.searchParams.get('category');
      return send(res, 200, { categories: CATS, reports: cat && CATS[cat] ? reports.filter(r => r.category === cat) : reports });
    }
    const m = p.match(/^\/api\/reports\/([\w-]+)(\/read)?$/);
    if (m) {
      const i = reports.findIndex(r => r.id === m[1]);
      if (i < 0) return send(res, 404, { error: 'Rapor yok.' });
      if (req.method === 'POST' && m[2]) { reports[i].read = true; save(); return send(res, 200, { ok: true }); }
      if (req.method === 'DELETE' && !m[2]) { reports.splice(i, 1); save(); return send(res, 200, { ok: true }); }
    }
  }
  send(res, 404, 'Bulunamadı');
});

if (require.main === module) {
  // Varsayılan olarak yalnızca yerel adreste dinler; ters vekil (Nginx) önünde durur.
  const host = cfg.host || '127.0.0.1';
  server.listen(cfg.port, host, () => console.log('Schway Geri Bildirim Merkezi: http://' + host + ':' + cfg.port));
}
module.exports = { server, tokenOk, ipAllowed };
