# Schway Geri Bildirim Merkezi

Bağımlılığı yok, yalnızca Node.js 18+ gerekir.

    node server.js

- `http://sunucu:3000/` herkese açık geri bildirim formu (site kaynağı).
- `http://sunucu:3000/admin` yalnızca `config.json` içindeki `allowedIps` listesindeki IP'ler açabilir (tek IP ya da `192.168.1.0/24` gibi IPv4 aralığı) **ve** yönetici anahtarını girmek gerekir. Anahtar `config.json` > `adminToken` doluysa oradan, boşsa ilk açılışta üretilip `data/admin-token` dosyasına (0600) yazılır; `SCHWAY_FB_TOKEN` ortam değişkeni de kabul edilir. API'ye `Authorization: Bearer <anahtar>` ya da `X-Admin-Token` başlığıyla erişilir. 10 hatalı denemede IP 10 dakika engellenir.
- Varsayılan olarak yalnızca `127.0.0.1` dinler (`host`); dışarıya Nginx + HTTPS ile açın (`nginx.conf.example`, `schway-feedback-center.service.example`).
- `maxReports` (varsayılan 5000) aşılınca en eski raporlar düşer.
- Test: `node --test test.js`
- Uygulama `POST /api/feedback` ile gönderir: `{category: bug|oneri|elestiri, message, contact, version, system, source: "app"}`.
- Raporlar `data/reports.json` dosyasında durur.
- Nginx gibi bir ters vekil arkasındaysanız `trustProxy` değerini `true` yapın ve vekilin `X-Forwarded-For` gönderdiğinden emin olun; aksi halde bu başlık taklit edilebilir, `false` bırakın.
