const f = document.getElementById('f');
const msg = document.getElementById('msg');
f.addEventListener('submit', async e => {
  e.preventDefault();
  const d = new FormData(f);
  msg.className = ''; msg.textContent = 'Gönderiliyor…';
  try {
    const r = await fetch('/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category: d.get('category'), message: d.get('message'), contact: d.get('contact'), source: 'web' })
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Gönderilemedi.');
    f.reset(); msg.className = 'ok'; msg.textContent = 'Teşekkürler, iletildi.';
  } catch (err) { msg.className = 'err'; msg.textContent = err.message; }
});
