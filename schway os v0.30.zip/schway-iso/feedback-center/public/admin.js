const list = document.getElementById('list');
const count = document.getElementById('count');
let cat = '';
const NAMES = { bug: 'Hata', oneri: 'Öneri', elestiri: 'Eleştiri' };

function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

const login = document.getElementById('login');
const tok = document.getElementById('tok');
const err = document.getElementById('err');
function authHeaders() { return { Authorization: 'Bearer ' + (sessionStorage.getItem('sfb') || '') }; }
function showLogin(msg) { login.hidden = false; err.textContent = msg || ''; list.replaceChildren(); count.textContent = ''; }
login.addEventListener('submit', e => { e.preventDefault(); sessionStorage.setItem('sfb', tok.value.trim()); tok.value = ''; load(); });

async function load() {
  const r = await fetch('/api/reports' + (cat ? '?category=' + cat : ''), { headers: authHeaders() });
  if (r.status === 401) { sessionStorage.removeItem('sfb'); return showLogin('Anahtar geçersiz.'); }
  if (r.status === 429) { return showLogin('Çok fazla hatalı deneme, 10 dakika bekleyin.'); }
  if (!r.ok) { list.textContent = 'Raporlar yüklenemedi.'; return; }
  login.hidden = true;
  const { reports } = await r.json();
  const unread = reports.filter(x => !x.read).length;
  count.textContent = reports.length + ' rapor, ' + unread + ' okunmamış';
  list.replaceChildren();
  if (!reports.length) list.append(el('p', 'sub', 'Henüz rapor yok.'));
  for (const x of reports) {
    const card = el('article', 'rep' + (x.read ? '' : ' new'));
    const head = el('div', 'rep-h');
    head.append(el('span', 'tag ' + x.category, NAMES[x.category]));
    head.append(el('span', 'meta', new Date(x.date).toLocaleString('tr-TR') + ' · ' + (x.source === 'app' ? 'uygulama' : 'site')));
    card.append(head, el('p', 'rep-m', x.message));
    const info = [x.contact && 'İletişim: ' + x.contact, x.version && 'Sürüm: ' + x.version, x.system && x.system].filter(Boolean).join(' · ');
    if (info) card.append(el('p', 'meta', info));
    const acts = el('div', 'acts');
    if (!x.read) {
      const b = el('button', null, 'Okundu'); b.onclick = async () => { await fetch('/api/reports/' + x.id + '/read', { method: 'POST', headers: authHeaders() }); load(); };
      acts.append(b);
    }
    const d = el('button', 'del', 'Sil'); d.onclick = async () => { if (confirm('Bu rapor silinsin mi?')) { await fetch('/api/reports/' + x.id, { method: 'DELETE', headers: authHeaders() }); load(); } };
    acts.append(d); card.append(acts); list.append(card);
  }
}
document.getElementById('tabs').addEventListener('click', e => {
  if (!e.target.dataset) return;
  cat = e.target.dataset.c ?? cat;
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b === e.target));
  load();
});
load();
