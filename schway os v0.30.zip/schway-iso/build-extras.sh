#!/bin/bash
# İsteğe bağlı AUR paketlerini (şimdilik: Bibata imleç teması) derleyip yerel depoya ekler.
# Başarısız olursa derlemeyi DURDURMAZ: ISO Adwaita imleciyle devam eder (build-iso.sh bunu kendisi ayarlar).
# NORMAL KULLANICIYLA çalıştır (root değil):  bash build-extras.sh
HERE=$(cd "$(dirname "$0")" && pwd)
[ "$EUID" -ne 0 ] || { echo "root ile değil, normal kullanıcıyla çalıştır: bash build-extras.sh"; exit 1; }
mkdir -p "$HERE/localrepo" "$HERE/aur-build"

# shellcheck disable=SC2043  # şimdilik tek paket; liste ileride büyüyebilir
for pkg in bibata-cursor-theme-bin; do
    ls "$HERE"/localrepo/$pkg-*.pkg.tar.* >/dev/null 2>&1 && { echo ">> $pkg zaten yerel depoda."; continue; }
    rm -rf "$HERE/aur-build/$pkg"
    if git clone --depth 1 "https://aur.archlinux.org/$pkg.git" "$HERE/aur-build/$pkg" \
       && (cd "$HERE/aur-build/$pkg" && makepkg -sf --noconfirm); then
        cp "$HERE"/aur-build/$pkg/*.pkg.tar.* "$HERE/localrepo/"
        rm -f "$HERE"/localrepo/*-debug-*
        repo-add "$HERE/localrepo/schway-local.db.tar.gz" "$HERE"/aur-build/$pkg/*.pkg.tar.* \
            || echo "UYARI: $pkg yerel depoya eklenemedi."
    else
        echo "UYARI: $pkg derlenemedi, ISO bunsuz (Adwaita imleç) hazırlanacak."
    fi
done

# Geri Bildirim uygulaması (Tauri): kendi deposundan derlenir; olmazsa ISO onsuz hazırlanır.
if (cd "$HERE/repo/schway-feedback" && rm -f ./*.pkg.tar.* && makepkg -sf --noconfirm); then
    rm -f "$HERE"/localrepo/schway-feedback-*.pkg.tar.*
    cp "$HERE"/repo/schway-feedback/*.pkg.tar.* "$HERE/localrepo/"
    repo-add "$HERE/localrepo/schway-local.db.tar.gz" "$HERE"/localrepo/schway-feedback-*.pkg.tar.* \
        || echo "UYARI: schway-feedback yerel depoya eklenemedi."
else
    echo "UYARI: schway-feedback (Tauri) derlenemedi, ISO bu uygulama olmadan hazırlanacak."
fi
exit 0
