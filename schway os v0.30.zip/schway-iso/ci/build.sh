#!/bin/bash
# GitHub Actions içinde (Arch Linux konteyneri) çalışır.
set -euo pipefail
cd "$(dirname "$0")/.."
exec > >(tee build.log) 2>&1

# Konteynerde alan denetimi şikayet eder
sed -i 's/^CheckSpace/#CheckSpace/' /etc/pacman.conf
pacman -Syu --noconfirm --needed base-devel git sudo archiso

# AUR derlemesi için root olmayan kullanıcı
id builder >/dev/null 2>&1 || useradd -m builder
echo 'builder ALL=(ALL) NOPASSWD: ALL' > /etc/sudoers.d/builder
chown -R builder:builder /work

if [ ! -f localrepo/schway-local.db.tar.gz ]; then
    sudo -u builder bash build-calamares.sh
else
    echo ">> Calamares önbellekten alındı, yeniden derlenmedi."
fi

# Bibata (isteğe bağlı): önbellekteki depoda yoksa sadece onu derle; olmazsa ISO Adwaita ile devam eder
sudo -u builder bash build-extras.sh || echo "UYARI: build-extras.sh başarısız, Bibata imleç atlandı."

if [ "${LITE:-1}" = "1" ]; then
    bash build-iso.sh --lite
else
    bash build-iso.sh
fi

cd out
for f in *.iso; do sha256sum "$f" > "$f.sha256"; done
ls -lh
