# Schway: ana (insan) kullanıcıyı bulur. `. /usr/local/lib/schway-user.sh` ile yüklenir.
# Kullanıcı adı artık sabit "schway" değil: kurulumda seçilir (Calamares "users" modülü).
#   schway_user   kullanıcı adı. Sıra: pkexec > sudo > (kök değilse) çalıştıran > ilk 1000+ hesap > "schway"
#   schway_home   o kullanıcının ev dizini
# SCHWAY_PASSWD ortam değişkeni (testler için) /etc/passwd yerine başka bir dosya gösterir.
schway_user() {
    local pw="${SCHWAY_PASSWD:-/etc/passwd}" u=""
    if [ -n "${PKEXEC_UID:-}" ]; then u=$(awk -F: -v i="$PKEXEC_UID" '$3==i {print $1; exit}' "$pw"); fi
    if [ -z "$u" ] && [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != root ]; then u=$SUDO_USER; fi
    if [ -z "$u" ] && [ "$(id -u)" -ne 0 ]; then u=$(id -un); fi
    if [ -z "$u" ]; then u=$(awk -F: '$3>=1000 && $3<60000 {print $1; exit}' "$pw"); fi
    echo "${u:-schway}"
}
schway_home() { awk -F: -v u="$(schway_user)" '$1==u {print $6; exit}' "${SCHWAY_PASSWD:-/etc/passwd}"; }
# 1000+ numaralı gerçek (insan) hesap var mı?
schway_has_human() { awk -F: '$3>=1000 && $3<60000 {f=1} END{exit !f}' "${SCHWAY_PASSWD:-/etc/passwd}"; }
# Kullanıcının uid'si (yoksa boş)
schway_uid() { awk -F: -v u="$1" '$1==u {print $3; exit}' "${SCHWAY_PASSWD:-/etc/passwd}"; }
