# Schway: yetki yükseltme yardımcısı. `. /usr/local/lib/schway-elev.sh` ile yüklenir.
#   elev komut arg...   Kök olarak çalıştırır:
#     - sudoers parolasız izin veriyorsa (ya da sudo parolası az önce girildiyse) sudo -n,
#     - terminaldeyse sudo (parolayı terminalde sorar),
#     - grafik oturumdaysa pkexec (hyprpolkitagent parola penceresi açar).
elev() {
    local c; c=$(command -v "$1") || { echo "komut yok: $1" >&2; return 127; }; shift
    if [ "$EUID" -eq 0 ]; then "$c" "$@"
    elif sudo -n -ll "$c" "$@" 2>/dev/null | grep -q "!authenticate"; then sudo -n "$c" "$@"
    elif [ -t 0 ] && [ -t 1 ]; then sudo "$c" "$@"
    else pkexec "$c" "$@"; fi
}
