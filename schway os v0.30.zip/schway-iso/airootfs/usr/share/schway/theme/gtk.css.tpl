/* Schway koyu tema: libadwaita adlandırılmış renkleri (adw-gtk3 ve GTK4 uygulamaları) */
@define-color accent_color @ACCENT_L@;
@define-color accent_bg_color @ACCENT@;
@define-color accent_fg_color @ACCENT_FG@;
@define-color destructive_color #ff7b8a;
@define-color destructive_bg_color #e5484d;
@define-color destructive_fg_color #ffffff;
@define-color success_color #57d6a0;
@define-color success_bg_color #2f9e6f;
@define-color success_fg_color #ffffff;
@define-color warning_color #f5c76b;
@define-color warning_bg_color #c98f1a;
@define-color warning_fg_color #11131a;
@define-color error_color #ff7b8a;
@define-color error_bg_color #e5484d;
@define-color error_fg_color #ffffff;

@define-color window_bg_color #13171f;
@define-color window_fg_color #e3e7ef;
@define-color view_bg_color #0e1117;
@define-color view_fg_color #e3e7ef;
@define-color headerbar_bg_color #181d27;
@define-color headerbar_fg_color #e3e7ef;
@define-color headerbar_border_color rgba(255, 255, 255, 0.08);
@define-color headerbar_backdrop_color #13171f;
@define-color headerbar_shade_color rgba(0, 0, 0, 0.25);
@define-color card_bg_color rgba(255, 255, 255, 0.06);
@define-color card_fg_color #e3e7ef;
@define-color card_shade_color rgba(0, 0, 0, 0.25);
@define-color popover_bg_color #1b212c;
@define-color popover_fg_color #e3e7ef;
@define-color dialog_bg_color #181d27;
@define-color dialog_fg_color #e3e7ef;
@define-color sidebar_bg_color #10141b;
@define-color sidebar_fg_color #e3e7ef;
@define-color sidebar_backdrop_color #13171f;
@define-color sidebar_border_color rgba(255, 255, 255, 0.06);
@define-color sidebar_shade_color rgba(0, 0, 0, 0.25);
@define-color thumbnail_bg_color #1b212c;
@define-color thumbnail_fg_color #e3e7ef;

/* Yuvarlak köşeler (Schway görünümü) */
button, entry, spinbutton, combobox button { border-radius: 8px; }
menu, .popup, popover.background > contents { border-radius: 10px; }
scrollbar slider { min-width: 6px; min-height: 6px; border-radius: 6px; }
