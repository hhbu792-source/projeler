[main]
font=JetBrains Mono:size=11
pad=12x10

[cursor]
style=beam
blink=no

# [colors] eski ve yeni foot sürümlerinde çalışır
[colors]
alpha=0.92
background=0d1016
foreground=e3e7ef
cursor=0d1016 @ACCENT_NH@
selection-foreground=e3e7ef
selection-background=@ACCENT_NH@
regular0=232934
regular1=f0707d
regular2=4fd1a1
regular3=e8b65a
regular4=6d93f5
regular5=c58af0
regular6=5cc8de
regular7=c5cad6
bright0=4a5163
bright1=f58e98
bright2=7be0b9
bright3=f2cc85
bright4=94b2fb
bright5=dcaef7
bright6=8fe3f2
bright7=ffffff
