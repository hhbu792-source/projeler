import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

// Schway Mağaza (Flathub / Flatpak). Arka uç: schway-store. Ayrı bir Quickshell süreci olarak çalışır
// (`schway-store gui`), bu yüzden burada bir hata olsa bile masaüstü kabuğu etkilenmez.
ShellRoot {
    FloatingWindow {
        id: win
        visible: true
        title: "Schway Mağaza"
        implicitWidth: 920
        implicitHeight: 660
        color: Theme.base

        property int tab: 0                 // 0 Keşfet, 1 Kurulu, 2 Güncellemeler
        property var featuredList: []
        property var searchList: []
        property var installedList: []
        property var updatesList: []
        property var installedMap: ({})
        property string busyId: ""
        property string busyWhat: ""
        property string note: ""
        property bool searching: false
        readonly property string q: search.text.trim()
        readonly property var shown: tab === 0 ? (q.length >= 2 ? searchList : featuredList) : (tab === 1 ? installedList : updatesList)
        readonly property string heading: tab === 0 ? (q.length >= 2 ? "Arama sonuçları" : "Öne çıkanlar") : (tab === 1 ? "Kurulu uygulamalar" : "Güncellemesi olanlar")
        readonly property bool busy: busyWhat !== ""

        // Arka uç satırları: "T<TAB>kimlik<TAB>ad<TAB>açıklama"
        function rows(text) {
            const out = []
            const lines = text.split("\n")
            for (let i = 0; i < lines.length; i++) {
                if (lines[i] === "") continue
                const p = lines[i].split("\t")
                if (p.length >= 3) out.push({ id: p[1], name: p[2], desc: p.length > 3 ? p[3] : "" })
            }
            return out
        }
        function run(p) { p.running = false; p.running = true }
        function reload() { run(instProc); run(updProc) }
        function pickTab(t) { tab = t; note = "" }
        function act(verb, id) {
            if (busy) return
            busyId = id
            busyWhat = verb
            note = ""
            actProc.command = verb === "update" ? ["schway-store", "update"] : ["schway-store", verb, id]
            run(actProc)
        }
        function actDone(code) {
            const what = busyWhat
            busyId = ""
            busyWhat = ""
            if (code === 0) note = what === "install" ? "Kuruldu. Uygulama menüde görünmüyorsa oturumu bir kez kapatıp aç." : (what === "remove" ? "Kaldırıldı." : "Güncellendi.")
            else note = "İşlem tamamlanamadı. İnternet bağlantını kontrol et ve tekrar dene."
            reload()
        }
        onVisibleChanged: if (!visible) Qt.quit()
        Component.onCompleted: { run(featProc); reload() }

        Process {
            id: featProc
            command: ["schway-store", "featured"]
            stdout: StdioCollector { onStreamFinished: win.featuredList = win.rows(text) }
        }
        Process {
            id: searchProc
            stdout: StdioCollector {
                onStreamFinished: { win.searchList = win.rows(text); win.searching = false }
            }
            onExited: (code, status) => { if (code !== 0) { win.searching = false; win.searchList = []; win.note = "Arama yapılamadı. İnternet bağlantını kontrol et." } }
        }
        Process {
            id: instProc
            command: ["schway-store", "installed"]
            stdout: StdioCollector {
                onStreamFinished: {
                    const l = win.rows(text)
                    const m = {}
                    for (let i = 0; i < l.length; i++) m[l[i].id] = true
                    win.installedList = l
                    win.installedMap = m
                }
            }
        }
        Process {
            id: updProc
            command: ["schway-store", "updates"]
            stdout: StdioCollector { onStreamFinished: win.updatesList = win.rows(text) }
        }
        Process {
            id: actProc
            onExited: (code, status) => win.actDone(code)
        }
        Timer {
            id: searchTimer
            interval: 450
            onTriggered: {
                if (win.q.length < 2) { win.searching = false; return }
                win.searching = true
                win.note = ""
                searchProc.command = ["schway-store", "search", win.q]
                win.run(searchProc)
            }
        }

        Item {
            anchors.fill: parent
            focus: true
            Keys.onEscapePressed: Qt.quit()

            ColumnLayout {
                anchors { fill: parent; margins: 22 }
                spacing: 14

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 14
                    Text {
                        text: "Mağaza"
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 26
                        font.weight: Font.DemiBold
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        Layout.preferredWidth: 340
                        Layout.preferredHeight: 40
                        radius: Theme.rCtl
                        color: Theme.well
                        border.width: 1
                        border.color: search.activeFocus ? Theme.accent : Theme.border
                        TextInput {
                            id: search
                            objectName: "storeSearch"
                            anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                            verticalAlignment: TextInput.AlignVCenter
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: 14
                            clip: true
                            selectByMouse: true
                            onTextChanged: { win.tab = 0; searchTimer.restart() }
                            Text {
                                visible: search.text === "" && !search.activeFocus
                                anchors.verticalCenter: parent.verticalCenter
                                text: "Uygulama ara (Flathub)"
                                color: Theme.faint
                                font.family: Theme.font
                                font.pixelSize: 14
                            }
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: [
                            { t: "Keşfet", i: 0 },
                            { t: "Kurulu", i: 1 },
                            { t: "Güncellemeler", i: 2 }
                        ]
                        delegate: Rectangle {
                            required property var modelData
                            Layout.preferredHeight: 34
                            Layout.preferredWidth: label.implicitWidth + 32
                            radius: Theme.rCtl
                            color: win.tab === modelData.i ? Theme.accentSoft : (tabHit.containsMouse ? Theme.hover : "transparent")
                            Text {
                                id: label
                                anchors.centerIn: parent
                                text: modelData.t + (modelData.i === 2 && win.updatesList.length > 0 ? " (" + win.updatesList.length + ")" : "")
                                color: win.tab === modelData.i ? Theme.text : Theme.muted
                                font.family: Theme.font
                                font.pixelSize: 13
                            }
                            MouseArea {
                                id: tabHit
                                anchors.fill: parent
                                hoverEnabled: true
                                onClicked: win.pickTab(modelData.i)
                            }
                        }
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        visible: win.tab === 2 && win.updatesList.length > 0
                        Layout.preferredHeight: 34
                        Layout.preferredWidth: updLabel.implicitWidth + 32
                        radius: Theme.rCtl
                        color: win.busy ? Theme.surface : Theme.accent
                        Text {
                            id: updLabel
                            anchors.centerIn: parent
                            text: win.busyWhat === "update" ? "Güncelleniyor..." : "Tümünü güncelle"
                            color: win.busy ? Theme.muted : Theme.onAccent
                            font.family: Theme.font
                            font.pixelSize: 13
                            font.weight: Font.Medium
                        }
                        MouseArea { anchors.fill: parent; enabled: !win.busy; onClicked: win.act("update", "") }
                    }
                }

                Text {
                    text: win.heading
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 12
                    font.weight: Font.Medium
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: Theme.rGroup
                    color: Theme.surface
                    border.width: 1
                    border.color: Theme.line
                    clip: true

                    ListView {
                        id: view
                        objectName: "storeList"
                        anchors.fill: parent
                        model: win.shown
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Item {
                            id: row
                            required property var modelData
                            required property int index
                            readonly property bool isInstalled: win.installedMap[modelData.id] === true
                            readonly property bool mine: win.busyId === modelData.id
                            width: view.width
                            height: 68

                            Rectangle {
                                visible: row.index > 0
                                anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 16 }
                                height: 1
                                color: Theme.line
                            }
                            RowLayout {
                                anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
                                spacing: 14
                                Rectangle {
                                    Layout.preferredWidth: 40
                                    Layout.preferredHeight: 40
                                    radius: Theme.rCtl
                                    color: Theme.accentSoft
                                    Text {
                                        anchors.centerIn: parent
                                        text: row.modelData.name.length > 0 ? row.modelData.name.charAt(0).toUpperCase() : "?"
                                        color: Theme.accentDark
                                        font.family: Theme.font
                                        font.pixelSize: 18
                                        font.weight: Font.DemiBold
                                    }
                                }
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 2
                                    Text {
                                        Layout.fillWidth: true
                                        text: row.modelData.name
                                        color: Theme.text
                                        font.family: Theme.font
                                        font.pixelSize: 14
                                        font.weight: Font.Medium
                                        elide: Text.ElideRight
                                    }
                                    Text {
                                        Layout.fillWidth: true
                                        text: row.modelData.desc
                                        color: Theme.muted
                                        font.family: Theme.font
                                        font.pixelSize: 12
                                        elide: Text.ElideRight
                                    }
                                }
                                Rectangle {
                                    Layout.preferredHeight: 34
                                    Layout.preferredWidth: 104
                                    radius: Theme.rCtl
                                    color: row.mine ? Theme.surface : (row.isInstalled ? Theme.hover : Theme.accent)
                                    border.width: row.isInstalled ? 1 : 0
                                    border.color: Theme.border
                                    Text {
                                        anchors.centerIn: parent
                                        text: row.mine ? (win.busyWhat === "remove" ? "Kaldırılıyor..." : "Kuruluyor...") : (row.isInstalled ? "Kaldır" : "Kur")
                                        color: row.mine ? Theme.muted : (row.isInstalled ? Theme.text : Theme.onAccent)
                                        font.family: Theme.font
                                        font.pixelSize: 13
                                        font.weight: Font.Medium
                                    }
                                    MouseArea {
                                        anchors.fill: parent
                                        enabled: !win.busy
                                        onClicked: win.act(row.isInstalled ? "remove" : "install", row.modelData.id)
                                    }
                                }
                            }
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        visible: win.shown.length === 0
                        width: parent.width - 60
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 14
                        text: win.searching ? "Aranıyor..." : (win.tab === 1 ? "Mağazadan kurduğun uygulama yok." : (win.tab === 2 ? "Tüm uygulamaların güncel." : (win.q.length >= 2 ? "Sonuç bulunamadı." : "Yükleniyor...")))
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    Rectangle {
                        visible: win.busy
                        Layout.preferredWidth: 90
                        Layout.preferredHeight: 4
                        radius: 2
                        color: Theme.track
                        clip: true
                        Rectangle {
                            id: bar
                            width: 30
                            height: parent.height
                            radius: 2
                            color: Theme.accent
                            SequentialAnimation on x {
                                running: win.busy
                                loops: Animation.Infinite
                                NumberAnimation { from: 0; to: 60; duration: 700; easing.type: Easing.InOutQuad }
                                NumberAnimation { from: 60; to: 0; duration: 700; easing.type: Easing.InOutQuad }
                            }
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        text: win.busy ? "İşlem sürüyor, uygulama boyutuna göre birkaç dakika sürebilir..." : win.note
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                    Text {
                        text: "Kaynak: Flathub"
                        color: Theme.faint
                        font.family: Theme.font
                        font.pixelSize: 11
                    }
                }
            }
        }
    }
}
