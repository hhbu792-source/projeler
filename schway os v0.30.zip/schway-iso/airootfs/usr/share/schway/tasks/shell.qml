import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

// Schway Görev Yöneticisi. Arka uç: schway-tasks. Ayrı bir Quickshell sürecidir (`schway-tasks gui`): hata olsa masaüstü kabuğu etkilenmez.
ShellRoot {
    FloatingWindow {
        id: win
        visible: true
        title: "Schway Görev Yöneticisi"
        implicitWidth: 980
        implicitHeight: 660
        color: Theme.base

        property int tab: 0                       // 0 İşlemler, 1 Performans, 2 Hizmetler
        property var sum: ({})
        property var cpuHist: []
        property var memHist: []
        property var svcs: []
        property string sortKey: "cpu"
        property bool allProcs: false
        property int selPid: -1
        property string selName: ""
        property string selFlags: ""
        property string svcFilter: "all"
        readonly property string lockGlyph: String.fromCodePoint(0xF033E)
        property string note: ""
        property bool noteBad: false
        property bool busy: false
        property var ask: null                    // { text, danger, fn }
        readonly property string q: search.text.trim().toLowerCase()

        function num(x) { const v = parseFloat(x); return isNaN(v) ? 0 : v }
        function sizeText(mb) { return mb >= 1024 ? (mb / 1024).toFixed(1) + " GB" : Math.round(mb) + " MB" }
        function upText(s) {
            const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60)
            return (d > 0 ? d + " gün " : "") + (h > 0 ? h + " sa " : "") + m + " dk"
        }
        function say(text, bad) { note = text; noteBad = !!bad; noteTimer.restart() }
        function run(p) { p.running = false; p.running = true }
        function push(arr, v) { const a = arr.slice(-59); a.push(v); return a }
        function sync(m, arr) {
            for (let i = 0; i < arr.length; i++) { if (i < m.count) m.set(i, arr[i]); else m.append(arr[i]) }
            if (m.count > arr.length) m.remove(arr.length, m.count - arr.length)
        }
        function parseProcs(text) {
            const out = []
            text.split("\n").forEach(l => {
                const p = l.split("\t")
                if (p.length >= 8) out.push({ pid: parseInt(p[0]), user: p[1], cpu: num(p[2]), mem: num(p[3]), state: p[4], pname: p[5], cmd: p[6], flags: p[7] })
            })
            return out
        }
        function refreshProcs() {
            const f = parseProcs(rawProcs).filter(p => (allProcs || (p.flags.indexOf("m") >= 0 && p.flags.indexOf("k") < 0)) &&
                (q === "" || p.pname.toLowerCase().indexOf(q) >= 0 || p.cmd.toLowerCase().indexOf(q) >= 0 || p.user.toLowerCase().indexOf(q) >= 0 || String(p.pid) === q))
            f.sort((a, b) => sortKey === "name" ? a.pname.toLowerCase().localeCompare(b.pname.toLowerCase()) : (sortKey === "mem" ? b.mem - a.mem : (sortKey === "pid" ? a.pid - b.pid : b.cpu - a.cpu)))
            shownCount = f.length
            sync(procModel, f)
        }
        property string rawProcs: ""
        property int shownCount: 0
        function parseSvcs(text) {
            const out = []
            text.split("\n").forEach(l => {
                const p = l.split("\t")
                if (p.length >= 6) out.push({ unit: p[0], active: p[1], enabled: p[2], mem: p[3], desc: p[4], pol: p[5] })
            })
            return out
        }
        function refreshSvcs() {
            const f = svcs.filter(s => (svcFilter === "all" || (svcFilter === "running" && s.active === "active") ||
                (svcFilter === "boot" && s.enabled === "enabled") || (svcFilter === "problem" && s.active === "failed")) &&
                (q === "" || s.unit.toLowerCase().indexOf(q) >= 0 || s.desc.toLowerCase().indexOf(q) >= 0))
            svcShown = f.length
            sync(svcModel, f)
        }
        property int svcShown: 0
        onSvcsChanged: refreshSvcs()
        onSvcFilterChanged: refreshSvcs()
        onQChanged: { refreshProcs(); refreshSvcs() }
        onSortKeyChanged: refreshProcs()
        onAllProcsChanged: refreshProcs()
        onTabChanged: { note = ""; if (tab === 2) run(svcProc) }

        function endTask(kill) {
            if (selPid < 0) return
            const go = () => { actProc.command = ["schway-tasks", "kill", String(selPid), kill ? "kill" : "term"]; run(actProc) }
            if (selFlags.indexOf("c") >= 0) ask = { text: "“" + selName + "” sistemin önemli bir parçası. Kapatmak oturumunu, ağını ya da sesini bozabilir. Yine de kapatılsın mı?", danger: true, fn: go }
            else if (kill) ask = { text: "“" + selName + "” zorla kapatılacak; kaydedilmemiş veriler kaybolabilir.", danger: true, fn: go }
            else go()
        }
        function svcAct(verb, unit) {
            if (busy) return
            const go = () => { busy = true; svcActProc.command = ["schway-tasks", "service", verb, unit]; run(svcActProc) }
            if (verb === "stop" || verb === "disable") ask = { text: unit + (verb === "stop" ? " durdurulacak." : " açılışta başlamayacak ve şimdi durdurulacak.") + " Devam edilsin mi?", danger: false, fn: go }
            else go()
        }

        ListModel { id: procModel }
        ListModel { id: svcModel }

        Process { id: sumProc; command: ["schway-tasks", "summary"]
            stdout: StdioCollector { onStreamFinished: {
                const o = {}
                text.split("\n").forEach(l => { const i = l.indexOf("="); if (i > 0) o[l.substring(0, i)] = l.substring(i + 1) })
                win.sum = o
                win.cpuHist = win.push(win.cpuHist, win.num(o.cpu))
                win.memHist = win.push(win.memHist, win.num(o.mem_total_mb) > 0 ? 100 * win.num(o.mem_used_mb) / win.num(o.mem_total_mb) : 0)
            } } }
        Process { id: procProc; command: ["schway-tasks", "list"]
            stdout: StdioCollector { onStreamFinished: { win.rawProcs = text; win.refreshProcs() } } }
        Process { id: svcProc; command: ["schway-tasks", "services"]
            stdout: StdioCollector { onStreamFinished: win.svcs = win.parseSvcs(text) } }
        Process { id: actProc
            stdout: StdioCollector { id: actOut }
            stderr: StdioCollector { id: actErr }
            onExited: (code, status) => { win.say(code === 0 ? actOut.text.trim() : (actErr.text.trim() || "İşlem başarısız."), code !== 0); win.run(procProc) } }
        Process { id: svcActProc
            stdout: StdioCollector { id: svcOut }
            stderr: StdioCollector { id: svcErr }
            onExited: (code, status) => { win.busy = false; win.say(code === 0 ? svcOut.text.trim() : (svcErr.text.trim() || "İşlem başarısız (yönetici onayı verilmedi mi?)."), code !== 0); win.run(svcProc) } }

        Timer { interval: 2000; running: true; repeat: true; triggeredOnStart: true
            onTriggered: { win.run(sumProc); if (win.tab === 0) win.run(procProc) } }
        Timer { interval: 8000; running: win.tab === 2; repeat: true; onTriggered: { if (!win.busy) win.run(svcProc) } }
        Timer { id: noteTimer; interval: 6000; onTriggered: win.note = "" }

        // ---------------- ortak parçalar ----------------
        component Btn: Rectangle {
            id: b
            property string text: ""
            property bool primary: false
            property bool danger: false
            property bool dim: false
            signal clicked()
            implicitWidth: lbl.implicitWidth + 28
            implicitHeight: 32
            radius: Theme.rCtl
            opacity: dim ? 0.4 : 1
            color: primary ? (ma.containsMouse && !dim ? Theme.accentDark : Theme.accent)
                 : (danger ? (ma.containsMouse && !dim ? Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.30) : Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.18))
                 : (ma.containsMouse && !dim ? Theme.press : Theme.hover))
            Text { id: lbl; anchors.centerIn: parent; text: b.text; font.family: Theme.font; font.pixelSize: 13; font.weight: Font.Medium
                   color: b.primary ? Theme.onAccent : (b.danger ? Theme.bad : Theme.text) }
            MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: dim ? Qt.ArrowCursor : Qt.PointingHandCursor; onClicked: if (!b.dim) b.clicked() }
        }
        component Tab: Rectangle {
            id: t
            property string text: ""
            property bool on: false
            signal clicked()
            implicitWidth: tl.implicitWidth + 30
            implicitHeight: 32
            radius: Theme.rCtl
            color: on ? Theme.accentSoft : (tm.containsMouse ? Theme.hover : "transparent")
            Text { id: tl; anchors.centerIn: parent; text: t.text; font.family: Theme.font; font.pixelSize: 14; font.weight: t.on ? Font.Medium : Font.Normal; color: t.on ? Theme.accentDark : Theme.muted }
            MouseArea { id: tm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: t.clicked() }
        }
        component Sw: Rectangle {
            id: s
            property bool on: false
            property bool locked: false
            signal toggled(bool v)
            implicitWidth: 38; implicitHeight: 22; radius: 11
            opacity: locked ? 0.35 : 1
            color: on ? Theme.accent : Theme.track
            Rectangle { y: 3; x: s.on ? 19 : 3; width: 16; height: 16; radius: 8; color: s.on ? Theme.onAccent : Theme.muted; Behavior on x { NumberAnimation { duration: 110 } } }
            MouseArea { anchors.fill: parent; cursorShape: s.locked ? Qt.ForbiddenCursor : Qt.PointingHandCursor; onClicked: if (!s.locked) s.toggled(!s.on) }
        }
        component Spark: Canvas {
            id: sp
            property var data: []
            property color tint: Theme.accent
            onDataChanged: requestPaint()
            onTintChanged: requestPaint()
            onPaint: {
                const c = getContext("2d")
                c.reset()
                const w = width, h = height, n = 60
                c.strokeStyle = Qt.rgba(1, 1, 1, 0.07); c.lineWidth = 1
                for (let g = 1; g < 4; g++) { c.beginPath(); c.moveTo(0, h * g / 4); c.lineTo(w, h * g / 4); c.stroke() }
                if (!data || data.length < 2) return
                const x = i => w - (data.length - 1 - i) * (w / (n - 1))
                const y = v => h - 2 - Math.min(100, Math.max(0, v)) / 100 * (h - 4)
                c.beginPath(); c.moveTo(x(0), h)
                for (let i = 0; i < data.length; i++) c.lineTo(x(i), y(data[i]))
                c.lineTo(x(data.length - 1), h); c.closePath()
                c.fillStyle = Qt.rgba(tint.r, tint.g, tint.b, 0.20); c.fill()
                c.beginPath()
                for (let i = 0; i < data.length; i++) { if (i === 0) c.moveTo(x(i), y(data[i])); else c.lineTo(x(i), y(data[i])) }
                c.strokeStyle = tint; c.lineWidth = 2; c.stroke()
            }
        }

        // ---------------- yerleşim ----------------
        ColumnLayout {
            anchors { fill: parent; margins: 18 }
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 6
                Tab { text: "İşlemler"; on: win.tab === 0; onClicked: win.tab = 0 }
                Tab { text: "Performans"; on: win.tab === 1; onClicked: win.tab = 1 }
                Tab { text: "Hizmetler"; on: win.tab === 2; onClicked: win.tab = 2 }
                Item { Layout.fillWidth: true }
                Rectangle {
                    visible: win.tab !== 1
                    Layout.preferredWidth: 230; Layout.preferredHeight: 32
                    radius: Theme.rCtl; color: Theme.well; border.width: 1; border.color: search.activeFocus ? Theme.accentEdge : Theme.border
                    Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } text: Theme.g.search; font.family: Theme.iconFont; font.pixelSize: 15; color: Theme.faint }
                    TextInput {
                        id: search
                        anchors { left: parent.left; leftMargin: 32; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        color: Theme.text; font.family: Theme.font; font.pixelSize: 13; clip: true; selectByMouse: true
                        Text { visible: search.text === "" && !search.activeFocus; text: win.tab === 0 ? "İşlem ara…" : "Hizmet ara…"; color: Theme.faint; font: search.font }
                    }
                }
            }

            // =================== 0: İŞLEMLER ===================
            ColumnLayout {
                visible: win.tab === 0
                Layout.fillWidth: true; Layout.fillHeight: true
                spacing: 8
                RowLayout {
                    Layout.fillWidth: true; Layout.leftMargin: 14; Layout.rightMargin: 14
                    spacing: 0
                    Repeater {
                        model: [["name", "Ad", 0], ["cpu", "İşlemci", 90], ["mem", "Bellek", 90], ["pid", "PID", 70]]
                        delegate: Item {
                            required property var modelData
                            Layout.fillWidth: modelData[2] === 0
                            Layout.preferredWidth: modelData[2]
                            implicitHeight: 22
                            Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                                   text: modelData[1] + (win.sortKey === modelData[0] ? (modelData[0] === "name" || modelData[0] === "pid" ? "  ▲" : "  ▼") : "")
                                   color: win.sortKey === modelData[0] ? Theme.accentDark : Theme.faint; font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Medium }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: win.sortKey = modelData[0] }
                        }
                    }
                }
                Rectangle {
                    Layout.fillWidth: true; Layout.fillHeight: true
                    radius: Theme.rGroup; color: Theme.surface; border.width: 1; border.color: Theme.line; clip: true
                    ListView {
                        id: pl
                        anchors { fill: parent; margins: 4 }
                        model: procModel
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Rectangle {
                            id: pr
                            required property int pid
                            required property string user
                            required property real cpu
                            required property real mem
                            required property string pname
                            required property string cmd
                            required property string flags
                            width: pl.width; height: 46; radius: Theme.rCtl
                            color: win.selPid === pid ? Theme.accentSoft : (pma.containsMouse ? Theme.hover : "transparent")
                            RowLayout {
                                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                spacing: 0
                                Column {
                                    Layout.fillWidth: true; spacing: 1
                                    Row { spacing: 6
                                        Text { text: pr.pname; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideRight; width: Math.min(implicitWidth, 320) }
                                        Text { visible: pr.flags.indexOf("c") >= 0; text: win.lockGlyph; font.family: Theme.iconFont; font.pixelSize: 12; color: Theme.warn; anchors.verticalCenter: parent.verticalCenter }
                                        Text { visible: pr.flags.indexOf("m") < 0; text: pr.user; color: Theme.faint; font.family: Theme.font; font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter }
                                    }
                                    Text { text: pr.cmd; width: 560; elide: Text.ElideMiddle; color: Theme.faint; font.family: Theme.mono; font.pixelSize: 11 }
                                }
                                Item {
                                    Layout.preferredWidth: 90; Layout.fillHeight: true
                                    Rectangle { anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                                        width: 4; height: 18; radius: 2
                                        color: pr.cpu > 60 ? Theme.bad : (pr.cpu > 25 ? Theme.warn : (pr.cpu > 2 ? Theme.accent : Theme.track)) }
                                    Text { anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                                           text: pr.cpu.toFixed(1) + " %"; color: pr.cpu > 25 ? Theme.text : Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                }
                                Text { Layout.preferredWidth: 90; text: win.sizeText(pr.mem); color: pr.mem > 1024 ? Theme.warn : Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                Text { Layout.preferredWidth: 70; text: pr.pid; color: Theme.faint; font.family: Theme.mono; font.pixelSize: 12 }
                            }
                            MouseArea { id: pma; anchors.fill: parent; hoverEnabled: true
                                onClicked: { win.selPid = pr.pid; win.selName = pr.pname; win.selFlags = pr.flags } }
                        }
                    }
                    Text { anchors.centerIn: parent; visible: win.shownCount === 0; text: win.q !== "" ? "Eşleşen işlem yok." : "İşlemler yükleniyor…"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 14 }
                }
                RowLayout {
                    Layout.fillWidth: true; spacing: 10
                    Text { text: win.shownCount + " işlem" + (win.allProcs ? "" : " (yalnızca sana ait)"); color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                    Rectangle { width: 1; height: 16; color: Theme.line }
                    Text { text: "Tüm işlemleri göster"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                    Sw { on: win.allProcs; onToggled: v => win.allProcs = v }
                    Item { Layout.fillWidth: true }
                    Text { visible: win.note !== "" && win.tab === 0; text: win.note; color: win.noteBad ? Theme.bad : Theme.ok; font.family: Theme.font; font.pixelSize: 13; elide: Text.ElideRight; Layout.maximumWidth: 330 }
                    Btn { text: "Zorla kapat"; danger: true; dim: win.selPid < 0; onClicked: win.endTask(true) }
                    Btn { text: "İşlemi sonlandır"; primary: true; dim: win.selPid < 0; onClicked: win.endTask(false) }
                }
            }

            // =================== 1: PERFORMANS ===================
            GridLayout {
                visible: win.tab === 1
                Layout.fillWidth: true; Layout.fillHeight: true
                columns: 2; columnSpacing: 14; rowSpacing: 14
                component Card: Rectangle {
                    default property alias body: inner.data
                    property string title: ""
                    property string big: ""
                    property string sub: ""
                    property int share: 1                 // satır yüksekliği payı: üst kartlar 2, alt kartlar 1
                    Layout.fillWidth: true; Layout.fillHeight: true; Layout.preferredWidth: 1; Layout.preferredHeight: share
                    radius: Theme.rGroup; color: Theme.surface; border.width: 1; border.color: Theme.line
                    Column {
                        anchors { left: parent.left; top: parent.top; margins: 18 }
                        spacing: 2
                        Text { text: parent.parent.title; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                        Text { text: parent.parent.big; color: Theme.text; font.family: Theme.font; font.pixelSize: 30; font.weight: Font.Medium }
                        Text { text: parent.parent.sub; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                    }
                    Item { id: inner; anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 14 } height: Math.max(24, parent.height - 120) }
                }
                Card {
                    share: 2
                    title: "İşlemci"; big: win.num(win.sum.cpu).toFixed(0) + " %"
                    sub: (win.sum.cores || "?") + " çekirdek · yük " + (win.sum.load1 || "0")
                    Spark { anchors.fill: parent; data: win.cpuHist; tint: Theme.accent }
                }
                Card {
                    share: 2
                    title: "Bellek"; big: win.sizeText(win.num(win.sum.mem_used_mb))
                    sub: "toplam " + win.sizeText(win.num(win.sum.mem_total_mb)) + " · %" + (win.num(win.sum.mem_total_mb) > 0 ? Math.round(100 * win.num(win.sum.mem_used_mb) / win.num(win.sum.mem_total_mb)) : 0)
                    Spark { anchors.fill: parent; data: win.memHist; tint: Theme.ok }
                }
                Card {
                    title: "Takas (swap / zram)"
                    big: win.num(win.sum.swap_total_mb) > 0 ? win.sizeText(win.num(win.sum.swap_used_mb)) : "Yok"
                    sub: win.num(win.sum.swap_total_mb) > 0 ? ("toplam " + win.sizeText(win.num(win.sum.swap_total_mb))) : "Takas alanı tanımlı değil"
                    Rectangle {
                        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                        height: 10; radius: 5; color: Theme.track; visible: win.num(win.sum.swap_total_mb) > 0
                        Rectangle { height: parent.height; radius: 5; color: Theme.warn
                                    width: parent.width * Math.min(1, win.num(win.sum.swap_used_mb) / Math.max(1, win.num(win.sum.swap_total_mb))) }
                    }
                }
                Card {
                    title: "Sistem"; big: win.upText(win.num(win.sum.uptime_s))
                    sub: "açık kalma süresi · " + (win.sum.procs || 0) + " işlem"
                }
            }

            // =================== 2: HİZMETLER ===================
            ColumnLayout {
                visible: win.tab === 2
                Layout.fillWidth: true; Layout.fillHeight: true
                spacing: 10
                RowLayout {
                    Layout.fillWidth: true; spacing: 6
                    Repeater {
                        model: [["all", "Hepsi"], ["running", "Çalışanlar"], ["boot", "Açılışta başlayanlar"], ["problem", "Sorunlular"]]
                        delegate: Tab { required property var modelData; text: modelData[1]; on: win.svcFilter === modelData[0]; onClicked: win.svcFilter = modelData[0] }
                    }
                    Item { Layout.fillWidth: true }
                    Text { text: "Açılışta yalnızca gerekenler çalışmalı. Kilit simgeli hizmetler sistem için zorunludur."; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                }
                Rectangle {
                    Layout.fillWidth: true; Layout.fillHeight: true
                    radius: Theme.rGroup; color: Theme.surface; border.width: 1; border.color: Theme.line; clip: true
                    ListView {
                        id: sl
                        anchors { fill: parent; margins: 4 }
                        model: svcModel
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Rectangle {
                            id: sr
                            required property string unit
                            required property string active
                            required property string enabled
                            required property string mem
                            required property string desc
                            required property string pol
                            width: sl.width; height: 54; radius: Theme.rCtl
                            color: sma.containsMouse ? Theme.hover : "transparent"
                            MouseArea { id: sma; anchors.fill: parent; hoverEnabled: true; acceptedButtons: Qt.NoButton }
                            RowLayout {
                                anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                                spacing: 12
                                Rectangle { width: 9; height: 9; radius: 4.5; color: sr.active === "active" ? Theme.ok : (sr.active === "failed" ? Theme.bad : Theme.track) }
                                Column {
                                    Layout.fillWidth: true; spacing: 2
                                    Row { spacing: 8
                                        Text { text: sr.unit.replace(".service", ""); color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                        Text { visible: sr.pol === "essential"; text: win.lockGlyph; font.family: Theme.iconFont; font.pixelSize: 12; color: Theme.warn; anchors.verticalCenter: parent.verticalCenter }
                                        Text { visible: sr.pol === "ondemand" || sr.pol === "remove"; text: "varsayılan kapalı"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter }
                                        Text { visible: sr.active === "failed"; text: "başarısız"; color: Theme.bad; font.family: Theme.font; font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter }
                                    }
                                    Text { text: sr.desc; width: 520; elide: Text.ElideRight; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                                }
                                Text { Layout.preferredWidth: 70; horizontalAlignment: Text.AlignRight; text: sr.mem === "-" ? "" : sr.mem + " MB"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                                Item {   // sabit genişlikli yuva: düğme olmayan satırlarda sütunlar kaymasın
                                    Layout.preferredWidth: 84; Layout.preferredHeight: 32
                                    Btn { anchors.right: parent.right; visible: sr.pol !== "essential" || sr.active !== "active"; text: sr.active === "active" ? "Durdur" : "Başlat"
                                          dim: win.busy; onClicked: win.svcAct(sr.active === "active" ? "stop" : "start", sr.unit) }
                                }
                                Column { spacing: 3
                                    Sw { on: sr.enabled === "enabled"; locked: sr.pol === "essential" || win.busy || (sr.enabled !== "enabled" && sr.enabled !== "disabled")
                                         onToggled: v => win.svcAct(v ? "enable" : "disable", sr.unit) }
                                    Text { text: "açılışta"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 10; anchors.horizontalCenter: parent.horizontalCenter }
                                }
                            }
                        }
                    }
                    Text { anchors.centerIn: parent; visible: win.svcShown === 0; text: win.svcs.length === 0 ? "Hizmetler yükleniyor…" : "Eşleşen hizmet yok."; color: Theme.muted; font.family: Theme.font; font.pixelSize: 14 }
                }
                RowLayout {
                    Layout.fillWidth: true
                    Text { text: win.svcShown + " hizmet"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                    Item { Layout.fillWidth: true }
                    Text { visible: win.note !== "" && win.tab === 2; text: win.note; color: win.noteBad ? Theme.bad : Theme.ok; font.family: Theme.font; font.pixelSize: 13; elide: Text.ElideRight; Layout.maximumWidth: 600 }
                    Text { visible: win.busy; text: "Yönetici onayı bekleniyor…"; color: Theme.warn; font.family: Theme.font; font.pixelSize: 13 }
                }
            }
        }

        // ---------------- onay penceresi ----------------
        Rectangle {
            anchors.fill: parent
            visible: win.ask !== null
            color: Theme.scrim
            MouseArea { anchors.fill: parent }
            Rectangle {
                anchors.centerIn: parent
                width: 420; implicitHeight: dc.implicitHeight + 40; height: implicitHeight
                radius: Theme.rWin; color: Qt.rgba(Theme.base.r, Theme.base.g, Theme.base.b, 1); border.width: 1; border.color: Theme.border
                ColumnLayout {
                    id: dc
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
                    spacing: 16
                    Text { Layout.fillWidth: true; wrapMode: Text.Wrap; text: win.ask ? win.ask.text : ""; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; lineHeight: 1.25 }
                    RowLayout {
                        Layout.alignment: Qt.AlignRight; spacing: 8
                        Btn { text: "Vazgeç"; onClicked: win.ask = null }
                        Btn { text: "Evet, devam et"; primary: !(win.ask && win.ask.danger); danger: win.ask ? win.ask.danger : false
                              onClicked: { const f = win.ask.fn; win.ask = null; f() } }
                    }
                }
            }
        }
    }
}
