import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

// Schway Dosyalar. Arka uç: schway-files. Ayrı bir Quickshell sürecidir (`schway-files gui`): hata olsa masaüstü kabuğu etkilenmez.
ShellRoot {
    FloatingWindow {
        id: win
        visible: true
        title: "Schway Dosyalar"
        implicitWidth: 1040
        implicitHeight: 700
        color: Theme.base

        // ---- durum ----
        property string cwd: ""                    // "trash://" = çöp kutusu görünümü
        property var backStack: []
        property var fwdStack: []
        property var places: []
        property bool showHidden: false
        property string sortKey: "name"            // name | size | date
        property bool sortAsc: true
        property var clip: ({ mode: "", paths: [] })
        property var sel: ({})                     // ad -> true
        property int anchorIdx: -1
        property var rows: []                      // ayrıştırılmış satırlar (sıralanmış, süzülmüş)
        property string rawText: ""
        property bool searching: false
        property string searchBase: ""
        property string startPath: ""               // ilk açılacak yer (boşsa SCHWAY_FILES_START, o da yoksa ev)
        property bool editPath: false
        property bool loading: false
        property string note: ""
        property bool noteBad: false
        property var dlg: null                     // { kind: "name"|"confirm", title, text, value, danger, fn }
        property bool previewOn: false
        property var prev: ({ kind: "none" })
        property string prevPath: ""
        property string prevText: ""
        property var menu: null                    // { x, y, items: [{ id, label, danger, dim, sep }] }
        property bool dragging: false
        property bool dragCopy: false
        property string dropHover: ""
        property bool justDragged: false
        readonly property bool inTrash: cwd === "trash://"
        readonly property string home: places.length > 0 ? places[0].path : ""
        readonly property int selCount: Object.keys(sel).length
        readonly property string q: search.text.trim()

        // ---- yardımcılar ----
        function g(cp) { return String.fromCodePoint(cp) }
        readonly property var gl: ({ back: g(0xF004D), fwd: g(0xF0054), up: g(0xF005D), refresh: g(0xF0450), search: g(0xF0349),
            folder: g(0xF024B), file: g(0xF0214), image: g(0xF021F), video: g(0xF022B), audio: g(0xF0223), doc: g(0xF0219), archive: g(0xF05C4),
            code: g(0xF0174), exec: g(0xF0493), home: g(0xF02DC), desk: g(0xF0379), down: g(0xF01DA), pics: g(0xF02E9), music: g(0xF075A),
            video2: g(0xF0381), drive: g(0xF129E), root: g(0xF02CA), trash: g(0xF01B4), link: g(0xF0337) })
        function kindGlyph(k) { return k === "dir" ? gl.folder : (gl[k] || gl.file) }
        function kindColor(k) {
            return k === "dir" ? Theme.accent : (k === "image" ? Theme.ok : (k === "video" ? "#c58af9" : (k === "audio" ? "#f2a65a" :
                   (k === "archive" ? Theme.warn : (k === "exec" ? Theme.bad : (k === "code" ? "#7ad0e0" : Theme.muted))))))
        }
        function placeGlyph(k) { return k === "video" ? gl.video2 : (gl[k] || gl.folder) }
        function sizeText(b) {
            if (b < 1024) return b + " B"
            const u = ["KB", "MB", "GB", "TB"]; let v = b / 1024, i = 0
            while (v >= 1024 && i < 3) { v /= 1024; i++ }
            return v.toFixed(v >= 100 ? 0 : 1) + " " + u[i]
        }
        function dateText(t) { return t > 0 ? Qt.formatDateTime(new Date(t * 1000), "dd.MM.yyyy HH:mm") : "" }
        function join(dir, name) { return dir === "/" ? "/" + name : dir + "/" + name }
        function parentOf(p) { const i = p.lastIndexOf("/"); return i <= 0 ? "/" : p.substring(0, i) }
        function say(t, bad) { note = t; noteBad = !!bad; noteTimer.restart() }
        function run(p) { p.running = false; p.running = true }
        function sync(m, arr) {
            for (let i = 0; i < arr.length; i++) { if (i < m.count) m.set(i, arr[i]); else m.append(arr[i]) }
            if (m.count > arr.length) m.remove(arr.length, m.count - arr.length)
        }
        function entryPath(r) { return inTrash ? r.ename : join(searching ? searchBase : cwd, r.ename) }
        function selectedRows() { return rows.filter(r => sel[r.ename]) }
        function isCut(r) { return clip.mode === "cut" && clip.paths.indexOf(join(searching ? searchBase : cwd, r.ename)) >= 0 }

        // ---- listeleme ----
        function parse(text) {
            const out = []
            text.split("\n").forEach(l => {
                const p = l.split("\t")
                if (inTrash) {
                    if (p.length >= 5) out.push({ etype: p[4], ename: p[0], edisp: p.length > 6 && p[6] !== "" ? p[6] : p[0], esize: parseInt(p[3]) || 0, emtime: Date.parse(p[2]) / 1000 || 0, ekind: p[4] === "d" ? "dir" : (p.length > 5 && p[5] !== "" ? p[5] : "file"), eflags: "-", eextra: p[1] })
                } else if (p.length >= 6) {
                    out.push({ etype: p[0], ename: p[1], edisp: p[1], esize: parseInt(p[2]) || 0, emtime: parseInt(p[3]) || 0, ekind: p[4], eflags: p[5], eextra: "" })
                }
            })
            return out
        }
        function rebuild() {
            const arr = parse(rawText)
            const dir = sortAsc ? 1 : -1
            arr.sort((a, b) => {
                if ((a.etype === "d") !== (b.etype === "d")) return a.etype === "d" ? -1 : 1
                let c = 0
                if (sortKey === "size") c = a.esize - b.esize
                else if (sortKey === "date") c = a.emtime - b.emtime
                if (c === 0) c = a.edisp.toLowerCase().localeCompare(b.edisp.toLowerCase())
                return c * dir
            })
            rows = arr
            const keep = {}
            arr.forEach(r => { if (sel[r.ename]) keep[r.ename] = true })
            if (Object.keys(keep).length !== Object.keys(sel).length) sel = keep
            sync(model, arr)
        }
        onSortKeyChanged: rebuild()
        onSortAscChanged: rebuild()
        function reload() {
            loading = true
            if (inTrash) listProc.command = ["schway-files", "trashlist"]
            else if (searching) listProc.command = ["schway-files", "search", searchBase, q].concat(showHidden ? ["--hidden"] : [])
            else listProc.command = ["schway-files", "list", cwd].concat(showHidden ? ["--hidden"] : [])
            run(listProc)
        }
        onShowHiddenChanged: if (cwd !== "") reload()
        function go(path, noHist) {
            if (path === "") return
            if (!noHist && cwd !== "" && cwd !== path) { backStack = backStack.concat([cwd]); fwdStack = [] }
            searching = false; search.text = ""; editPath = false
            sel = {}; anchorIdx = -1
            cwd = path
            reload()
        }
        function goBack() { if (backStack.length === 0) return; const p = backStack[backStack.length - 1]; fwdStack = fwdStack.concat([cwd]); backStack = backStack.slice(0, -1); go(p, true) }
        function goFwd() { if (fwdStack.length === 0) return; const p = fwdStack[fwdStack.length - 1]; backStack = backStack.concat([cwd]); fwdStack = fwdStack.slice(0, -1); go(p, true) }
        function goUp() { if (!inTrash && cwd !== "/") go(parentOf(cwd)) }
        function crumbs() {
            if (inTrash) return [{ label: "Çöp Kutusu", path: "trash://" }]
            const h = home
            let base = "", out = []
            if (h !== "" && (cwd === h || cwd.indexOf(h + "/") === 0)) { out.push({ label: "Ev", path: h }); base = h }
            else out.push({ label: "/", path: "/" })
            const rest = cwd.substring(base.length).split("/").filter(x => x !== "")
            let acc = base
            rest.forEach(s => { acc = acc + "/" + s; out.push({ label: s, path: acc }) })
            return out
        }
        function openRow(r) {
            if (inTrash) return
            const p = entryPath(r)
            if (r.etype === "d") go(p)
            else { actProc.command = ["schway-files", "open", p]; run(actProc) }
        }

        // ---- seçim ----
        function pick(i, mods) {
            const r = rows[i]; if (!r) return
            const n = {}
            if (mods & Qt.ShiftModifier && anchorIdx >= 0) {
                const a = Math.min(anchorIdx, i), b = Math.max(anchorIdx, i)
                for (let k = a; k <= b; k++) n[rows[k].ename] = true
            } else if (mods & Qt.ControlModifier) {
                Object.keys(sel).forEach(k => n[k] = true)
                if (n[r.ename]) delete n[r.ename]; else n[r.ename] = true
                anchorIdx = i
            } else { n[r.ename] = true; anchorIdx = i }
            sel = n
        }
        function selectAll() { const n = {}; rows.forEach(r => n[r.ename] = true); sel = n }

        // ---- işlemler ----
        function act(args, okMsg) { actProc.command = ["schway-files"].concat(args); actProc.okMsg = okMsg || ""; run(actProc) }
        function newFolder() { dlg = { kind: "name", title: "Yeni klasör", value: "Yeni klasör", fn: v => act(["mkdir", cwd, v]) } }
        function newFile() { dlg = { kind: "name", title: "Yeni dosya", value: "Yeni dosya.txt", fn: v => act(["newfile", cwd, v]) } }
        function renameSel() {
            const s = selectedRows(); if (s.length !== 1 || inTrash) return
            dlg = { kind: "name", title: "Yeniden adlandır", value: s[0].edisp, fn: v => act(["rename", entryPath(s[0]), v]) }
        }
        function copySel(cut) {
            const s = selectedRows(); if (s.length === 0 || inTrash) return
            clip = { mode: cut ? "cut" : "copy", paths: s.map(r => entryPath(r)) }
            say(s.length + " öğe " + (cut ? "kesildi" : "kopyalandı") + ": yapıştırmak için hedef klasörde “Yapıştır”.", false)
        }
        function paste() {
            if (clip.paths.length === 0 || inTrash || searching) return
            const mode = clip.mode === "cut" ? "move" : "copy"
            const paths = clip.paths
            if (clip.mode === "cut") clip = { mode: "", paths: [] }
            act([mode, cwd].concat(paths))
        }
        function trashSel() { const s = selectedRows(); if (s.length === 0 || inTrash) return; act(["trash"].concat(s.map(r => entryPath(r)))) }
        function deleteSel() {
            const s = selectedRows(); if (s.length === 0 || inTrash) return
            dlg = { kind: "confirm", danger: true, title: "Kalıcı sil", text: s.length === 1 ? "“" + s[0].edisp + "” kalıcı olarak silinecek. Bu geri alınamaz." : s.length + " öğe kalıcı olarak silinecek. Bu geri alınamaz.", fn: () => act(["delete"].concat(s.map(r => entryPath(r)))) }
        }
        function restoreSel() { const s = selectedRows(); if (s.length > 0 && inTrash) act(["restore"].concat(s.map(r => r.ename))) }
        function emptyTrash() { dlg = { kind: "confirm", danger: true, title: "Çöpü boşalt", text: "Çöp kutusundaki her şey kalıcı olarak silinecek.", fn: () => act(["trashempty"]) } }
        function doSearch() {
            if (q.length < 1 || inTrash) { if (searching) { searching = false; reload() } return }
            if (!searching) searchBase = cwd
            searching = true; sel = {}; reload()
        }

        // ---- önizleme ----
        function updatePreview() {
            if (!previewOn) return
            const s = selectedRows()
            if (s.length !== 1) { prev = { kind: s.length > 1 ? "multi" : "none", count: s.length }; prevText = ""; prevPath = ""; return }
            const r = s[0]
            if (inTrash) { prev = { kind: "trash", cins: r.ekind, size: r.esize, modified: r.emtime, detail: "özgün yer: " + r.eextra, name: r.edisp }; prevText = ""; prevPath = ""; return }
            prevPath = entryPath(r)
            prevProc.command = ["schway-files", "preview", prevPath]
            run(prevProc)
        }
        onSelChanged: previewTimer.restart()
        onPreviewOnChanged: updatePreview()
        function parsePreview(text) {
            const i = text.indexOf("@@\n")
            const head = i >= 0 ? text.substring(0, i) : text
            const o = {}
            head.split("\n").forEach(l => { const k = l.indexOf("="); if (k > 0) o[l.substring(0, k)] = l.substring(k + 1) })
            o.size = parseInt(o.size) || 0; o.modified = parseInt(o.modified) || 0
            prevText = i >= 0 ? text.substring(i + 3).replace(/\n$/, "") : ""
            prev = o
        }

        // ---- sağ tık menüsü ----
        function openMenu(x, y, idx) {
            if (idx >= 0 && !sel[rows[idx].ename]) { const n = {}; n[rows[idx].ename] = true; sel = n; anchorIdx = idx }
            const it = [], one = selCount === 1
            if (inTrash) {
                if (idx >= 0) it.push({ id: "restore", label: "Geri yükle" })
                it.push({ id: "emptyTrash", label: "Çöpü boşalt", danger: true, dim: rows.length === 0 })
                if (idx >= 0) it.push({ sep: true }, { id: "preview", label: previewOn ? "Önizlemeyi kapat" : "Önizleme" })
            } else if (idx >= 0) {
                if (one) it.push({ id: "open", label: rows[idx].etype === "d" ? "Aç" : "Varsayılan uygulamayla aç" }, { sep: true })
                it.push({ id: "cut", label: "Kes" }, { id: "copy", label: "Kopyala" }, { id: "paste", label: "Yapıştır", dim: clip.paths.length === 0 || searching })
                if (one) it.push({ id: "rename", label: "Yeniden adlandır" })
                it.push({ sep: true }, { id: "trash", label: "Çöpe at", danger: true }, { id: "delete", label: "Kalıcı sil…", danger: true },
                        { sep: true }, { id: "preview", label: previewOn ? "Önizlemeyi kapat" : "Önizleme" })
            } else {
                it.push({ id: "paste", label: "Yapıştır", dim: clip.paths.length === 0 || searching }, { id: "newFolder", label: "Yeni klasör", dim: searching },
                        { id: "newFile", label: "Yeni dosya", dim: searching }, { sep: true },
                        { id: "hidden", label: showHidden ? "Gizli dosyaları gizle" : "Gizli dosyaları göster" }, { id: "refresh", label: "Yenile" },
                        { id: "preview", label: previewOn ? "Önizlemeyi kapat" : "Önizleme" })
            }
            const h = it.reduce((a, m) => a + (m.sep ? 9 : 32), 12)
            menu = { x: Math.max(4, Math.min(x, keys.width - 224)), y: Math.max(4, Math.min(y, keys.height - h - 4)), items: it }
        }
        function menuAction(id) {
            menu = null
            if (id === "open") { const s = selectedRows(); if (s.length === 1) openRow(s[0]) }
            else if (id === "cut") copySel(true)
            else if (id === "copy") copySel(false)
            else if (id === "paste") paste()
            else if (id === "rename") renameSel()
            else if (id === "trash") trashSel()
            else if (id === "delete") deleteSel()
            else if (id === "restore") restoreSel()
            else if (id === "emptyTrash") emptyTrash()
            else if (id === "newFolder") newFolder()
            else if (id === "newFile") newFile()
            else if (id === "hidden") showHidden = !showHidden
            else if (id === "refresh") reload()
            else if (id === "preview") previewOn = !previewOn
        }

        // ---- sürükle-bırak ----
        function beginDrag(i) {
            const r = rows[i]
            if (!sel[r.ename]) { const n = {}; n[r.ename] = true; sel = n; anchorIdx = i }
            dragProxy.label = selCount === 1 ? r.edisp : selCount + " öğe"
            dragging = true
        }
        function endDrag(mods) {
            dragCopy = !!(mods & Qt.ControlModifier)
            dragProxy.Drag.drop()                  // hedef DropArea.onDropped -> dropTo()
            dragging = false; dropHover = ""
            justDragged = true; dragGuard.restart()
        }
        function dropTo(dest) {
            if (selCount === 0 || inTrash) return
            const paths = selectedRows().map(r => entryPath(r))
            if (dest === "trash://") act(["trash"].concat(paths))
            else act([dragCopy ? "copy" : "move", dest].concat(paths))
        }

        ListModel { id: model }
        Process { id: prevProc
            stdout: StdioCollector { onStreamFinished: win.parsePreview(text) }
            stderr: StdioCollector { id: prevErr }
            onExited: (code, status) => { if (code !== 0) { win.prev = { kind: "other", detail: prevErr.text.trim() || "önizlenemiyor" }; win.prevText = "" } } }
        Timer { id: previewTimer; interval: 160; onTriggered: win.updatePreview() }
        Timer { id: dragGuard; interval: 200; onTriggered: win.justDragged = false }

        Process { id: placesProc; command: ["schway-files", "places"]
            stdout: StdioCollector { onStreamFinished: {
                const out = []
                text.split("\n").forEach(l => { const p = l.split("\t"); if (p.length >= 3) out.push({ kind: p[0], label: p[1], path: p[2] }) })
                win.places = out
                if (win.cwd === "" && out.length > 0) { const s = win.startPath !== "" ? win.startPath : Quickshell.env("SCHWAY_FILES_START"); win.go(s && s !== "" ? s : out[0].path, true) }
            } } }
        Process { id: listProc
            stdout: StdioCollector { id: listOut; onStreamFinished: { win.loading = false; win.rawText = text; win.rebuild() } }
            stderr: StdioCollector { id: listErr }
            onExited: (code, status) => { if (code !== 0) { win.loading = false; win.rawText = ""; win.rebuild(); win.say(listErr.text.trim() || "Klasör açılamadı.", true) } } }
        Process { id: actProc
            property string okMsg: ""
            stdout: StdioCollector { id: actOut }
            stderr: StdioCollector { id: actErr }
            onExited: (code, status) => {
                win.say(code === 0 ? (actProc.okMsg !== "" ? actProc.okMsg : actOut.text.trim()) : (actErr.text.trim() || "İşlem başarısız."), code !== 0)
                win.dlg = null
                win.reload(); win.run(placesProc)
            } }
        Timer { id: noteTimer; interval: 7000; onTriggered: win.note = "" }
        Timer { id: searchTimer; interval: 450; onTriggered: win.doSearch() }
        Component.onCompleted: run(placesProc)

        // ---- ortak parçalar ----
        component Btn: Rectangle {
            id: b
            property string text: ""
            property string icon: ""
            property bool primary: false
            property bool danger: false
            property bool dim: false
            signal clicked()
            implicitWidth: row.implicitWidth + 24
            implicitHeight: 32
            radius: Theme.rCtl
            opacity: dim ? 0.38 : 1
            color: primary ? (ma.containsMouse && !dim ? Theme.accentDark : Theme.accent)
                 : (danger ? (ma.containsMouse && !dim ? Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.30) : Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.18))
                 : (ma.containsMouse && !dim ? Theme.press : Theme.hover))
            Row { id: row; anchors.centerIn: parent; spacing: 7
                Text { visible: b.icon !== ""; anchors.verticalCenter: parent.verticalCenter; text: b.icon; font.family: Theme.iconFont; font.pixelSize: 15
                       color: b.primary ? Theme.onAccent : (b.danger ? Theme.bad : Theme.text) }
                Text { visible: b.text !== ""; anchors.verticalCenter: parent.verticalCenter; text: b.text; font.family: Theme.font; font.pixelSize: 13; font.weight: Font.Medium
                       color: b.primary ? Theme.onAccent : (b.danger ? Theme.bad : Theme.text) }
            }
            MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: dim ? Qt.ArrowCursor : Qt.PointingHandCursor; onClicked: if (!b.dim) b.clicked() }
        }
        component Sw: Rectangle {
            id: s
            property bool on: false
            signal toggled(bool v)
            implicitWidth: 38; implicitHeight: 22; radius: 11
            color: on ? Theme.accent : Theme.track
            Rectangle { y: 3; x: s.on ? 19 : 3; width: 16; height: 16; radius: 8; color: s.on ? Theme.onAccent : Theme.muted; Behavior on x { NumberAnimation { duration: 110 } } }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: s.toggled(!s.on) }
        }

        // ---- yerleşim ----
        FocusScope {
            id: keys
            anchors.fill: parent
            focus: true
            Keys.onPressed: event => {
                const ctrl = event.modifiers & Qt.ControlModifier, shift = event.modifiers & Qt.ShiftModifier
                if (win.dlg) { if (event.key === Qt.Key_Escape) { win.dlg = null; event.accepted = true } return }
                if (win.menu) { if (event.key === Qt.Key_Escape) { win.menu = null; event.accepted = true } return }
                if (ctrl && event.key === Qt.Key_C) win.copySel(false)
                else if (ctrl && event.key === Qt.Key_X) win.copySel(true)
                else if (ctrl && event.key === Qt.Key_V) win.paste()
                else if (ctrl && event.key === Qt.Key_A) win.selectAll()
                else if (ctrl && event.key === Qt.Key_H) win.showHidden = !win.showHidden
                else if (ctrl && event.key === Qt.Key_L) { win.editPath = true; pathEdit.forceActiveFocus() }
                else if (ctrl && event.key === Qt.Key_F) search.forceActiveFocus()
                else if (ctrl && shift && event.key === Qt.Key_N) win.newFolder()
                else if (event.key === Qt.Key_Delete) { if (shift) win.deleteSel(); else win.trashSel() }
                else if (event.key === Qt.Key_Space) win.previewOn = !win.previewOn
                else if (event.key === Qt.Key_F2) win.renameSel()
                else if (event.key === Qt.Key_F5) win.reload()
                else if (event.key === Qt.Key_Backspace) win.goUp()
                else if ((event.modifiers & Qt.AltModifier) && event.key === Qt.Key_Left) win.goBack()
                else if ((event.modifiers & Qt.AltModifier) && event.key === Qt.Key_Right) win.goFwd()
                else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) { const s = win.selectedRows(); if (s.length === 1) win.openRow(s[0]) }
                else if (event.key === Qt.Key_Escape) { win.sel = {}; if (win.searching) { search.text = ""; win.doSearch() } }
                else return
                event.accepted = true
            }

            RowLayout {
                anchors.fill: parent
                spacing: 0

                // ---------- yerler ----------
                Rectangle {
                    Layout.preferredWidth: 212; Layout.fillHeight: true
                    color: Theme.well
                    Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.line }
                    Flickable {
                        anchors { fill: parent; topMargin: 14; bottomMargin: 10; leftMargin: 10; rightMargin: 10 }
                        contentHeight: pcol.implicitHeight; clip: true
                        Column {
                            id: pcol
                            width: parent.width; spacing: 2
                            Text { text: "Yerler"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Medium; padding: 6; leftPadding: 8 }
                            Repeater {
                                model: win.places
                                delegate: Rectangle {
                                    id: pi
                                    required property var modelData
                                    required property int index
                                    readonly property bool active: win.cwd === modelData.path
                                    objectName: "place_" + modelData.label
                                    width: pcol.width; height: 36; radius: Theme.rCtl
                                    color: active ? Theme.accentSoft : (pma.containsMouse || pdrop.containsDrag ? Theme.hover : "transparent")
                                    border.width: pdrop.containsDrag ? 2 : 0; border.color: Theme.accent
                                    DropArea { id: pdrop; anchors.fill: parent; enabled: pi.modelData.kind !== "root"; onDropped: win.dropTo(pi.modelData.path) }
                                    Row { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } spacing: 10
                                        Text { width: 20; horizontalAlignment: Text.AlignHCenter; anchors.verticalCenter: parent.verticalCenter; text: win.placeGlyph(pi.modelData.kind); font.family: Theme.iconFont; font.pixelSize: 16
                                               color: pi.active ? Theme.accentDark : (pi.modelData.kind === "drive" ? Theme.ok : Theme.muted) }
                                        Text { anchors.verticalCenter: parent.verticalCenter; width: pi.width - 60; elide: Text.ElideRight; text: pi.modelData.label; font.family: Theme.font; font.pixelSize: 14
                                               font.weight: pi.active ? Font.Medium : Font.Normal; color: pi.active ? Theme.text : Theme.muted }
                                    }
                                    MouseArea { id: pma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: { win.go(pi.modelData.path); keys.forceActiveFocus() } }
                                }
                            }
                        }
                    }
                }

                // ---------- ana alan ----------
                ColumnLayout {
                    Layout.fillWidth: true; Layout.fillHeight: true
                    Layout.margins: 16
                    spacing: 10

                    RowLayout {
                        Layout.fillWidth: true; spacing: 8
                        Btn { icon: win.gl.back; dim: win.backStack.length === 0; onClicked: win.goBack() }
                        Btn { icon: win.gl.fwd; dim: win.fwdStack.length === 0; onClicked: win.goFwd() }
                        Btn { icon: win.gl.up; dim: win.inTrash || win.cwd === "/"; onClicked: win.goUp() }
                        Btn { icon: win.gl.refresh; onClicked: win.reload() }
                        Rectangle {
                            Layout.fillWidth: true; Layout.preferredHeight: 32
                            radius: Theme.rCtl; color: Theme.well; border.width: 1; border.color: win.editPath ? Theme.accentEdge : Theme.border; clip: true
                            Row {
                                visible: !win.editPath
                                anchors { left: parent.left; leftMargin: 8; verticalCenter: parent.verticalCenter }
                                spacing: 2
                                Repeater {
                                    model: win.crumbs()
                                    delegate: Row {
                                        required property var modelData
                                        required property int index
                                        spacing: 2
                                        Text { visible: index > 0; anchors.verticalCenter: parent.verticalCenter; text: "›"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 14 }
                                        Rectangle {
                                            height: 24; width: cl.implicitWidth + 14; radius: 6; anchors.verticalCenter: parent.verticalCenter
                                            color: cma.containsMouse ? Theme.hover : "transparent"
                                            Text { id: cl; anchors.centerIn: parent; text: modelData.label; color: Theme.text; font.family: Theme.font; font.pixelSize: 13 }
                                            MouseArea { id: cma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.go(modelData.path) }
                                        }
                                    }
                                }
                            }
                            MouseArea { anchors.fill: parent; z: -1; visible: !win.editPath; onClicked: { win.editPath = true; pathEdit.text = win.cwd; pathEdit.forceActiveFocus(); pathEdit.selectAll() } }
                            TextInput {
                                id: pathEdit
                                visible: win.editPath
                                anchors { left: parent.left; right: parent.right; margins: 12; verticalCenter: parent.verticalCenter }
                                color: Theme.text; font.family: Theme.font; font.pixelSize: 13; clip: true; selectByMouse: true
                                selectionColor: Theme.accent; selectedTextColor: Theme.onAccent
                                onAccepted: { win.go(text.trim()); keys.forceActiveFocus() }
                                Keys.onEscapePressed: { win.editPath = false; keys.forceActiveFocus() }
                                onActiveFocusChanged: if (!activeFocus) win.editPath = false
                            }
                        }
                        Rectangle {
                            Layout.preferredWidth: 220; Layout.preferredHeight: 32
                            radius: Theme.rCtl; color: Theme.well; border.width: 1; border.color: search.activeFocus ? Theme.accentEdge : Theme.border
                            Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } text: win.gl.search; font.family: Theme.iconFont; font.pixelSize: 15; color: Theme.faint }
                            TextInput {
                                id: search
                                anchors { left: parent.left; leftMargin: 32; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                                color: Theme.text; font.family: Theme.font; font.pixelSize: 13; clip: true; selectByMouse: true
                                onTextChanged: searchTimer.restart()
                                Keys.onEscapePressed: { text = ""; keys.forceActiveFocus() }
                                Text { visible: search.text === "" && !search.activeFocus; text: win.inTrash ? "Çöpte arama yok" : "Bu klasörde ara…"; color: Theme.faint; font: search.font }
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true; spacing: 6
                        Btn { text: "Yeni klasör"; icon: win.g(0xF0257); dim: win.inTrash || win.searching; onClicked: win.newFolder() }
                        Btn { text: "Yeni dosya"; icon: win.g(0xF0224); dim: win.inTrash || win.searching; onClicked: win.newFile() }
                        Rectangle { width: 1; height: 20; color: Theme.line }
                        Btn { text: "Kes"; icon: win.g(0xF0190); dim: win.selCount === 0 || win.inTrash; onClicked: win.copySel(true) }
                        Btn { text: "Kopyala"; icon: win.g(0xF018F); dim: win.selCount === 0 || win.inTrash; onClicked: win.copySel(false) }
                        Btn { text: "Yapıştır"; icon: win.g(0xF0192); dim: win.clip.paths.length === 0 || win.inTrash || win.searching; onClicked: win.paste() }
                        Btn { text: "Yeniden adlandır"; icon: win.g(0xF03EB); dim: win.selCount !== 1 || win.inTrash; onClicked: win.renameSel() }
                        Btn { visible: !win.inTrash; text: "Çöpe at"; icon: win.gl.trash; danger: true; dim: win.selCount === 0; onClicked: win.trashSel() }
                        Btn { visible: win.inTrash; text: "Geri yükle"; icon: win.g(0xF099B); primary: true; dim: win.selCount === 0; onClicked: win.restoreSel() }
                        Btn { visible: win.inTrash; text: "Çöpü boşalt"; icon: win.gl.trash; danger: true; dim: win.rows.length === 0; onClicked: win.emptyTrash() }
                        Item { Layout.fillWidth: true }
                        Btn { text: "Önizleme"; icon: win.g(0xF0208); primary: win.previewOn; onClicked: win.previewOn = !win.previewOn }
                        Text { text: "Gizli dosyalar"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; visible: !win.inTrash }
                        Sw { visible: !win.inTrash; on: win.showHidden; onToggled: v => win.showHidden = v }
                    }

                    RowLayout {
                      Layout.fillWidth: true; Layout.fillHeight: true; spacing: 10
                    Rectangle {
                        Layout.fillWidth: true; Layout.fillHeight: true
                        radius: Theme.rGroup; color: Theme.surface; border.width: 1; border.color: Theme.line; clip: true
                        MouseArea { anchors.fill: parent; acceptedButtons: Qt.RightButton
                                    onClicked: mouse => { const p = mapToItem(keys, mouse.x, mouse.y); win.openMenu(p.x, p.y, -1) } }
                        ColumnLayout {
                            anchors.fill: parent; spacing: 0
                            RowLayout {
                                Layout.fillWidth: true; Layout.leftMargin: 18; Layout.rightMargin: 18; Layout.topMargin: 8; Layout.bottomMargin: 4
                                spacing: 0
                                Repeater {
                                    model: [["name", "Ad", 0], ["size", "Boyut", 100], ["date", win.inTrash ? "Silinme" : "Değiştirilme", 150]]
                                    delegate: Item {
                                        required property var modelData
                                        Layout.fillWidth: modelData[2] === 0
                                        Layout.preferredWidth: modelData[2]
                                        implicitHeight: 22
                                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                                               text: modelData[1] + (win.sortKey === modelData[0] ? (win.sortAsc ? "  ▲" : "  ▼") : "")
                                               color: win.sortKey === modelData[0] ? Theme.accentDark : Theme.faint; font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Medium }
                                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                            onClicked: { if (win.sortKey === modelData[0]) win.sortAsc = !win.sortAsc; else { win.sortKey = modelData[0]; win.sortAsc = modelData[0] === "name" } } }
                                    }
                                }
                            }
                            Rectangle { Layout.fillWidth: true; height: 1; color: Theme.line }
                            ListView {
                                id: fl
                                Layout.fillWidth: true; Layout.fillHeight: true
                                Layout.margins: 4
                                model: model
                                clip: true
                                boundsBehavior: Flickable.StopAtBounds
                                delegate: Rectangle {
                                    id: fr
                                    required property int index
                                    required property string etype
                                    required property string ename
                                    required property string edisp
                                    required property real esize
                                    required property real emtime
                                    required property string ekind
                                    required property string eflags
                                    required property string eextra
                                    readonly property bool on: !!win.sel[ename]
                                    objectName: "row_" + ename
                                    width: fl.width; height: 38; radius: Theme.rCtl
                                    opacity: win.isCut({ ename: ename }) ? 0.45 : 1
                                    color: rdrop.containsDrag ? Theme.accentSoft : (on ? Theme.accentSoft : (fma.containsMouse ? Theme.hover : "transparent"))
                                    border.width: rdrop.containsDrag ? 2 : 0; border.color: Theme.accent
                                    DropArea { id: rdrop; anchors.fill: parent; enabled: fr.etype === "d" && !fr.on && !win.inTrash
                                               onDropped: win.dropTo(win.entryPath({ ename: fr.ename })) }
                                    RowLayout {
                                        anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                                        spacing: 0
                                        RowLayout {
                                            Layout.fillWidth: true; spacing: 12
                                            Item { Layout.preferredWidth: 26; Layout.preferredHeight: 26
                                                Text { anchors.centerIn: parent; text: win.kindGlyph(fr.ekind); font.family: Theme.iconFont; font.pixelSize: 20; color: win.kindColor(fr.ekind) }
                                                Text { visible: fr.eflags.indexOf("l") >= 0; anchors { right: parent.right; bottom: parent.bottom; rightMargin: -3; bottomMargin: -3 } text: win.gl.link; font.family: Theme.iconFont; font.pixelSize: 10; color: Theme.text }
                                            }
                                            Column { Layout.fillWidth: true; spacing: 0
                                                Text { width: parent.width; elide: Text.ElideMiddle; text: fr.edisp; color: fr.eflags.indexOf("h") >= 0 ? Theme.muted : Theme.text; font.family: Theme.font; font.pixelSize: 14 }
                                                Text { visible: fr.eextra !== ""; width: parent.width; elide: Text.ElideMiddle; text: "özgün yer: " + fr.eextra; color: Theme.faint; font.family: Theme.font; font.pixelSize: 11 }
                                            }
                                        }
                                        Text { Layout.preferredWidth: 100; text: fr.etype === "d" ? "—" : win.sizeText(fr.esize); color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                        Text { Layout.preferredWidth: 150; text: win.dateText(fr.emtime); color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                    }
                                    MouseArea { id: fma; anchors.fill: parent; hoverEnabled: true; preventStealing: true
                                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                                        property real px: 0
                                        property real py: 0
                                        onPressed: mouse => { px = mouse.x; py = mouse.y }
                                        onPositionChanged: mouse => {
                                            if (pressed && (fma.pressedButtons & Qt.LeftButton) && !win.inTrash && (win.dragging || Math.abs(mouse.x - px) + Math.abs(mouse.y - py) > 12)) {
                                                if (!win.dragging) win.beginDrag(fr.index)
                                                const p = fma.mapToItem(keys, mouse.x, mouse.y)
                                                dragProxy.x = p.x + 14; dragProxy.y = p.y + 14
                                            }
                                        }
                                        onReleased: mouse => { if (win.dragging) win.endDrag(mouse.modifiers) }
                                        onClicked: mouse => {
                                            if (win.justDragged) return
                                            if (mouse.button === Qt.RightButton) { const p = fma.mapToItem(keys, mouse.x, mouse.y); win.openMenu(p.x, p.y, fr.index) }
                                            else { win.pick(fr.index, mouse.modifiers); keys.forceActiveFocus() }
                                        }
                                        onDoubleClicked: mouse => { if (mouse.button === Qt.LeftButton) win.openRow(win.rows[fr.index]) } }
                                }
                                MouseArea { anchors.fill: parent; z: -1; onClicked: { win.sel = {}; keys.forceActiveFocus() } }
                            }
                        }
                        Column {
                            anchors.centerIn: parent; spacing: 6
                            visible: win.rows.length === 0 && !win.loading
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: win.inTrash ? win.gl.trash : (win.searching ? win.gl.search : win.gl.folder); font.family: Theme.iconFont; font.pixelSize: 42; color: Theme.track }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: win.inTrash ? "Çöp kutusu boş" : (win.searching ? "“" + win.q + "” için sonuç yok" : "Bu klasör boş"); color: Theme.muted; font.family: Theme.font; font.pixelSize: 14 }
                        }
                    }

                    Rectangle {   // önizleme paneli
                        visible: win.previewOn
                        Layout.preferredWidth: 300; Layout.fillHeight: true
                        radius: Theme.rGroup; color: Theme.surface; border.width: 1; border.color: Theme.line; clip: true
                        ColumnLayout {
                            anchors { fill: parent; margins: 16 }
                            spacing: 10
                            Text { visible: win.prev.kind === "none" || win.prev.kind === "multi"; Layout.fillWidth: true; Layout.topMargin: 40; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
                                   text: win.prev.kind === "multi" ? win.prev.count + " öğe seçili" : "Önizlemek için bir öğe seç"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 14 }
                            Item {
                                visible: win.prev.kind === "image"
                                Layout.fillWidth: true; Layout.preferredHeight: 190
                                Rectangle { anchors.fill: parent; radius: Theme.rCtl; color: Theme.well }
                                Image { anchors { fill: parent; margins: 4 } source: win.prev.kind === "image" ? "file://" + win.prevPath : ""
                                        fillMode: Image.PreserveAspectFit; asynchronous: true; sourceSize.width: 560; sourceSize.height: 380 }
                            }
                            Text { visible: win.prev.kind === "dir" || win.prev.kind === "binary" || win.prev.kind === "other" || win.prev.kind === "trash"
                                   Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 6
                                   text: win.kindGlyph(win.prev.cins || "file"); color: win.kindColor(win.prev.cins || "file"); font.family: Theme.iconFont; font.pixelSize: 56 }
                            Text { visible: win.prev.kind !== "none" && win.prev.kind !== "multi"; Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; maximumLineCount: 3; elide: Text.ElideRight
                                   text: win.prev.kind === "trash" ? win.prev.name : (win.prevPath !== "" ? win.prevPath.substring(win.prevPath.lastIndexOf("/") + 1) : "")
                                   color: Theme.text; font.family: Theme.font; font.pixelSize: 15; font.weight: Font.Medium }
                            Column {
                                visible: win.prev.kind !== "none" && win.prev.kind !== "multi"; Layout.fillWidth: true; spacing: 3
                                Text { visible: win.prev.kind !== "dir"; text: "Boyut: " + win.sizeText(win.prev.size || 0); color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                                Text { text: (win.prev.kind === "trash" ? "Silinme: " : "Değiştirilme: ") + win.dateText(win.prev.modified || 0); color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                                Text { visible: !!win.prev.detail; width: parent.width; wrapMode: Text.WrapAnywhere; text: win.prev.detail || ""; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                            }
                            Rectangle {
                                visible: win.prev.kind === "text"
                                Layout.fillWidth: true; Layout.fillHeight: true
                                radius: Theme.rCtl; color: Theme.well; clip: true
                                Text { anchors { fill: parent; margins: 10 } text: win.prevText === "" ? "(boş dosya)" : win.prevText; color: Theme.muted; font.family: Theme.mono; font.pixelSize: 11; wrapMode: Text.NoWrap; lineHeight: 1.2 }
                            }
                            Item { visible: win.prev.kind !== "text"; Layout.fillHeight: true }
                        }
                    }
                    }

                    RowLayout {
                        Layout.fillWidth: true; spacing: 10
                        Text { text: win.rows.length + " öğe" + (win.searching ? " (arama)" : "") + (win.selCount > 0 ? " · " + win.selCount + " seçili" : ""); color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                        Text { visible: win.clip.paths.length > 0; text: "· panoda " + win.clip.paths.length + " öğe (" + (win.clip.mode === "cut" ? "kesildi" : "kopyalandı") + ")"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 13 }
                        Item { Layout.fillWidth: true }
                        Text { visible: win.note !== ""; text: win.note; color: win.noteBad ? Theme.bad : Theme.ok; font.family: Theme.font; font.pixelSize: 13; elide: Text.ElideRight; Layout.maximumWidth: 520 }
                    }
                }
            }

            // ---------- sürüklenen öğenin gösterimi ----------
            Rectangle {
                id: dragProxy
                property string label: ""
                visible: win.dragging
                z: 200
                width: dlab.implicitWidth + 28; height: 30; radius: 8
                color: Theme.accent; opacity: 0.92
                Drag.active: win.dragging
                Drag.dragType: Drag.Internal
                Drag.hotSpot.x: -14
                Drag.hotSpot.y: -14
                Drag.supportedActions: Qt.CopyAction | Qt.MoveAction
                Text { id: dlab; anchors.centerIn: parent; text: dragProxy.label; color: Theme.onAccent; font.family: Theme.font; font.pixelSize: 13; font.weight: Font.Medium }
            }

            // ---------- sağ tık menüsü ----------
            MouseArea {
                anchors.fill: parent; z: 150
                visible: win.menu !== null
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: win.menu = null
                Rectangle {
                    x: win.menu ? win.menu.x : 0; y: win.menu ? win.menu.y : 0
                    width: 220; implicitHeight: mcol.implicitHeight + 12; height: implicitHeight
                    radius: Theme.rCtl + 2; color: Qt.rgba(Theme.base.r, Theme.base.g, Theme.base.b, 1); border.width: 1; border.color: Theme.border
                    MouseArea { anchors.fill: parent }
                    Column {
                        id: mcol
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
                        Repeater {
                            model: win.menu ? win.menu.items : []
                            delegate: Item {
                                id: mi
                                required property var modelData
                                width: mcol.width; height: modelData.sep ? 9 : 32
                                Rectangle { visible: !!mi.modelData.sep; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 6; rightMargin: 6 } height: 1; color: Theme.line }
                                Rectangle {
                                    visible: !mi.modelData.sep; anchors.fill: parent; radius: Theme.rSm + 2
                                    objectName: mi.modelData.sep ? "" : "menu_" + mi.modelData.id
                                    color: mia.containsMouse && !mi.modelData.dim ? Theme.hover : "transparent"
                                    opacity: mi.modelData.dim ? 0.4 : 1
                                    Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } text: mi.modelData.label || ""
                                           color: mi.modelData.danger ? Theme.bad : Theme.text; font.family: Theme.font; font.pixelSize: 13 }
                                    MouseArea { id: mia; anchors.fill: parent; hoverEnabled: true; cursorShape: mi.modelData.dim ? Qt.ArrowCursor : Qt.PointingHandCursor
                                                onClicked: if (!mi.modelData.dim) win.menuAction(mi.modelData.id) }
                                }
                            }
                        }
                    }
                }
            }

            // ---------- iletişim kutusu ----------
            Rectangle {
                anchors.fill: parent
                visible: win.dlg !== null
                color: Theme.scrim
                MouseArea { anchors.fill: parent }
                Rectangle {
                    anchors.centerIn: parent
                    width: 440; implicitHeight: dcol.implicitHeight + 40; height: implicitHeight
                    radius: Theme.rWin; color: Qt.rgba(Theme.base.r, Theme.base.g, Theme.base.b, 1); border.width: 1; border.color: Theme.border
                    ColumnLayout {
                        id: dcol
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
                        spacing: 14
                        Text { text: win.dlg ? win.dlg.title : ""; color: Theme.text; font.family: Theme.font; font.pixelSize: 17; font.weight: Font.Medium }
                        Text { visible: win.dlg && win.dlg.kind === "confirm"; Layout.fillWidth: true; wrapMode: Text.Wrap; text: win.dlg && win.dlg.text ? win.dlg.text : ""; color: Theme.muted; font.family: Theme.font; font.pixelSize: 14; lineHeight: 1.25 }
                        Rectangle {
                            visible: win.dlg && win.dlg.kind === "name"
                            Layout.fillWidth: true; Layout.preferredHeight: 38
                            radius: Theme.rCtl; color: Theme.well; border.width: 1; border.color: Theme.accentEdge
                            TextInput {
                                id: nameIn
                                anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                                verticalAlignment: TextInput.AlignVCenter
                                color: Theme.text; font.family: Theme.font; font.pixelSize: 14; selectByMouse: true; clip: true
                                selectionColor: Theme.accent; selectedTextColor: Theme.onAccent
                                text: win.dlg && win.dlg.value ? win.dlg.value : ""
                                onVisibleChanged: if (visible) { forceActiveFocus(); const i = text.lastIndexOf("."); if (i > 0) select(0, i); else selectAll() }
                                onAccepted: okBtn.clicked()
                                Keys.onEscapePressed: win.dlg = null
                            }
                        }
                        RowLayout {
                            Layout.alignment: Qt.AlignRight; spacing: 8
                            Btn { text: "Vazgeç"; onClicked: { win.dlg = null; keys.forceActiveFocus() } }
                            Btn { id: okBtn; text: win.dlg && win.dlg.kind === "confirm" ? "Evet, devam et" : "Tamam"
                                  primary: !(win.dlg && win.dlg.danger); danger: win.dlg ? !!win.dlg.danger : false
                                  onClicked: { const d = win.dlg; if (!d) return; if (d.kind === "name") { const v = nameIn.text.trim(); if (v === "") return; d.fn(v) } else { win.dlg = null; d.fn() } } }
                        }
                    }
                }
            }
        }
    }
}
