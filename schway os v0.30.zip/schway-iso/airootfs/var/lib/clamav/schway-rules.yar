// Schway: ek YARA kuralları (ClamAV, DatabaseDirectory içindeki .yar dosyalarını otomatik yükler).
// Kendi kuralını aynı dizine (/var/lib/clamav) .yar uzantısıyla koyabilirsin.
// Kurallar bilerek az, özgül ve tutucu: yanlış alarm vermemek için tek bir ipucuna değil, birlikte görülen ipuçlarına bakar.
// ClamAV YARA'nın yalnızca bir alt kümesini destekler (modül yok); burada yalnızca metin dizgisi + "N of them" kullanılır.

rule Schway_Miner_XMRig
{
    meta:
        description = "XMRig tarzı kripto madenci"
    strings:
        $a = "xmrig" nocase ascii
        $b = "stratum+tcp://" ascii
        $c = "donate-level" nocase ascii
    condition:
        2 of them
}

rule Schway_Miner_Config
{
    meta:
        description = "Madencilik havuzu ayarı (stratum + cüzdan algoritması)"
    strings:
        $a = "stratum+tcp://" ascii
        $b = "cryptonight" nocase ascii
        $c = "randomx" nocase ascii
        $d = "\"algo\"" ascii
    condition:
        $a and 2 of ($b, $c, $d)
}

rule Schway_Script_ReverseShell
{
    meta:
        description = "Bash ters kabuk (reverse shell) kalıbı"
    strings:
        $a = "bash -i >& /dev/tcp/" ascii
        $b = "0>&1" ascii
        $c = "/dev/tcp/" ascii
        $d = "exec 5<>/dev/tcp/" ascii
    condition:
        ($a and $b) or ($d and $c)
}

rule Schway_Script_PipeToShell_Cron
{
    meta:
        description = "Kalıcılık için cron'a indirip çalıştıran satır ekleyen betik"
    strings:
        $a = "crontab" ascii
        $b = "| sh" ascii
        $c = "| bash" ascii
        $d = "curl -s" ascii
        $e = "wget -q" ascii
    condition:
        $a and ($b or $c) and ($d or $e)
}

rule Schway_Ransom_Note
{
    meta:
        description = "Fidye yazılımı notu metni"
    strings:
        $a = "your files have been encrypted" nocase ascii
        $b = "your files are encrypted" nocase ascii
        $c = "bitcoin" nocase ascii
        $d = "decrypt" nocase ascii
        $e = "private key" nocase ascii
    condition:
        ($a or $b) and $c and ($d or $e)
}

rule Schway_PS_EncodedDownloader
{
    meta:
        description = "Gizli pencereli, kodlanmış PowerShell indirici bayrakları"
    strings:
        $a = "-WindowStyle Hidden" nocase ascii wide
        $b = "-NoProfile" nocase ascii wide
        $c = "-EncodedCommand" nocase ascii wide
        $d = "DownloadString(" nocase ascii wide
        $e = "IEX" ascii wide
    condition:
        $a and $c and ($d or $e or $b)
}

rule Schway_Mimikatz
{
    meta:
        description = "Mimikatz kimlik bilgisi çalma aracı"
    strings:
        $a = "sekurlsa::logonpasswords" nocase ascii wide
        $b = "mimikatz" nocase ascii wide
        $c = "gentilkiwi" nocase ascii wide
    condition:
        2 of them
}

rule Schway_PHP_Webshell
{
    meta:
        description = "Bilinen PHP web kabuğu (webshell) kalıpları"
    strings:
        $a = "eval(base64_decode($_POST" ascii
        $b = "eval(gzinflate(base64_decode(" ascii
        $c = "assert($_POST[" ascii
        $d = "eval($_REQUEST[" ascii
        $e = "preg_replace(\"/.*/e\"" ascii
    condition:
        any of them
}
