import QtQuick 2.0
import calamares.slideshow 1.0

Presentation {
    id: presentation

    Timer {
        interval: 7000
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    // Her slayt: sola dayalı başlık ve açıklama, sağda logo
    Slide {
        Rectangle { anchors.fill: parent; color: "#0B0E14" }
        Image { source: "logo.png"; width: 120; height: 120; anchors { right: parent.right; rightMargin: 72; verticalCenter: parent.verticalCenter } smooth: true }
        Column {
            anchors { left: parent.left; leftMargin: 72; verticalCenter: parent.verticalCenter }
            spacing: 12
            Text { text: "Schway'e hoş geldin"; color: "#E3E7EF"; font.family: "IBM Plex Sans"; font.pixelSize: 32; font.weight: Font.Medium }
            Text { text: "Hafif, hızlı, sana özel."; color: "#8791A5"; font.family: "IBM Plex Sans"; font.pixelSize: 18 }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0B0E14" }
        Column {
            anchors { left: parent.left; leftMargin: 72; verticalCenter: parent.verticalCenter }
            spacing: 12
            Text { text: "Windows uygulamaları ve oyunları"; color: "#E3E7EF"; font.family: "IBM Plex Sans"; font.pixelSize: 32; font.weight: Font.Medium }
            Text { text: "Wine ve Steam hazır gelir."; color: "#8791A5"; font.family: "IBM Plex Sans"; font.pixelSize: 18 }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0B0E14" }
        Column {
            anchors { left: parent.left; leftMargin: 72; verticalCenter: parent.verticalCenter }
            spacing: 14
            Text { text: "Düşük bellek, yüksek FPS"; color: "#E3E7EF"; font.family: "IBM Plex Sans"; font.pixelSize: 32; font.weight: Font.Medium }
            Text { text: "Oyun modu kendiliğinden açılır."; color: "#8791A5"; font.family: "IBM Plex Sans"; font.pixelSize: 18 }
            Row {
                spacing: 4
                Repeater {
                    model: 24
                    Rectangle { width: 10; height: 14; radius: 2; color: index < 8 ? "#5980FA" : "#1B2029" }
                }
            }
        }
    }

    function onActivate() { }
    function onLeave() { }
}
