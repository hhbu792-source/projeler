#!/bin/bash
# Kurulumdan sonra (chroot içinde, bootloader adımından ÖNCE) çalışır:
#  - GRUB'a pürüzsüz geçiş ayarı (animasyon için)
#  - btrfs ise @snapshots alt birimini /.snapshots olarak bağlayan fstab satırı
#    (grub-btrfs anlık görüntüleri GRUB menüsünde buradan bulur)
GRUB_DEFAULT_FILE="${GRUB_DEFAULT_FILE:-/etc/default/grub}"
FSTAB="${FSTAB:-/etc/fstab}"

if [ -f "$GRUB_DEFAULT_FILE" ]; then
    sed -i '/^GRUB_GFXPAYLOAD_LINUX=/d' "$GRUB_DEFAULT_FILE"
    echo 'GRUB_GFXPAYLOAD_LINUX=keep' >> "$GRUB_DEFAULT_FILE"
fi

# Kök LUKS ve ayrı /boot yoksa GRUB çekirdeği şifreli bölümden okumak zorundadır.
if [ -f "$GRUB_DEFAULT_FILE" ] && [ -f "$FSTAB" ]; then
    LUKS_ROOT=$(awk '$1 !~ /^#/ && $2 == "/" && $1 ~ /^\/dev\/mapper\// { print $1; exit }' "$FSTAB")
    BOOT_SEP=$(awk '$1 !~ /^#/ && $2 == "/boot" { print $1; exit }' "$FSTAB")
    if [ -n "$LUKS_ROOT" ] && [ -z "$BOOT_SEP" ]; then
        sed -i '/^#\?GRUB_ENABLE_CRYPTODISK=/d' "$GRUB_DEFAULT_FILE"
        echo 'GRUB_ENABLE_CRYPTODISK=y' >> "$GRUB_DEFAULT_FILE"
    fi
fi

if [ -f "$FSTAB" ]; then
    ROOT_DEV=$(awk '$1 !~ /^#/ && $2 == "/" && $3 == "btrfs" { print $1; exit }' "$FSTAB")
    if [ -n "$ROOT_DEV" ] && ! grep -q '[[:space:]]/\.snapshots[[:space:]]' "$FSTAB"; then
        mkdir -p /.snapshots
        # nofail: @snapshots henüz yoksa (ilk anlık görüntüden önce) açılış takılmasın
        echo "$ROOT_DEV /.snapshots btrfs subvol=@snapshots,noatime,nofail,x-systemd.device-timeout=5s 0 0" >> "$FSTAB"
    fi
fi
# Ayarlar uygulaması: güç profilleri hizmeti
systemctl enable power-profiles-daemon >/dev/null 2>&1 || true
exit 0
