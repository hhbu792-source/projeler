#!/bin/bash
# Kurulu sistemin mkinitcpio HOOKS satırına Schway'in ihtiyaç duyduğu kancaları ekler.
# Calamares'in initcpiocfg adımından SONRA, initcpio adımından ÖNCE çalışır (chroot içinde).
#  - plymouth             : açılış animasyonu (udev'den hemen sonra olmalı)
#  - grub-btrfs-overlayfs : salt-okunur anlık görüntüden önyüklemeyi mümkün kılar
#  - encrypt              : kök bölüm LUKS ise (fstab'ta /dev/mapper/...), Calamares eklemediyse sigorta olarak ekler
CONF="${MKINITCPIO_CONF:-/etc/mkinitcpio.conf}"
FSTAB="${FSTAB:-/etc/fstab}"
[ -f "$CONF" ] || { echo "mkinitcpio.conf yok: $CONF"; exit 0; }

# Yalnızca gerçek HOOKS= satırına dokun (örnek yorum satırlarına değil)
if ! grep -q '^HOOKS=.*plymouth' "$CONF"; then
    if grep -q '^HOOKS=.* udev ' "$CONF"; then
        sed -i '/^HOOKS=/ s/ udev / udev plymouth /' "$CONF"
    else
        echo "UYARI: HOOKS satırında udev bulunamadı, plymouth kancası eklenmedi (açılış animasyonu çalışmaz)."
    fi
fi
if ! grep -q '^HOOKS=.*grub-btrfs-overlayfs' "$CONF"; then
    sed -i '/^HOOKS=/ s/)/ grub-btrfs-overlayfs)/' "$CONF"
fi
# Kök LUKS ise ve ne "encrypt" ne "sd-encrypt" varsa sistem açılmaz; filesystems'ten önce encrypt ekle.
if awk '$1 !~ /^#/ && $2 == "/" && $1 ~ /^\/dev\/mapper\// { f=1 } END { exit !f }' "$FSTAB" 2>/dev/null; then
    if ! grep -Eq '^HOOKS=.*[( ](sd-)?encrypt[) ]' "$CONF"; then
        if grep -q '^HOOKS=.* filesystems' "$CONF"; then
            sed -i '/^HOOKS=/ s/ filesystems/ encrypt filesystems/' "$CONF"
        else
            echo "UYARI: HOOKS satırında filesystems yok, encrypt kancası eklenemedi (şifreli disk açılmayabilir)."
        fi
    fi
fi
grep '^HOOKS=' "$CONF"
exit 0
