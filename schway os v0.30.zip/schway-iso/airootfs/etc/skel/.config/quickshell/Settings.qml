import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Schway Ayarlar (Super+I). Veri: SettingsPages.qml, arka uç: schway-settings.
PanelWindow {
    id: win
    visible: Ui.settingsOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-settings"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.settingsOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property int pageIndex: 1
    property var caps: []
    property var values: ({})
    property var choiceMap: ({})
    property var infoMap: ({})
    property string toast: ""
    property string confirmText: ""
    property var confirmFn: null
    property var pending: ({ key: "", value: "" })

    readonly property var nav: buildNav(caps)
    readonly property var rows: filterRows(SettingsPages.pages[pageIndex], caps)
    readonly property var groupRows: rows.filter(r => r.t !== "note")
    readonly property var noteRows: rows.filter(r => r.t === "note")

    function has(c) { return !c || caps.indexOf(c) >= 0 }
    function buildNav(c) {
        const out = []
        const p = SettingsPages.pages
        for (let i = 0; i < p.length; i++) {
            if (p[i].section) { out.push({ section: p[i].section }); continue }
            if (p[i].cap && c.indexOf(p[i].cap) < 0) continue
            out.push({ idx: i, title: p[i].title, sub: p[i].sub })
        }
        return out
    }
    function filterRows(pg, c) {
        if (!pg || !pg.rows) return []
        return pg.rows.filter(r => !r.cap || c.indexOf(r.cap) >= 0)
    }

    // ---- veri okuma ----
    function getVal(k) {
        if (k === "qml:dnd") return Notifs.dnd ? "1" : "0"
        const v = values[k]
        return v === undefined ? "" : v
    }
    function getChoices(k) { return choiceMap[k] || [] }
    function getInfo(n) { return (infoMap[n] || "").trim() }

    function load() {
        const keys = [], names = []
        for (const r of rows) {
            if (r.key && r.key.indexOf("qml:") !== 0 && keys.indexOf(r.key) < 0) keys.push(r.key)
            if (r.name && names.indexOf(r.name) < 0) names.push(r.name)
        }
        const q = s => "'" + s.replace(/'/g, "") + "'"
        loadProc.running = false
        loadProc.command = ["sh", "-c",
            "schway-settings dump " + keys.map(q).join(" ") + "; schway-settings infos " + names.map(q).join(" ")]
        loadProc.running = true
    }
    function parse(text) {
        const vals = {}, ch = {}, inf = {}
        let cur = null
        const lines = text.split("\n")
        for (let i = 0; i < lines.length; i++) {
            const l = lines[i]
            if (l.indexOf("@@") === 0) { cur = l.substring(2); inf[cur] = ""; continue }
            if (cur !== null) { inf[cur] += (inf[cur] === "" ? "" : "\n") + l; continue }
            if (l.indexOf("V ") === 0) {
                const r = l.substring(2), sp = r.indexOf(" ")
                vals[sp < 0 ? r : r.substring(0, sp)] = sp < 0 ? "" : r.substring(sp + 1)
            } else if (l.indexOf("C ") === 0) {
                const r = l.substring(2), sp = r.indexOf(" ")
                const k = r.substring(0, sp), rest = r.substring(sp + 1), bar = rest.indexOf("|")
                if (!ch[k]) ch[k] = []
                ch[k].push([rest.substring(0, bar), rest.substring(bar + 1)])
            }
        }
        values = vals; choiceMap = ch; infoMap = inf
    }

    // ---- yazma ----
    function localSet(k, v) { const o = Object.assign({}, values); o[k] = v; values = o }
    function send(k, v) {
        if (k.indexOf("qml:") === 0) { if (k === "qml:dnd") Notifs.dnd = (v === "1"); return }
        Quickshell.execDetached(["schway-settings", "set", k, String(v)])
        localSet(k, String(v))
        reloadTimer.restart()
    }
    function ask(text, fn) { confirmText = text; confirmFn = fn }
    function setToggle(r, on) {
        const go = () => send(r.key, on ? "1" : "0")
        if (r.confirm) ask(r.title, go); else go()
    }
    function setChoice(r, v) {
        const go = () => send(r.key, v)
        if (r.confirm) ask(r.title + ": " + v, go); else go()
    }
    function slide(r, raw) {
        const step = r.step || 1
        let v = Math.round(raw / step) * step
        v = step < 1 ? v.toFixed(1) : String(Math.round(v))
        localSet(r.key, v)
        pending = { key: r.key, value: v }
        slideTimer.restart()
    }
    function doAction(r) {
        const go = () => {
            if (r.term) Quickshell.execDetached(["foot", "-e"].concat(r.term))
            else if (r.qml === "openPassword") { Ui.settingsOpen = false; Ui.passwordOpen = true }
            else if (r.qml === "openSecurity") { Ui.settingsOpen = false; Ui.securityOpen = true }
            else if (r.qml === "clearNotifs") {
                const l = Notifs.model.values.slice(); l.forEach(n => n.dismiss()); toast = "Bildirim geçmişi temizlendi."
            } else if (r.run) {
                runProc.running = false
                runProc.command = ["schway-settings", "run", r.run]
                runProc.running = true
            }
            reloadTimer.restart()
        }
        if (r.confirm) ask(r.text, go); else go()
    }

    Process {
        id: capsProc
        command: ["schway-settings", "caps"]
        stdout: StdioCollector { onStreamFinished: win.caps = text.trim().split("\n").filter(x => x !== "") }
    }
    Process {
        id: loadProc
        stdout: StdioCollector { onStreamFinished: win.parse(text) }
    }
    Process {
        id: runProc
        stdout: StdioCollector {
            onStreamFinished: { if (text.trim() !== "") { win.toast = text.trim(); toastTimer.restart() } }
        }
    }
    Timer { id: reloadTimer; interval: 800; onTriggered: win.load() }
    Timer { id: toastTimer; interval: 7000; onTriggered: win.toast = "" }
    Timer { id: slideTimer; interval: 150
        onTriggered: Quickshell.execDetached(["schway-settings", "set", win.pending.key, win.pending.value]) }
    onRowsChanged: load()

    Connections {
        target: Ui
        function onSettingsOpenChanged() {
            if (Ui.settingsOpen) { capsProc.running = false; capsProc.running = true; win.load(); keyItem.forceActiveFocus() }
            else { win.confirmFn = null; win.toast = "" }
        }
    }

    Item { id: keyItem; focus: true; Keys.onEscapePressed: { if (win.confirmFn) win.confirmFn = null; else Ui.settingsOpen = false } }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, Theme.scrim.a * card.opacity)
        MouseArea { anchors.fill: parent; onClicked: Ui.settingsOpen = false }
    }

    Shadow { target: card }

    Rectangle {
        id: card
        width: Math.min(parent.width - 48, 1060)
        height: Math.min(parent.height - 48, 700)
        anchors.centerIn: parent
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        opacity: Ui.settingsOpen ? 1 : 0
        transform: Translate { y: Ui.settingsOpen ? 0 : 10; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        clip: true

        MouseArea { anchors.fill: parent }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // ---- Sol kategori menüsü ----
            Rectangle {
                Layout.preferredWidth: 236
                Layout.fillHeight: true
                color: Theme.well

                Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.line }

                ColumnLayout {
                    anchors.fill: parent
                    anchors.topMargin: 20
                    anchors.bottomMargin: 12
                    anchors.leftMargin: 12
                    anchors.rightMargin: 13
                    spacing: 12
                    RowLayout {
                        Layout.leftMargin: 8
                        spacing: 10
                        Image { source: Theme.logo; sourceSize: Qt.size(64, 64); Layout.preferredWidth: 26; Layout.preferredHeight: 26 }
                        Text { text: "Ayarlar"; color: Theme.text; font.family: Theme.font; font.pixelSize: 16; font.weight: Font.Medium }
                    }
                    ListView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 1
                        model: win.nav
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Item {
                            required property var modelData
                            width: ListView.view.width
                            height: modelData.section ? 34 : 36
                            Text {
                                visible: !!modelData.section
                                anchors { left: parent.left; leftMargin: 10; bottom: parent.bottom; bottomMargin: 5 }
                                text: modelData.section || ""
                                color: Theme.faint
                                font.family: Theme.font
                                font.pixelSize: 12
                            }
                            Rectangle {
                                visible: !modelData.section
                                anchors.fill: parent
                                radius: Theme.rCtl
                                color: modelData.idx === win.pageIndex ? Theme.press : (navArea.containsMouse ? Theme.surface : "transparent")
                                Behavior on color { ColorAnimation { duration: 100 } }
                                Rectangle {
                                    visible: modelData.idx === win.pageIndex
                                    anchors { left: parent.left; leftMargin: 6; verticalCenter: parent.verticalCenter }
                                    width: 3; height: 14; radius: 1.5
                                    color: Theme.accent
                                }
                                Text {
                                    anchors { left: parent.left; leftMargin: 18; right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                                    text: modelData.title || ""
                                    elide: Text.ElideRight
                                    color: modelData.idx === win.pageIndex ? Theme.text : Theme.muted
                                    font.family: Theme.font
                                    font.pixelSize: 13
                                    font.weight: modelData.idx === win.pageIndex ? Font.Medium : Font.Normal
                                }
                                MouseArea { id: navArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.pageIndex = modelData.idx }
                            }
                        }
                    }
                }
            }

            // ---- İçerik ----
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.topMargin: 22
                Layout.bottomMargin: 20
                Layout.leftMargin: 30
                Layout.rightMargin: 24
                spacing: 16

                RowLayout {
                    Layout.fillWidth: true
                    ColumnLayout {
                        spacing: 3
                        Text { text: SettingsPages.pages[win.pageIndex].title; color: Theme.text; font.family: Theme.font; font.pixelSize: 22; font.weight: Font.Medium }
                        Text { text: SettingsPages.pages[win.pageIndex].sub || ""; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        Layout.preferredWidth: 30
                        Layout.preferredHeight: 30
                        radius: Theme.rCtl
                        color: closeArea.containsMouse ? Theme.hover : "transparent"
                        Text { anchors.centerIn: parent; anchors.verticalCenterOffset: -1; text: "\u00D7"; color: closeArea.containsMouse ? Theme.text : Theme.muted; font.family: Theme.font; font.pixelSize: 20 }
                        MouseArea { id: closeArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.settingsOpen = false }
                    }
                }

                Flickable {
                    id: flick
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    contentWidth: width
                    contentHeight: col.implicitHeight
                    boundsBehavior: Flickable.StopAtBounds
                    ColumnLayout {
                        id: col
                        width: flick.width
                        spacing: 14

                        // Ayar grubu: tek yüzey, satırlar ince çizgiyle ayrılır
                        Rectangle {
                            visible: win.groupRows.length > 0
                            Layout.fillWidth: true
                            implicitHeight: groupCol.implicitHeight + 2
                            radius: Theme.rGroup
                            color: Theme.surface
                            border.width: 1
                            border.color: Theme.line
                            ColumnLayout {
                                id: groupCol
                                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                                spacing: 0
                                Repeater {
                                    model: win.groupRows
                                    delegate: SRow {
                                        required property var modelData
                                        required property int index
                                        rd: modelData
                                        st: win
                                        last: index === win.groupRows.length - 1
                                    }
                                }
                            }
                        }

                        Repeater {
                            model: win.noteRows
                            delegate: Text {
                                required property var modelData
                                Layout.fillWidth: true
                                Layout.leftMargin: 4
                                text: modelData.text || ""
                                wrapMode: Text.Wrap
                                color: Theme.muted
                                font.family: Theme.font
                                font.pixelSize: 13
                                lineHeight: 1.25
                            }
                        }
                    }
                }

                Rectangle {
                    visible: win.toast !== ""
                    Layout.fillWidth: true
                    implicitHeight: toastText.implicitHeight + 22
                    radius: Theme.rCtl
                    color: Theme.accentSoft
                    border.width: 1
                    border.color: Theme.accentEdge
                    Text {
                        id: toastText
                        anchors { fill: parent; margins: 11 }
                        text: win.toast
                        wrapMode: Text.Wrap
                        maximumLineCount: 5
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                }
            }
        }

        // ---- Yönetici izni onayı ----
        Rectangle {
            anchors.fill: parent
            visible: win.confirmFn !== null
            color: Qt.rgba(0, 0, 0, 0.5)
            MouseArea { anchors.fill: parent }
            Rectangle {
                anchors.centerIn: parent
                width: 400
                height: confirmCol.implicitHeight + 44
                radius: Theme.rWin
                color: Qt.rgba(0.075, 0.088, 0.120, 1)
                border.width: 1
                border.color: Theme.border
                ColumnLayout {
                    id: confirmCol
                    anchors { fill: parent; margins: 22 }
                    spacing: 12
                    Text { text: "Yönetici izni gerekiyor"; color: Theme.text; font.family: Theme.font; font.pixelSize: 17; font.weight: Font.Medium }
                    Text {
                        Layout.fillWidth: true
                        text: win.confirmText + "\n\nBu işlem sistem düzeyinde değişiklik yapar. Devam edilsin mi?"
                        wrapMode: Text.Wrap
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 13
                        lineHeight: 1.25
                    }
                    RowLayout {
                        Layout.topMargin: 6
                        spacing: 10
                        Item { Layout.fillWidth: true }
                        Chip { text: "Vazgeç"; onClicked: win.confirmFn = null }
                        Chip { text: "Onayla"; primary: true; onClicked: { const f = win.confirmFn; win.confirmFn = null; if (f) f() } }
                    }
                }
            }
        }
    }
}
