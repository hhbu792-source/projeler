pragma Singleton
import QtQuick
import Quickshell

// Schway görünüm dili: mürekkep mavisi zemin, logodaki mavi vurgu, tek bir imza öğe (kademeli göstergeler).
// Katmanlar: base (pencere gövdesi) > surface (yükseltilmiş) > press; well = gömülü alan.
// accent / accentDark / accentSoft satırlarının biçimini `schway-theme accent` sed ile değiştirir; bu üç satırın kalıbını bozma.
Singleton {
    // Açık tema yok (Ayarlar'da da öyle yazıyor)
    readonly property bool dark: true

    // ---- Zemin katmanları ----
    readonly property color barColor: Qt.rgba(0.045, 0.057, 0.080, 0.80)
    readonly property color base: Qt.rgba(0.055, 0.066, 0.092, 0.94)
    readonly property color glass: base
    readonly property color well: Qt.rgba(0, 0, 0, 0.24)
    readonly property color surface: Qt.rgba(1, 1, 1, 0.045)
    readonly property color hover: Qt.rgba(1, 1, 1, 0.085)
    readonly property color press: Qt.rgba(1, 1, 1, 0.125)
    readonly property color track: Qt.rgba(1, 1, 1, 0.10)
    readonly property color line: Qt.rgba(1, 1, 1, 0.065)
    readonly property color border: Qt.rgba(1, 1, 1, 0.095)
    readonly property color scrim: Qt.rgba(0.02, 0.03, 0.05, 0.22)

    // ---- Vurgu (varsayılan: logodaki mavi) ----
    readonly property color accent: dark ? "#5980FA" : "#5980FA"
    readonly property color accentDark: dark ? "#98B0FC" : "#98B0FC"
    readonly property color accentSoft: dark ? Qt.rgba(89/255, 128/255, 250/255, 0.28) : Qt.rgba(89/255, 128/255, 250/255, 0.28)
    readonly property color accentEdge: Qt.rgba(accent.r, accent.g, accent.b, 0.55)
    // Vurgu dolgusunun üstündeki yazı (açık vurgularda koyu, koyularda beyaz)
    readonly property color onAccent: (0.299 * accent.r + 0.587 * accent.g + 0.114 * accent.b) > 0.59 ? "#11131A" : "#FFFFFF"

    // ---- Yazı ----
    readonly property color text: "#E3E7EF"
    readonly property color muted: "#8791A5"
    readonly property color faint: "#5B6477"

    // ---- Durum ----
    readonly property color ok: "#4FD1A1"
    readonly property color warn: "#E8B65A"
    readonly property color bad: "#F0707D"

    // ---- Köşe yarıçapları: pencere > grup > kontrol > küçük ----
    readonly property int rWin: 16
    readonly property int rGroup: 12
    readonly property int rCtl: 8
    readonly property int rSm: 5
    readonly property int radius: rCtl
    readonly property int radiusLg: rWin

    readonly property string font: "IBM Plex Sans"
    readonly property string mono: "IBM Plex Mono"
    readonly property string iconFont: "Symbols Nerd Font"
    readonly property string logo: "file:///usr/share/schway/logo-mark.png"
    readonly property string logoIcon: "file:///usr/share/schway/logo.png"

    // Nerd Font (Material Design) simgeleri
    readonly property var g: ({
        apps: String.fromCodePoint(0xF003B),
        wifi: String.fromCodePoint(0xF05A9),
        wifiOff: String.fromCodePoint(0xF05AA),
        bluetooth: String.fromCodePoint(0xF00AF),
        game: String.fromCodePoint(0xF0297),
        moon: String.fromCodePoint(0xF0594),
        search: String.fromCodePoint(0xF0349),
        brightness: String.fromCodePoint(0xF00E0),
        volHigh: String.fromCodePoint(0xF057E),
        volMid: String.fromCodePoint(0xF0580),
        volLow: String.fromCodePoint(0xF057F),
        volOff: String.fromCodePoint(0xF0581),
        battery: String.fromCodePoint(0xF0079),
        charging: String.fromCodePoint(0xF0084)
    })
    function volGlyph(v, muted) {
        if (muted || v <= 0.001) return g.volOff
        return v < 0.34 ? g.volLow : (v < 0.67 ? g.volMid : g.volHigh)
    }
}
