import QtQuick

// Anahtar (açık/kapalı). Tıklamayı üstündeki satır yönetir.
Rectangle {
    id: root
    property bool on: false
    property bool locked: false
    property bool hot: false

    implicitWidth: 38
    implicitHeight: 22
    radius: 7
    color: on ? (locked ? Theme.accentSoft : Theme.accent) : Theme.track
    border.width: on ? 0 : 1
    border.color: Theme.line
    Behavior on color { ColorAnimation { duration: 120 } }

    Rectangle {
        width: 16; height: 16; radius: 5
        y: 3
        x: root.on ? root.width - width - 3 : 3
        color: root.on ? "#FFFFFF" : (root.hot ? Theme.text : Theme.muted)
        Behavior on x { NumberAnimation { duration: 130; easing.type: Easing.OutCubic } }
        Behavior on color { ColorAnimation { duration: 120 } }
    }
}
