pragma Singleton
import QtQuick
import Quickshell

Singleton {
    property bool launcherOpen: false
    property bool controlOpen: false
    property bool welcomeOpen: false
    property bool settingsOpen: false
    property bool securityOpen: false
    property bool passwordOpen: false
    property int securityPage: -1
    onLauncherOpenChanged: if (launcherOpen) controlOpen = false
    onControlOpenChanged: if (controlOpen) launcherOpen = false
}
