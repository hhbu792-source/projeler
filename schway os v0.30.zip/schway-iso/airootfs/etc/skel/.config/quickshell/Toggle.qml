import QtQuick
import QtQuick.Layouts

// Açma/kapama satırı: başlık + açıklama + anahtar
Rectangle {
    id: root
    property string title: ""
    property string body: ""
    property bool checked: false
    property bool locked: false
    signal toggled(bool value)

    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 28
    radius: Theme.rGroup
    color: Theme.surface
    border.width: 1
    border.color: Theme.line
    opacity: locked ? 0.8 : 1

    RowLayout {
        anchors.fill: parent
        anchors.margins: 14
        spacing: 16

        ColumnLayout {
            id: col
            Layout.fillWidth: true
            spacing: 3
            Text {
                text: root.title
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 14
                font.weight: Font.Medium
            }
            Text {
                Layout.fillWidth: true
                text: root.body
                wrapMode: Text.Wrap
                color: Theme.muted
                font.family: Theme.font
                font.pixelSize: 13
                lineHeight: 1.25
            }
        }
        Flip { on: root.checked; locked: root.locked; hot: area.containsMouse && !root.locked }
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        enabled: !root.locked
        cursorShape: Qt.PointingHandCursor
        onClicked: { root.checked = !root.checked; root.toggled(root.checked) }
    }
}
