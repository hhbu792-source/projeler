import QtQuick
import QtQuick.Layouts

// Güvenlik ayarlarında bölüm başlığı (satır gruplarını ayırır)
Text {
    Layout.fillWidth: true
    Layout.leftMargin: 16
    Layout.topMargin: 12
    Layout.bottomMargin: 2
    color: Theme.faint
    font.family: Theme.font
    font.pixelSize: 12
    font.weight: Font.Medium
}
