import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Hesap parolası belirleme (sudo parolasını açar). Parola komut satırına değil ortam değişkenine konur,
// `schway-harden on-stdin` onu standart girişten okur.
PanelWindow {
    id: win
    visible: Ui.passwordOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-welcome"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.passwordOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property bool busy: false
    property bool done: false
    property string error: ""
    readonly property bool valid: pw1.text.length >= 6 && pw1.text === pw2.text
    readonly property string hint: pw1.text.length === 0 ? "En az 6 karakter." : (pw1.text.length < 6 ? "Parola çok kısa (en az 6 karakter)." : (pw1.text !== pw2.text && pw2.text.length > 0 ? "Parolalar aynı değil." : ""))

    function submit() {
        if (!valid || busy) return
        busy = true; error = ""
        setProc.command = ["sh", "-c", "printf '%s\\n' \"$SPW\" | sudo schway-harden on-stdin 2>&1"]
        setProc.environment = ({ SPW: pw1.text })
        setProc.running = true
    }
    function close() { Ui.passwordOpen = false }

    Process {
        id: setProc
        stdout: StdioCollector { id: out }
        onExited: (code, status) => {
            win.busy = false
            if (code === 0) { win.done = true; pw1.text = ""; pw2.text = "" }
            else win.error = out.text.trim() || "Parola belirlenemedi."
        }
    }
    Connections {
        target: Ui
        function onPasswordOpenChanged() {
            if (Ui.passwordOpen) { win.done = false; win.error = ""; pw1.text = ""; pw2.text = ""; pw1.forceActiveFocus() }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, Theme.scrim.a * card.opacity)
        MouseArea { anchors.fill: parent }
    }

    Rectangle {
        id: card
        width: 440
        height: col.implicitHeight + 48
        anchors.centerIn: parent
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        opacity: Ui.passwordOpen ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        MouseArea { anchors.fill: parent }

        ColumnLayout {
            id: col
            anchors { fill: parent; margins: 24 }
            spacing: 14

            RowLayout {
                spacing: 12
                Text { text: String.fromCodePoint(0xF0565); color: Theme.accentDark; font.family: Theme.iconFont; font.pixelSize: 28 }
                Text { text: win.done ? "Parola belirlendi" : "Hesabına parola belirle"; color: Theme.text; font.family: Theme.font; font.pixelSize: 18; font.weight: Font.Medium }
            }
            Text {
                Layout.fillWidth: true
                wrapMode: Text.Wrap
                color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25
                text: win.done ? "Artık sudo ve yönetici işlemleri bu parolayı soracak. Antivirüsü kapatmak da parola ister."
                              : "Sudo, sistem ayarları ve antivirüsü kapatmak bu parolayı soracak; kötü amaçlı bir program bunları sessizce değiştiremesin diye. Oturum açarken sorulmaz."
            }

            ColumnLayout {
                visible: !win.done
                Layout.fillWidth: true
                spacing: 10
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 36
                    radius: Theme.rCtl
                    color: Theme.well
                    border.width: 1
                    border.color: pw1.activeFocus ? Theme.accentEdge : Theme.line
                    TextInput {
                        id: pw1
                        anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                        verticalAlignment: TextInput.AlignVCenter
                        echoMode: TextInput.Password
                        color: Theme.text; font.family: Theme.font; font.pixelSize: 14
                        clip: true
                        KeyNavigation.tab: pw2
                        Keys.onEscapePressed: win.close()
                    }
                    Text { visible: pw1.text === ""; anchors.left: parent.left
                        anchors.leftMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Parola"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 14 }
                }
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 36
                    radius: Theme.rCtl
                    color: Theme.well
                    border.width: 1
                    border.color: pw2.activeFocus ? Theme.accentEdge : Theme.line
                    TextInput {
                        id: pw2
                        anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                        verticalAlignment: TextInput.AlignVCenter
                        echoMode: TextInput.Password
                        color: Theme.text; font.family: Theme.font; font.pixelSize: 14
                        clip: true
                        onAccepted: win.submit()
                        Keys.onEscapePressed: win.close()
                    }
                    Text { visible: pw2.text === ""; anchors.left: parent.left
                        anchors.leftMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Parolayı tekrar yaz"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 14 }
                }
                Text {
                    Layout.fillWidth: true
                    text: win.error !== "" ? win.error : win.hint
                    color: win.error !== "" ? Theme.bad : Theme.muted
                    wrapMode: Text.Wrap
                    font.family: Theme.font; font.pixelSize: 12
                }
            }

            RowLayout {
                Layout.topMargin: 4
                spacing: 10
                Item { Layout.fillWidth: true }
                Chip { text: win.done ? "Tamam" : "Şimdi değil"; onClicked: win.close() }
                Chip { visible: !win.done; text: win.busy ? "Ayarlanıyor…" : "Parolayı belirle"; primary: true; opacity: win.valid && !win.busy ? 1 : 0.45; onClicked: win.submit() }
            }
        }
    }
}
