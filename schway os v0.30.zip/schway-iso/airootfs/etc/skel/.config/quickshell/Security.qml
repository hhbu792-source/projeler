import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Schway Güvenlik (Super+S): virüs ve tehdit koruması. Veri ve eylemler: Defender.qml -> schway-defender (ClamAV).
PanelWindow {
    id: win
    visible: Ui.securityOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-security"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.securityOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property int page: 0
    property string confirmText: ""
    property var confirmFn: null

    readonly property var nav: [
        { i: 0, title: "Ana sayfa", glyph: Defender.glyph.home, sub: "Cihazının güvenlik özeti" },
        { i: 1, title: "Virüs ve tehdit koruması", glyph: Defender.glyph.virus, sub: "Tarama, etkin tehditler, tanım güncellemesi" },
        { i: 2, title: "Koruma geçmişi", glyph: Defender.glyph.history, sub: "Son taramalar, tehditler ve güncellemeler" },
        { i: 3, title: "Karantina", glyph: Defender.glyph.archive, sub: "Engellenen dosyalar burada güvenle saklanır" },
        { i: 4, title: "Koruma ayarları", glyph: Defender.glyph.cog, sub: "Gerçek zamanlı koruma, zamanlama, dışlamalar" },
        { i: 5, title: "Güvenlik duvarı", glyph: Defender.glyph.wall, sub: "Gelen bağlantıları denetler (ufw)" }
    ]

    readonly property var cards: [
        { page: 1, glyph: Defender.glyph.virus, title: "Virüs ve tehdit koruması", status: Defender.activeThreats > 0 ? (Defender.activeThreats + " etkin tehdit") : Defender.lastScanText,
          level: Defender.activeThreats > 0 ? "bad" : (parseInt(Defender.s.last_scan_time || "0") === 0 ? "warn" : "ok") },
        { page: 4, glyph: Defender.glyph.shield, title: "Gerçek zamanlı koruma", status: Defender.rtText, level: Defender.s.realtime === "on" ? "ok" : "warn" },
        { page: 1, glyph: Defender.glyph.update, title: "Virüs tanımları", status: Defender.defsText, level: Defender.s.defs === "ok" ? "ok" : "warn" },
        { page: 5, glyph: Defender.glyph.wall, title: "Güvenlik duvarı", status: Defender.fwOn ? "Açık" : "Kapalı", level: Defender.fwOn ? "ok" : "warn" },
        { page: 4, glyph: Defender.glyph.lock, title: "Fidye yazılımı koruması", status: Defender.ransomInfo.text, level: Defender.ransomInfo.level },
        { page: 4, glyph: Defender.glyph.web, title: "Web koruması", status: Defender.webInfo.text, level: Defender.webInfo.level },
        { page: 4, glyph: Defender.glyph.run, title: "Çalıştırma öncesi engelleme", status: Defender.preventInfo.text, level: Defender.preventInfo.level },
        { page: 3, glyph: Defender.glyph.archive, title: "Karantina", status: Defender.quarantined > 0 ? (Defender.quarantined + " öğe bekliyor") : "Boş", level: Defender.quarantined > 0 ? "warn" : "ok" }
    ]

    function lc(l) { return Defender.levelColor(l) }
    function ask(text, fn) { confirmText = text; confirmFn = fn }
    function histTitle(h) {
        if (h.kind === "threat") {
            return ({ "karantina": "Tehdit karantinaya alındı", "algilandi": "Tehdit algılandı", "geri-yuklendi": "Karantinadan geri yüklendi",
                      "silindi": "Tehdit silindi", "yoksayildi": "Tehdit yoksayıldı", "izinli": "Tehdit izinli olarak işaretlendi" })[h.action] || "Tehdit"
        }
        if (h.kind === "scan") return h.action === "clean" ? "Tarama tamamlandı: temiz" : (h.action === "threats" ? "Tarama tamamlandı: tehdit bulundu" : "Tarama durduruldu")
        if (h.kind === "integrity") return h.action === "degisik" ? "Sistem dosyaları değişmiş" : "Sistem dosyası denetimi: temiz"
        if (h.kind === "update") return h.action === "ok" ? "Virüs tanımları güncellendi" : "Tanım güncellemesi başarısız"
        if (h.kind === "guard") return h.action === "hata" ? "İndirme koruması dosyayı tarayamadı" : (h.action === "karantina" ? "İndirilen dosya engellendi ve karantinaya alındı" : "İndirilen dosyada tehdit algılandı")
        if (h.kind === "execblock") return h.action === "karantina" ? "Çalıştırma engellendi, dosya karantinaya alındı" : "Çalıştırma engellendi"
        if (h.kind === "ransom") return "Fidye yazılımı şüphesi"
        return h.kind
    }
    function histDetail(h) {   // tarama kaydındaki "quick: ..." gibi baştaki İngilizce tür adını çevirir
        const m = /^(quick|full|custom): (.*)$/.exec(h.detail)
        return m ? Defender.kindName(m[1]) + ": " + m[2] : h.detail
    }
    function histColor(h) {
        if (h.kind === "threat") return (h.action === "karantina" || h.action === "algilandi") ? Theme.bad : Theme.muted
        if (h.kind === "scan") return h.action === "threats" ? Theme.warn : Theme.ok
        if (h.kind === "integrity") return h.action === "degisik" ? Theme.warn : Theme.ok
        if (h.kind === "execblock") return Theme.bad
        if (h.kind === "ransom") return Theme.warn
        if (h.kind === "guard") return h.action === "hata" ? Theme.warn : Theme.bad
        return h.action === "ok" ? Theme.ok : Theme.warn
    }
    function addExclusion() {
        const p = pathInput.text.trim()
        if (p === "") return
        Defender.cmd(["exclude", "add", p]); pathInput.text = ""
    }
    function customScan() {
        const p = scanPath.text.trim()
        if (p === "") return
        Defender.scan("custom", p)
    }

    Connections {
        target: Ui
        function onSecurityOpenChanged() {
            if (Ui.securityOpen) keyItem.forceActiveFocus()
            else win.confirmFn = null
        }
        function onSecurityPageChanged() {
            if (Ui.securityPage >= 0 && Ui.securityPage < win.nav.length) { win.page = Ui.securityPage; Ui.securityPage = -1 }
        }
    }

    Item { id: keyItem; focus: true; Keys.onEscapePressed: { if (win.confirmFn) win.confirmFn = null; else Ui.securityOpen = false } }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, Theme.scrim.a * card.opacity)
        MouseArea { anchors.fill: parent; onClicked: Ui.securityOpen = false }
    }

    Shadow { target: card }

    Rectangle {
        id: card
        width: Math.min(parent.width - 48, 1020)
        height: Math.min(parent.height - 48, 680)
        anchors.centerIn: parent
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        opacity: Ui.securityOpen ? 1 : 0
        transform: Translate { y: Ui.securityOpen ? 0 : 10; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        clip: true

        MouseArea { anchors.fill: parent }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // ---- Sol menü ----
            Rectangle {
                Layout.preferredWidth: 236
                Layout.fillHeight: true
                color: Theme.well
                Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.line }

                ColumnLayout {
                    anchors { fill: parent; topMargin: 20; bottomMargin: 14; leftMargin: 12; rightMargin: 13 }
                    spacing: 12
                    RowLayout {
                        Layout.leftMargin: 8
                        spacing: 10
                        Text { text: Defender.healthGlyph; color: Defender.healthColor; font.family: Theme.iconFont; font.pixelSize: 24 }
                        Text { text: "Güvenlik"; color: Theme.text; font.family: Theme.font; font.pixelSize: 16; font.weight: Font.Medium }
                    }
                    Repeater {
                        model: win.nav
                        delegate: Rectangle {
                            id: navItem
                            required property var modelData
                            Layout.fillWidth: true
                            Layout.preferredHeight: 38
                            radius: Theme.rCtl
                            color: modelData.i === win.page ? Theme.press : (navArea.containsMouse ? Theme.surface : "transparent")
                            Behavior on color { ColorAnimation { duration: 100 } }
                            Rectangle {
                                visible: navItem.modelData.i === win.page
                                anchors { left: parent.left; leftMargin: 6; verticalCenter: parent.verticalCenter }
                                width: 3; height: 14; radius: 1.5; color: Theme.accent
                            }
                            Row {
                                anchors { left: parent.left; leftMargin: 18; right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                                spacing: 10
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: 20; horizontalAlignment: Text.AlignHCenter   // sabit genişlik: simge genişliği yazıyı kaydırmasın
                                    text: navItem.modelData.glyph
                                    color: navItem.modelData.i === win.page ? Theme.accentDark : Theme.muted
                                    font.family: Theme.iconFont
                                    font.pixelSize: 16
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width - 30
                                    text: navItem.modelData.title
                                    elide: Text.ElideRight
                                    color: navItem.modelData.i === win.page ? Theme.text : Theme.muted
                                    font.family: Theme.font
                                    font.pixelSize: 13
                                    font.weight: navItem.modelData.i === win.page ? Font.Medium : Font.Normal
                                }
                            }
                            // Etkin tehdit rozeti
                            Rectangle {
                                visible: navItem.modelData.i === 1 && Defender.activeThreats > 0
                                anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                                width: 8; height: 8; radius: 4; color: Theme.bad
                            }
                            MouseArea { id: navArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.page = navItem.modelData.i }
                        }
                    }
                    Item { Layout.fillHeight: true }
                    Text {
                        Layout.leftMargin: 8
                        Layout.fillWidth: true
                        text: "Motor: ClamAV"
                        color: Theme.faint
                        font.family: Theme.font
                        font.pixelSize: 12
                    }
                }
            }

            // ---- İçerik ----
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.topMargin: 22
                Layout.bottomMargin: 20
                Layout.leftMargin: 30
                Layout.rightMargin: 24
                spacing: 16

                RowLayout {
                    Layout.fillWidth: true
                    ColumnLayout {
                        spacing: 3
                        Text { text: win.nav[win.page].title; color: Theme.text; font.family: Theme.font; font.pixelSize: 22; font.weight: Font.Medium }
                        Text { text: win.nav[win.page].sub; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        Layout.preferredWidth: 30
                        Layout.preferredHeight: 30
                        radius: Theme.rCtl
                        color: closeArea.containsMouse ? Theme.hover : "transparent"
                        Text { anchors.centerIn: parent; anchors.verticalCenterOffset: -1; text: "\u00D7"; color: closeArea.containsMouse ? Theme.text : Theme.muted; font.family: Theme.font; font.pixelSize: 20 }
                        MouseArea { id: closeArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.securityOpen = false }
                    }
                }

                Flickable {
                    id: flick
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    contentWidth: width
                    contentHeight: col.implicitHeight
                    boundsBehavior: Flickable.StopAtBounds

                    ColumnLayout {
                        id: col
                        width: flick.width
                        spacing: 14

                        // =================== 0: Ana sayfa ===================
                        ColumnLayout {
                            visible: win.page === 0
                            Layout.fillWidth: true
                            spacing: 14

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: 104
                                radius: Theme.rGroup
                                color: Qt.rgba(Defender.healthColor.r, Defender.healthColor.g, Defender.healthColor.b, 0.10)
                                border.width: 1
                                border.color: Qt.rgba(Defender.healthColor.r, Defender.healthColor.g, Defender.healthColor.b, 0.38)
                                RowLayout {
                                    anchors { fill: parent; leftMargin: 22; rightMargin: 20 }
                                    spacing: 18
                                    Text { text: Defender.healthGlyph; color: Defender.healthColor; font.family: Theme.iconFont; font.pixelSize: 46 }
                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 4
                                        Text { text: Defender.loaded ? Defender.healthTitle : "Denetleniyor…"; color: Theme.text; font.family: Theme.font; font.pixelSize: 20; font.weight: Font.Medium }
                                        Text { text: Defender.loaded ? Defender.healthSub : ""; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; wrapMode: Text.Wrap; Layout.fillWidth: true }
                                    }
                                    Chip {
                                        visible: Defender.activeThreats > 0
                                        text: "Tehditleri gör"
                                        primary: true
                                        onClicked: win.page = 1
                                    }
                                    Chip {
                                        visible: Defender.activeThreats === 0 && Defender.ransomRecent
                                        text: "Geçmişi aç"
                                        primary: true
                                        onClicked: win.page = 2
                                    }
                                    Chip {
                                        visible: !Defender.scanning && Defender.activeThreats === 0 && !Defender.ransomRecent && Defender.s.defs !== "missing" && Defender.s.engine !== "missing"
                                        text: "Hızlı tara"
                                        primary: true
                                        onClicked: { Defender.scan("quick"); win.page = 1 }
                                    }
                                    Chip {
                                        visible: Defender.s.defs === "missing" && Defender.s.engine !== "missing"
                                        text: Defender.updating ? "İndiriliyor…" : "Tanımları indir"
                                        primary: true
                                        onClicked: Defender.update()
                                    }
                                }
                            }

                            GridLayout {
                                Layout.fillWidth: true
                                columns: 2
                                columnSpacing: 12
                                rowSpacing: 12
                                Repeater {
                                    model: win.cards
                                    delegate: Rectangle {
                                        id: cardItem
                                        required property var modelData
                                        Layout.fillWidth: true
                                        Layout.preferredWidth: 1
                                        implicitHeight: 86
                                        radius: Theme.rGroup
                                        color: cardArea.pressed ? Theme.press : (cardArea.containsMouse ? Theme.hover : Theme.surface)
                                        border.width: 1
                                        border.color: Theme.line
                                        Behavior on color { ColorAnimation { duration: 110 } }
                                        Row {
                                            anchors { left: parent.left; leftMargin: 18; right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                                            spacing: 14
                                            Text { anchors.verticalCenter: parent.verticalCenter; width: 34; horizontalAlignment: Text.AlignHCenter; text: cardItem.modelData.glyph; color: win.lc(cardItem.modelData.level); font.family: Theme.iconFont; font.pixelSize: 28 }
                                            Column {
                                                anchors.verticalCenter: parent.verticalCenter
                                                width: parent.width - 48
                                                spacing: 3
                                                Text { width: parent.width; text: cardItem.modelData.title; elide: Text.ElideRight; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                                Text { width: parent.width; text: cardItem.modelData.status; elide: Text.ElideRight; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                            }
                                        }
                                        MouseArea { id: cardArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.page = cardItem.modelData.page }
                                    }
                                }
                            }

                            Text {
                                Layout.fillWidth: true
                                Layout.leftMargin: 4
                                wrapMode: Text.Wrap
                                color: Theme.faint
                                font.family: Theme.font
                                font.pixelSize: 12
                                lineHeight: 1.25
                                text: "ClamAV imza tabanlı bir tarayıcıdır: bilinen zararlıları yakalar, yeni ve hedefli saldırılara karşı tek başına yeterli değildir. Karantina geri alınabilir."
                            }
                        }

                        // =================== 1: Virüs ve tehdit koruması ===================
                        ColumnLayout {
                            visible: win.page === 1
                            Layout.fillWidth: true
                            spacing: 14

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: scanCol.implicitHeight + 36
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: scanCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 18; rightMargin: 18 }
                                    spacing: 12

                                    Text {
                                        text: Defender.scanning ? (Defender.kindName(Defender.s.kind) + (Defender.counting ? " hazırlanıyor" : " sürüyor")) : "Taramalar"
                                        color: Theme.text; font.family: Theme.font; font.pixelSize: 16; font.weight: Font.Medium
                                    }

                                    // Tarama sürerken
                                    ColumnLayout {
                                        visible: Defender.scanning
                                        Layout.fillWidth: true
                                        spacing: 9
                                        Rectangle {
                                            Layout.fillWidth: true
                                            Layout.preferredHeight: 6
                                            radius: 3
                                            color: Theme.track
                                            Rectangle {
                                                id: fillBar
                                                property real shift: 0
                                                x: Defender.counting ? shift : 0
                                                width: Defender.counting ? parent.width * 0.25 : parent.width * Defender.progress
                                                height: parent.height
                                                radius: 3
                                                color: parseInt(Defender.s.threats || "0") > 0 ? Theme.warn : Theme.accent
                                                Behavior on width { NumberAnimation { duration: 400 } }
                                                SequentialAnimation on shift {
                                                    running: Defender.counting
                                                    loops: Animation.Infinite
                                                    NumberAnimation { from: 0; to: fillBar.parent.width * 0.75; duration: 900 }
                                                    NumberAnimation { from: fillBar.parent.width * 0.75; to: 0; duration: 900 }
                                                }
                                            }
                                        }
                                        Text {
                                            text: Defender.counting ? "Taranacak dosyalar sayılıyor…" : (Defender.done + " / " + Defender.total + " dosya · " + (Defender.s.threats || "0") + " tehdit")
                                            color: Theme.text; font.family: Theme.font; font.pixelSize: 13
                                        }
                                        Text {
                                            Layout.fillWidth: true
                                            visible: !Defender.counting
                                            text: Defender.s.current || ""
                                            elide: Text.ElideMiddle
                                            color: Theme.faint; font.family: Theme.mono; font.pixelSize: 12
                                        }
                                        Chip { text: "Taramayı durdur"; danger: true; onClicked: Defender.cancel() }
                                    }

                                    // Boştayken
                                    ColumnLayout {
                                        visible: !Defender.scanning
                                        Layout.fillWidth: true
                                        spacing: 12
                                        Text {
                                            Layout.fillWidth: true
                                            wrapMode: Text.Wrap
                                            color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25
                                            text: parseInt(Defender.s.last_scan_time || "0") > 0
                                                  ? ("Son tarama: " + Defender.fmt(Defender.s.last_scan_time) + " · " + Defender.lastScanText + " · " + (Defender.s.last_scan_files || "0") + " dosya")
                                                  : "Henüz tarama yapılmadı."
                                        }
                                        Flow {
                                            Layout.fillWidth: true
                                            spacing: 8
                                            Chip { text: "Hızlı tarama"; primary: true; onClicked: Defender.scan("quick") }
                                            Chip { text: "Tam tarama"; onClicked: win.ask("Tam tarama tüm diski tarar ve uzun sürebilir (arka planda çalışır, Taramayı durdur ile bırakabilirsin).", () => Defender.scan("full")) }
                                        }
                                        RowLayout {
                                            Layout.fillWidth: true
                                            spacing: 8
                                            Rectangle {
                                                Layout.fillWidth: true
                                                implicitHeight: 30
                                                radius: Theme.rCtl
                                                color: Theme.well
                                                border.width: 1
                                                border.color: scanPath.activeFocus ? Theme.accentEdge : Theme.line
                                                TextInput {
                                                    id: scanPath
                                                    anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                                    verticalAlignment: TextInput.AlignVCenter
                                                    color: Theme.text; font.family: Theme.mono; font.pixelSize: 12
                                                    clip: true; selectByMouse: true
                                                    onAccepted: win.customScan()
                                                    Keys.onEscapePressed: Ui.securityOpen = false
                                                }
                                                Text {
                                                    visible: scanPath.text === ""
                                                    anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                                                    text: "Özel tarama: klasör ya da dosya yolu (örn. /home/kullanıcı_adın/Downloads)"
                                                    color: Theme.faint; font.family: Theme.font; font.pixelSize: 12
                                                }
                                            }
                                            Chip { text: "Özel tara"; onClicked: win.customScan() }
                                        }
                                    }
                                }
                            }

                            // Etkin tehditler
                            ColumnLayout {
                                visible: Defender.threats.length > 0
                                Layout.fillWidth: true
                                spacing: 8
                                Text { text: "Etkin tehditler"; color: Theme.bad; font.family: Theme.font; font.pixelSize: 15; font.weight: Font.Medium }
                                Repeater {
                                    model: Defender.threats
                                    delegate: Rectangle {
                                        id: thr
                                        required property var modelData
                                        Layout.fillWidth: true
                                        implicitHeight: thrCol.implicitHeight + 28
                                        radius: Theme.rGroup
                                        color: Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.08)
                                        border.width: 1
                                        border.color: Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.35)
                                        ColumnLayout {
                                            id: thrCol
                                            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                            spacing: 8
                                            Text { text: thr.modelData.sig; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                            Text { Layout.fillWidth: true; text: thr.modelData.path; elide: Text.ElideMiddle; color: Theme.muted; font.family: Theme.mono; font.pixelSize: 12 }
                                            Flow {
                                                Layout.fillWidth: true
                                                spacing: 8
                                                Chip { text: "Karantinaya al"; primary: true; onClicked: Defender.cmd(["threat", "quarantine", thr.modelData.path]) }
                                                Chip { text: "Sil"; danger: true; onClicked: win.ask("Dosya kalıcı olarak silinecek:\n" + thr.modelData.path, () => Defender.cmd(["threat", "delete", thr.modelData.path])) }
                                                Chip { text: "İzin ver"; onClicked: win.ask("Bu dosyanın aynı içeriği bir daha uyarı vermez. Yalnızca zararsız olduğundan eminsen (örn. kendi yazdığın bir araç) izin ver.", () => Defender.cmd(["threat", "allow", thr.modelData.path])) }
                                                Chip { text: "Yoksay"; onClicked: win.ask("Dosya yerinde kalır ve listeden kalkar. Zararlı olduğundan eminsen yoksayma.", () => Defender.cmd(["threat", "ignore", thr.modelData.path])) }
                                            }
                                        }
                                    }
                                }
                            }

                            // Tanım güncelleme
                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: updRow.implicitHeight + 32
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                RowLayout {
                                    id: updRow
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 18; rightMargin: 18 }
                                    spacing: 16
                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 3
                                        Text { text: "Koruma güncellemeleri"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                        Text {
                                            Layout.fillWidth: true
                                            wrapMode: Text.Wrap
                                            color: Theme.muted; font.family: Theme.font; font.pixelSize: 13
                                            text: Defender.defsText + (parseInt(Defender.s.defs_time || "0") > 0 ? (" · " + Defender.fmt(Defender.s.defs_time)) : "")
                                        }
                                    }
                                    Chip { text: Defender.updating ? "Güncelleniyor…" : "Şimdi güncelle"; onClicked: Defender.update() }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: intCol.implicitHeight + 32
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: intCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 18; rightMargin: 18 }
                                    spacing: 10
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 16
                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            spacing: 3
                                            Text { text: "Sistem dosyası bütünlüğü"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                            Text {
                                                Layout.fillWidth: true
                                                wrapMode: Text.Wrap
                                                color: Defender.integrityCount > 0 && !Defender.integrityRunning ? Theme.warn : Theme.muted
                                                font.family: Theme.font; font.pixelSize: 13
                                                text: Defender.integrityRunning ? "Paket dosyaları denetleniyor (birkaç dakika sürebilir)…"
                                                      : (parseInt(Defender.s.last_integrity_time || "0") === 0 ? "Henüz denetlenmedi. Kurulu paketlerin dosyalarının özgün içerikten farklı olup olmadığına bakar."
                                                      : (Defender.fmt(Defender.s.last_integrity_time) + " · " + (Defender.integrityCount > 0 ? (Defender.integrityCount + " dosya değişmiş") : "değişen dosya yok")))
                                            }
                                        }
                                        Chip { text: Defender.integrityRunning ? "Denetleniyor…" : "Denetle"; onClicked: { if (!Defender.integrityRunning) Defender.checkIntegrity() } }
                                    }
                                    Repeater {
                                        model: Defender.integrity.slice(0, 12)
                                        delegate: ColumnLayout {
                                            id: ir
                                            required property var modelData
                                            Layout.fillWidth: true
                                            spacing: 1
                                            Text { Layout.fillWidth: true; text: ir.modelData.path; elide: Text.ElideMiddle; color: Theme.text; font.family: Theme.mono; font.pixelSize: 12 }
                                            Text { Layout.fillWidth: true; text: ir.modelData.pkg + " · " + ir.modelData.problem; elide: Text.ElideRight; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                                        }
                                    }
                                    Text {
                                        visible: Defender.integrity.length > 12
                                        text: "…ve " + (Defender.integrity.length - 12) + " dosya daha (schway-defender integrity list)"
                                        color: Theme.faint; font.family: Theme.font; font.pixelSize: 12
                                    }
                                }
                            }
                        }

                        // =================== 2: Geçmiş ===================
                        ColumnLayout {
                            visible: win.page === 2
                            Layout.fillWidth: true
                            spacing: 8
                            Text {
                                visible: Defender.history.length === 0
                                text: "Henüz kayıt yok. Taramalar, tehditler ve güncellemeler burada listelenir."
                                color: Theme.muted; font.family: Theme.font; font.pixelSize: 13
                            }
                            Repeater {
                                model: Defender.history
                                delegate: Rectangle {
                                    id: hr
                                    required property var modelData
                                    Layout.fillWidth: true
                                    implicitHeight: hrCol.implicitHeight + 24
                                    radius: Theme.rGroup
                                    color: Theme.surface
                                    border.width: 1
                                    border.color: Theme.line
                                    Rectangle { anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter } width: 8; height: 8; radius: 4; color: win.histColor(hr.modelData) }
                                    ColumnLayout {
                                        id: hrCol
                                        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 34; rightMargin: 16 }
                                        spacing: 3
                                        RowLayout {
                                            Layout.fillWidth: true
                                            Text { text: win.histTitle(hr.modelData); color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; Layout.fillWidth: true; elide: Text.ElideRight }
                                            Text { text: Defender.fmt(hr.modelData.time); color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                                        }
                                        Text { visible: hr.modelData.detail !== ""; Layout.fillWidth: true; text: win.histDetail(hr.modelData); elide: Text.ElideRight; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                        Text { visible: hr.modelData.path !== ""; Layout.fillWidth: true; text: hr.modelData.path; elide: Text.ElideMiddle; color: Theme.faint; font.family: Theme.mono; font.pixelSize: 12 }
                                    }
                                }
                            }
                        }

                        // =================== 3: Karantina ===================
                        ColumnLayout {
                            visible: win.page === 3
                            Layout.fillWidth: true
                            spacing: 8
                            RowLayout {
                                Layout.fillWidth: true
                                visible: Defender.quarantine.length > 0
                                Text { text: Defender.quarantine.length + " öğe"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; Layout.fillWidth: true }
                                Chip { text: "Tümünü sil"; danger: true; onClicked: win.ask("Karantinadaki tüm dosyalar kalıcı olarak silinecek.", () => Defender.cmd(["quarantine", "clear"])) }
                            }
                            Text {
                                visible: Defender.quarantine.length === 0
                                text: "Karantina boş."
                                color: Theme.muted; font.family: Theme.font; font.pixelSize: 13
                            }
                            Repeater {
                                model: Defender.quarantine
                                delegate: Rectangle {
                                    id: qr
                                    required property var modelData
                                    Layout.fillWidth: true
                                    implicitHeight: qrCol.implicitHeight + 28
                                    radius: Theme.rGroup
                                    color: Theme.surface
                                    border.width: 1
                                    border.color: Theme.line
                                    ColumnLayout {
                                        id: qrCol
                                        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                        spacing: 6
                                        RowLayout {
                                            Layout.fillWidth: true
                                            Text { text: qr.modelData.sig; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; Layout.fillWidth: true; elide: Text.ElideRight }
                                            Text { text: Defender.fmt(qr.modelData.time) + " · " + Defender.sizeText(qr.modelData.size); color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                                        }
                                        Text { Layout.fillWidth: true; text: qr.modelData.path; elide: Text.ElideMiddle; color: Theme.muted; font.family: Theme.mono; font.pixelSize: 12 }
                                        Flow {
                                            Layout.fillWidth: true
                                            spacing: 8
                                            Chip { text: "Geri yükle"; onClicked: win.ask("Zararlı olabilecek dosya eski yerine geri konacak:\n" + qr.modelData.path, () => Defender.cmd(["quarantine", "restore", qr.modelData.id])) }
                                            Chip { text: "Kalıcı sil"; danger: true; onClicked: win.ask("Dosya kalıcı olarak silinecek.", () => Defender.cmd(["quarantine", "delete", qr.modelData.id])) }
                                        }
                                    }
                                }
                            }
                        }

                        // =================== 4: Ayarlar ===================
                        ColumnLayout {
                            visible: win.page === 4
                            Layout.fillWidth: true
                            spacing: 14

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: setCol.implicitHeight + 2
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: setCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                                    spacing: 0
                                    SecHead { text: "Gerçek zamanlı ve otomatik" }
                                    SecRow {
                                        title: "Gerçek zamanlı koruma"
                                        body: "İndirilenler, Masaüstü, Belgeler ve geçici klasörlerdeki dosyalar yazılırken taranır. Açıkken yaklaşık 1 GB RAM kullanır; RAM'i az bilgisayarda kapalı bırakabilirsin."
                                        on: Defender.rtOn
                                        onToggled: v => Defender.setCfg("realtime", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Bulunan tehditleri otomatik karantinaya al"
                                        body: "Kapalıysa tehdit yalnızca listelenir, işlemi sen seçersin."
                                        on: Defender.s.cfg_autoquarantine === "1"
                                        onToggled: v => Defender.setCfg("autoquarantine", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Virüs tanımlarını otomatik güncelle"
                                        body: "Arka planda günde birkaç kez kontrol eder (internet gerekir)."
                                        on: Defender.s.cfg_autoupdate === "1"
                                        onToggled: v => Defender.setCfg("autoupdate", v ? "1" : "0")
                                    }
                                    SecHead { text: "Ek korumalar" }
                                    SecRow {
                                        title: "İndirme koruması"
                                        body: "İndirilenler'e inen riskli dosyalar (exe, sh, zip, pdf...) taranana kadar açılamaz; tehditte karantinaya alınır. Gerçek zamanlı koruma açıkken çalışır."
                                        on: Defender.s.cfg_guard === "1"
                                        onToggled: v => Defender.setCfg("guard", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Fidye yazılımı koruması"
                                        body: "Belgeler, Masaüstü ve Resimler'e gizli tuzak dosyalar koyar; tuzağa dokunulursa ya da kısa sürede çok dosya değişirse uyarır. Engellemez, yalnızca erken uyarı verir. Çok az RAM kullanır."
                                        on: Defender.s.cfg_ransom === "1"
                                        status: on ? Defender.ransomInfo.text : ""
                                        statusColor: Defender.levelColor(Defender.ransomInfo.level)
                                        onToggled: v => Defender.setCfg("ransom", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Web koruması"
                                        body: "Bilinen zararlı alan adlarını (abuse.ch URLhaus) tüm uygulamalar için engeller. Alan adı bazlıdır: IP ile doğrudan bağlanmayı ve tarayıcının kendi DNS-over-HTTPS'ini engellemez."
                                        on: Defender.s.cfg_web === "1"
                                        status: on ? Defender.webInfo.text : ""
                                        statusColor: Defender.levelColor(Defender.webInfo.level)
                                        onToggled: v => Defender.setCfg("web", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Çalıştırma öncesi engelleme"
                                        body: "İndirilenler, /tmp, USB gibi yerlerden çalıştırılan dosya çalışmadan önce taranır; tehdit varsa açılmaz. Açılınca gerçek zamanlı korumayı da açar (yaklaşık 1 GB RAM). Tarama yapılamazsa dosya çalışır."
                                        on: Defender.s.cfg_prevent === "1"
                                        status: on ? Defender.preventInfo.text : ""
                                        statusColor: Defender.levelColor(Defender.preventInfo.level)
                                        onToggled: v => Defender.setCfg("prevent", v ? "1" : "0")
                                    }
                                    SecHead { text: "Tarama ve bildirimler" }
                                    SecRow {
                                        title: "USB ve harici diskleri otomatik tara"
                                        body: "Takılan USB bellek ya da harici disk bağlanınca taranır (dahili diskler taranmaz)."
                                        on: Defender.s.cfg_usbscan === "1"
                                        onToggled: v => Defender.setCfg("usbscan", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Bildirimler"
                                        body: "Tehdit bulununca ve taramalar bitince bildirim gösterir."
                                        on: Defender.s.cfg_notify === "1"
                                        onToggled: v => Defender.setCfg("notify", v ? "1" : "0")
                                    }
                                    SecRow {
                                        title: "Arşivleri tara (zip, rar, 7z…)"
                                        body: "Kapatmak taramayı hızlandırır, arşiv içindeki zararlıları kaçırır."
                                        on: Defender.s.cfg_archives === "1"
                                        last: true
                                        onToggled: v => Defender.setCfg("archives", v ? "1" : "0")
                                    }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: schCol.implicitHeight + 32
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: schCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                    spacing: 10
                                    Text { text: "Zamanlanmış tarama"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                    Text { Layout.fillWidth: true; wrapMode: Text.Wrap; text: "Bilgisayar boştayken ve fişe takılıyken çalışır; oyun modu açıksa ertelenir."; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                    Flow {
                                        Layout.fillWidth: true
                                        spacing: 8
                                        Repeater {
                                            model: [["off", "Kapalı"], ["daily", "Her gün (hızlı)"], ["weekly", "Haftalık (hızlı)"], ["weekly-full", "Haftalık (tam)"]]
                                            delegate: Chip {
                                                required property var modelData
                                                text: modelData[1]; fontSize: 13; implicitHeight: 28
                                                highlighted: Defender.s.cfg_schedule === modelData[0]
                                                onClicked: Defender.setCfg("schedule", modelData[0])
                                            }
                                        }
                                    }
                                    Text { visible: Defender.s.cfg_schedule !== "off"; text: "Tarama saati"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; Layout.topMargin: 6 }
                                    Flow {
                                        visible: Defender.s.cfg_schedule !== "off"
                                        Layout.fillWidth: true
                                        spacing: 8
                                        Repeater {
                                            model: ["03:00", "12:00", "18:00", "22:00"]
                                            delegate: Chip {
                                                required property string modelData
                                                text: modelData; fontSize: 13; implicitHeight: 28
                                                highlighted: Defender.s.cfg_scantime === modelData
                                                onClicked: Defender.setCfg("scantime", modelData)
                                            }
                                        }
                                    }
                                    Text { text: "En büyük taranan dosya"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; Layout.topMargin: 6 }
                                    Flow {
                                        Layout.fillWidth: true
                                        spacing: 8
                                        Repeater {
                                            model: [["25", "25 MB"], ["100", "100 MB"], ["250", "250 MB"], ["500", "500 MB"]]
                                            delegate: Chip {
                                                required property var modelData
                                                text: modelData[1]; fontSize: 13; implicitHeight: 28
                                                highlighted: Defender.s.cfg_maxsize === modelData[0]
                                                onClicked: Defender.setCfg("maxsize", modelData[0])
                                            }
                                        }
                                    }
                                }
                            }

                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: exCol.implicitHeight + 32
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: exCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                    spacing: 10
                                    Text { text: "Dışlamalar"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                    Text {
                                        Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25
                                        text: "Buradaki yollar taranmaz. Zaten taranmayanlar: /proc, /sys, /dev, /mnt, /media, Steam oyun dosyaları, karantina ve anlık görüntüler."
                                    }
                                    Repeater {
                                        model: Defender.exclusions
                                        delegate: RowLayout {
                                            id: exRow
                                            required property string modelData
                                            Layout.fillWidth: true
                                            spacing: 10
                                            Text { Layout.fillWidth: true; text: exRow.modelData; elide: Text.ElideMiddle; color: Theme.text; font.family: Theme.mono; font.pixelSize: 12 }
                                            Chip { text: "Kaldır"; fontSize: 12; implicitHeight: 24; onClicked: Defender.cmd(["exclude", "remove", exRow.modelData]) }
                                        }
                                    }
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 8
                                        Rectangle {
                                            Layout.fillWidth: true
                                            implicitHeight: 30
                                            radius: Theme.rCtl
                                            color: Theme.well
                                            border.width: 1
                                            border.color: pathInput.activeFocus ? Theme.accentEdge : Theme.line
                                            TextInput {
                                                id: pathInput
                                                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                                verticalAlignment: TextInput.AlignVCenter
                                                color: Theme.text; font.family: Theme.mono; font.pixelSize: 12
                                                clip: true; selectByMouse: true
                                                onAccepted: win.addExclusion()
                                                Keys.onEscapePressed: Ui.securityOpen = false
                                            }
                                            Text {
                                                visible: pathInput.text === ""
                                                anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                                                text: "Dışlanacak klasör ya da dosya yolu"
                                                color: Theme.faint; font.family: Theme.font; font.pixelSize: 12
                                            }
                                        }
                                        Chip { text: "Ekle"; onClicked: win.addExclusion() }
                                    }
                                }
                            }

                            Rectangle {
                                visible: Defender.allowed.length > 0
                                Layout.fillWidth: true
                                implicitHeight: alCol.implicitHeight + 32
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: alCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                    spacing: 10
                                    Text { text: "İzin verilen dosyalar"; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium }
                                    Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; text: "Bu içeriğe sahip dosyalar uyarı vermez. Dosya değişirse yeniden taranır." }
                                    Repeater {
                                        model: Defender.allowed
                                        delegate: RowLayout {
                                            id: alRow
                                            required property var modelData
                                            Layout.fillWidth: true
                                            spacing: 10
                                            ColumnLayout {
                                                Layout.fillWidth: true
                                                spacing: 1
                                                Text { Layout.fillWidth: true; text: alRow.modelData.path; elide: Text.ElideMiddle; color: Theme.text; font.family: Theme.mono; font.pixelSize: 12 }
                                                Text { Layout.fillWidth: true; text: alRow.modelData.sig; elide: Text.ElideRight; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                                            }
                                            Chip { text: "Kaldır"; fontSize: 12; implicitHeight: 24; onClicked: Defender.cmd(["allowed", "remove", alRow.modelData.hash]) }
                                        }
                                    }
                                }
                            }
                        }

                        // =================== 5: Güvenlik duvarı ===================
                        ColumnLayout {
                            visible: win.page === 5
                            Layout.fillWidth: true
                            spacing: 14
                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: fwCol.implicitHeight + 2
                                radius: Theme.rGroup
                                color: Theme.surface
                                border.width: 1
                                border.color: Theme.line
                                ColumnLayout {
                                    id: fwCol
                                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                                    spacing: 0
                                    SecRow {
                                        title: "Güvenlik duvarı (ufw)"
                                        body: "Dışarıdan gelen bağlantıları engeller, giden bağlantılara karışmaz. Yönetici izni ister."
                                        on: Defender.fwOn
                                        last: true
                                        onToggled: v => win.ask("Güvenlik duvarı " + (v ? "açılacak." : "kapatılacak."), () => Defender.setFirewall(v))
                                    }
                                }
                            }
                            Text {
                                Layout.fillWidth: true; Layout.leftMargin: 4; wrapMode: Text.Wrap; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25
                                text: "Sunucu hizmetleri (ssh, nginx…) için kural eklemek gerekir: sudo ufw allow <port>. Ayrıntılı ağ ayarları Ayarlar > Ağ ve İnternet sayfasındadır."
                            }
                        }
                    }
                }
            }
        }

        // ---- Onay penceresi ----
        Rectangle {
            anchors.fill: parent
            visible: win.confirmFn !== null
            color: Qt.rgba(0, 0, 0, 0.5)
            MouseArea { anchors.fill: parent }
            Rectangle {
                anchors.centerIn: parent
                width: 420
                height: confirmCol.implicitHeight + 44
                radius: Theme.rWin
                color: Qt.rgba(0.075, 0.088, 0.120, 1)
                border.width: 1
                border.color: Theme.border
                ColumnLayout {
                    id: confirmCol
                    anchors { fill: parent; margins: 22 }
                    spacing: 12
                    Text { text: "Onay gerekiyor"; color: Theme.text; font.family: Theme.font; font.pixelSize: 17; font.weight: Font.Medium }
                    Text { Layout.fillWidth: true; text: win.confirmText; wrapMode: Text.Wrap; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25 }
                    RowLayout {
                        Layout.topMargin: 6
                        spacing: 10
                        Item { Layout.fillWidth: true }
                        Chip { text: "Vazgeç"; onClicked: win.confirmFn = null }
                        Chip { text: "Onayla"; primary: true; onClicked: { const f = win.confirmFn; win.confirmFn = null; if (f) f() } }
                    }
                }
            }
        }
    }
}
