pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property string ram: "-"
    property real ramUsed: 0
    property real ramTotal: 0
    readonly property real ramFrac: ramTotal > 0 ? ramUsed / ramTotal : 0
    property bool dpi: false
    property bool live: false
    property bool wifiOn: true

    readonly property var aylar: ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"]
    readonly property var gunler: ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt"]

    function trDate(d) { return d.getDate() + " " + aylar[d.getMonth()] + " " + d.getFullYear() }
    // "Sal 20 Eki"
    function trDay(d) { return gunler[d.getDay()] + " " + d.getDate() + " " + aylar[d.getMonth()] }

    Process {
        id: ramProc
        command: ["sh", "-c", "awk '/MemTotal/{t=$2}/MemAvailable/{a=$2}END{printf \"%.1f %.1f\",(t-a)/1048576,t/1048576}' /proc/meminfo"]
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim().split(" ")
                root.ramUsed = parseFloat(p[0]) || 0
                root.ramTotal = parseFloat(p[1]) || 0
                root.ram = p[0] + " GB"
            }
        }
    }
    Process {
        id: dpiProc
        command: ["systemctl", "is-active", "--quiet", "zapret"]
        onExited: (code, status) => root.dpi = (code === 0)
    }
    Process {
        id: wifiProc
        command: ["nmcli", "radio", "wifi"]
        stdout: StdioCollector { onStreamFinished: root.wifiOn = text.trim() === "enabled" }
    }
    Process {
        id: liveProc
        command: ["test", "-d", "/run/archiso"]
        onExited: (code, status) => root.live = (code === 0)
    }
    Component.onCompleted: liveProc.running = true
    Timer {
        interval: 3000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: { ramProc.running = true; dpiProc.running = true; wifiProc.running = true }
    }
}
