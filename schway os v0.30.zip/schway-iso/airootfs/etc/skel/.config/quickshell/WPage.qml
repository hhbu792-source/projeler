import QtQuick
import QtQuick.Layouts

ColumnLayout {
    id: root
    property string pageTitle: ""
    property string pageBody: ""
    property string actionText: ""
    property string iconSource: ""
    signal action()
    spacing: 22

    Image {
        visible: root.iconSource !== ""
        source: root.iconSource
        sourceSize: Qt.size(192, 192)
        Layout.preferredWidth: 84
        Layout.preferredHeight: 84
        smooth: true
    }
    PageHead {
        title: root.pageTitle
        body: root.pageBody
        titleSize: root.iconSource !== "" ? 32 : 26
    }
    Chip {
        visible: root.actionText !== ""
        text: root.actionText
        primary: true
        onClicked: root.action()
    }
    Item { Layout.fillHeight: true }
}
