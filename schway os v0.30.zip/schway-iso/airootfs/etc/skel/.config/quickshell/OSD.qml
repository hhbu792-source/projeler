import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Services.Pipewire
import QtQuick

// Ses ve parlaklık göstergesi. Ses değişince kendiliğinden, parlaklık tuşlarında
// `qs ipc call osd brightness` ile (hyprland.conf) görünür.
PanelWindow {
    id: win
    visible: shown || card.opacity > 0.01
    anchors { bottom: true }
    margins { bottom: 100 }
    implicitWidth: 300
    implicitHeight: 52
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    mask: Region {}
    WlrLayershell.namespace: "schway-osd"
    WlrLayershell.layer: WlrLayer.Overlay

    property bool shown: false
    property string kind: "volume"
    property real level: 0
    property bool muted: false
    property bool armed: false

    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var audio: sink ? sink.audio : null
    readonly property string glyph: kind === "brightness" ? Theme.g.brightness : Theme.volGlyph(level, muted)
    readonly property string valueText: (kind === "volume" && muted) ? "Sessiz" : Math.round(level * 100) + "%"

    function show(k, lv, mt) {
        kind = k
        level = Math.max(0, Math.min(1, lv))
        muted = mt
        shown = true
        hideTimer.restart()
    }
    function onAudio() {
        // Açılışta ve hızlı ayarlar açıkken gösterme
        if (!armed || Ui.controlOpen || Ui.settingsOpen || !audio) return
        show("volume", audio.volume, audio.muted)
    }

    PwObjectTracker { objects: [Pipewire.defaultAudioSink] }
    Timer { interval: 4000; running: true; onTriggered: win.armed = true }
    Timer { id: hideTimer; interval: 1600; onTriggered: win.shown = false }

    Connections {
        target: win.audio
        ignoreUnknownSignals: true
        function onVolumeChanged() { win.onAudio() }
        function onMutedChanged() { win.onAudio() }
    }

    Process {
        id: briProc
        command: ["sh", "-c", "brightnessctl -m | cut -d, -f4 | tr -d %"]
        stdout: StdioCollector {
            onStreamFinished: {
                const v = parseInt(text.trim())
                if (!isNaN(v)) win.show("brightness", v / 100, false)
            }
        }
    }
    IpcHandler {
        target: "osd"
        function brightness(): void { briProc.running = true }
    }

    Rectangle {
        id: card
        anchors.fill: parent
        radius: 14
        color: Qt.rgba(0.060, 0.072, 0.100, 0.96)
        border.width: 1
        border.color: Theme.border
        opacity: win.shown ? 1 : 0
        transform: Translate { y: win.shown ? 0 : 8; Behavior on y { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } } }
        Behavior on opacity { NumberAnimation { duration: win.shown ? 90 : 220 } }

        Text {
            id: icon
            anchors { left: parent.left; leftMargin: 18; verticalCenter: parent.verticalCenter }
            width: 24
            horizontalAlignment: Text.AlignHCenter
            text: win.glyph
            color: win.muted && win.kind === "volume" ? Theme.faint : Theme.text
            font.family: Theme.iconFont
            font.pixelSize: 20
        }
        TickMeter {
            anchors { left: icon.right; leftMargin: 14; right: label.left; rightMargin: 14; verticalCenter: parent.verticalCenter }
            height: 18
            ticks: 24
            value: (win.kind === "volume" && win.muted) ? 0 : win.level
        }
        Text {
            id: label
            anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
            width: 44
            horizontalAlignment: Text.AlignRight
            text: win.valueText
            color: Theme.text
            font.family: Theme.font
            font.pixelSize: 13
            font.weight: Font.Medium
        }
    }
}
