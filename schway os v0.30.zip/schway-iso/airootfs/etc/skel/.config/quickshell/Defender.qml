pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

// Schway Güvenlik durumu. Veri kaynağı: `schway-defender` (ClamAV). Tarama, kabuktan bağımsız
// arka planda çalışır; burası yalnızca durum dosyasını okur, bu yüzden pencere kapansa da tarama sürer.
Singleton {
    id: root

    property var s: ({})            // schway-defender status çıktısı
    property var quarantine: []     // { id, time, sig, path, size }
    property var history: []        // { time, kind, action, detail, path }
    property var threats: []        // { path, sig, time }
    property var exclusions: []
    property var allowed: []        // { hash, path, sig, time }
    property var integrity: []      // { pkg, path, problem }
    property bool loaded: false

    readonly property string health: s.health || "warn"
    readonly property bool scanning: s.state === "running" || s.state === "counting"
    readonly property bool counting: s.state === "counting"
    readonly property int done: parseInt(s.done || "0")
    readonly property int total: parseInt(s.total || "0")
    readonly property real progress: (!counting && total > 0) ? Math.min(1, done / total) : 0
    readonly property int activeThreats: parseInt(s.active_threats || "0")
    readonly property bool integrityRunning: s.integrity_state === "running"
    readonly property int integrityCount: parseInt(s.last_integrity_count || "0")
    readonly property int quarantined: parseInt(s.quarantined || "0")
    readonly property bool rtOn: s.realtime === "on" || s.realtime === "starting"
    readonly property bool fwOn: s.firewall === "on"
    readonly property bool ransomRecent: parseInt(s.last_ransom_time || "0") > 0 && (Date.now() / 1000 - parseInt(s.last_ransom_time)) < 86400
    readonly property color healthColor: health === "ok" ? Theme.ok : (health === "warn" ? Theme.warn : Theme.bad)
    readonly property string healthGlyph: health === "ok" ? String.fromCodePoint(0xF0565) : (health === "warn" ? String.fromCodePoint(0xF0780) : String.fromCodePoint(0xF0ECC))

    readonly property var glyph: ({
        shield: String.fromCodePoint(0xF0498), ok: String.fromCodePoint(0xF0565), alert: String.fromCodePoint(0xF0ECC),
        off: String.fromCodePoint(0xF099E), half: String.fromCodePoint(0xF0780), home: String.fromCodePoint(0xF02DC),
        virus: String.fromCodePoint(0xF13B6), history: String.fromCodePoint(0xF02DA), cog: String.fromCodePoint(0xF0493),
        refresh: String.fromCodePoint(0xF0450), archive: String.fromCodePoint(0xF003C), wall: String.fromCodePoint(0xF07FE),
        update: String.fromCodePoint(0xF06B0), check: String.fromCodePoint(0xF05E0), scan: String.fromCodePoint(0xF0349),
        lock: String.fromCodePoint(0xF033E), web: String.fromCodePoint(0xF059F), run: String.fromCodePoint(0xF040D)
    })

    // Ek korumaların kart/satır durumu: { text, level } (level: ok | warn | bad | idle)
    function dots(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".") }
    readonly property var ransomInfo: {
        if (s.cfg_ransom !== "1") return { text: "Kapalı", level: "warn" }
        if (ransomRecent) return { text: "Şüphe algılandı (son 24 saat)", level: "bad" }
        if (s.ransom_state === "on") return { text: "Tuzak dosyalar izleniyor", level: "ok" }
        if (s.ransom_state === "error") return { text: "Hizmet hata verdi", level: "bad" }
        return { text: "Başlıyor…", level: "warn" }
    }
    readonly property var webInfo: {
        if (s.cfg_web !== "1") return { text: "Kapalı", level: "warn" }
        const n = parseInt(s.web_count || "0")
        return n > 0 ? { text: dots(n) + " alan adı engelli", level: "ok" } : { text: "Liste indirilmedi (internet gerekir)", level: "warn" }
    }
    readonly property var preventInfo: {
        if (s.cfg_prevent !== "1") return { text: "Kapalı (isteğe bağlı)", level: "idle" }
        if (s.prevent_state === "on") return { text: "Çalışmadan önce taranıyor", level: "ok" }
        if (s.prevent_state === "error") return { text: "Hizmet hata verdi", level: "bad" }
        return { text: "Başlıyor…", level: "warn" }
    }
    function levelColor(l) { return l === "ok" ? Theme.ok : (l === "warn" ? Theme.warn : (l === "idle" ? Theme.muted : Theme.bad)) }

    function kindName(k) { return k === "quick" ? "Hızlı tarama" : (k === "full" ? "Tam tarama" : (k === "custom" ? "Özel tarama" : "Tarama")) }
    function fmt(epoch) { const e = parseInt(epoch); return e > 0 ? Qt.formatDateTime(new Date(e * 1000), "dd.MM.yyyy HH:mm") : "-" }
    function sizeText(b) {
        const n = parseInt(b)
        if (isNaN(n)) return ""
        return n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"
    }

    readonly property string healthTitle: health === "ok" ? "Cihazın korunuyor" : (health === "warn" ? "Dikkat gerekiyor" : "Eylem gerekli")
    readonly property string healthSub: {
        if (s.engine === "missing") return "ClamAV kurulu değil (sudo pacman -S clamav)."
        if (activeThreats > 0) return activeThreats + " etkin tehdit için işlem bekleniyor."
        if (ransomRecent) return "Son 24 saatte fidye yazılımı şüphesi: " + s.last_ransom_reason + " (" + fmt(s.last_ransom_time) + ")."
        if (s.defs === "missing") return "Virüs tanımları henüz indirilmedi."
        if (s.defs === "old") return "Virüs tanımları " + s.defs_age + " gün önce güncellendi."
        if (s.realtime !== "on") return s.realtime === "starting" ? "Gerçek zamanlı koruma başlıyor." : "Gerçek zamanlı koruma kapalı."
        if (parseInt(s.last_scan_time || "0") === 0) return "Henüz tarama yapılmadı."
        return "Son tarama " + fmt(s.last_scan_time) + "."
    }
    readonly property string rtText: s.realtime === "on" ? "Açık" : (s.realtime === "starting" ? "Başlıyor…" : (s.realtime === "error" ? "Hata (günlüğe bak)" : "Kapalı"))
    readonly property string defsText: s.defs === "ok" ? ("Güncel · sürüm " + (s.defs_version || "?")) : (s.defs === "old" ? ("Eski · " + s.defs_age + " gün") : "Yok · indirilmeli")
    readonly property string lastScanText: {
        if (scanning) return counting ? "Dosyalar sayılıyor…" : (kindName(s.kind) + " sürüyor")
        if (parseInt(s.last_scan_time || "0") === 0) return "Henüz taranmadı"
        const r = s.last_scan_result
        return kindName(s.last_scan_kind) + " · " + (r === "clean" ? "temiz" : (r === "threats" ? (s.last_scan_threats + " tehdit") : "durduruldu"))
    }

    function parseKV(text) {
        const o = {}
        text.split("\n").forEach(l => { const i = l.indexOf("="); if (i > 0) o[l.substring(0, i)] = l.substring(i + 1) })
        return o
    }
    function rows(text) { return text.split("\n").filter(l => l.trim() !== "").map(l => l.split("\t")) }

    function refresh() { statusProc.running = false; statusProc.running = true }
    function loadLists() {
        qProc.running = false; qProc.running = true
        hProc.running = false; hProc.running = true
        tProc.running = false; tProc.running = true
        eProc.running = false; eProc.running = true
        aProc.running = false; aProc.running = true
        iProc.running = false; iProc.running = true
    }
    function reloadSoon() { afterTimer.restart() }

    // ---- eylemler ----
    function scan(kind, path) {
        const c = ["schway-defender", "scan", kind]
        if (path) c.push(path)
        Quickshell.execDetached(c)
        const o = Object.assign({}, s); o.state = "counting"; o.kind = kind; o.done = "0"; o.total = "0"; s = o
        afterTimer.restart()
    }
    function checkIntegrity() {
        Quickshell.execDetached(["schway-defender", "integrity"])
        const o = Object.assign({}, s); o.integrity_state = "running"; s = o
        afterTimer.restart()
    }
    function cancel() { Quickshell.execDetached(["schway-defender", "cancel"]); afterTimer.restart() }
    function update() { Quickshell.execDetached(["schway-defender", "update"]); updating = true; updTimer.restart(); afterTimer.restart() }
    property bool updating: false
    function setCfg(k, v) {
        const o = Object.assign({}, s); o["cfg_" + k] = String(v)
        if (k === "realtime") o.realtime = String(v) === "1" ? "starting" : "off"
        s = o
        Quickshell.execDetached(["schway-defender", "config", "set", k, String(v)])
        afterTimer.restart()
    }
    function setFirewall(on) {
        const o = Object.assign({}, s); o.firewall = on ? "on" : "off"; s = o
        Quickshell.execDetached(["schway-settings", "set", "firewall", on ? "1" : "0"])
        afterTimer.restart()
    }
    function cmd(args) { Quickshell.execDetached(["schway-defender"].concat(args)); afterTimer.restart() }

    Process {
        id: statusProc
        command: ["schway-defender", "status"]
        stdout: StdioCollector { onStreamFinished: { root.s = root.parseKV(text); root.loaded = true } }
    }
    Process {
        id: qProc
        command: ["schway-defender", "quarantine", "list"]
        stdout: StdioCollector {
            onStreamFinished: root.quarantine = root.rows(text).map(r => ({ id: r[0], time: r[1], sig: r[2], path: r[3], size: r[4] })).reverse()
        }
    }
    Process {
        id: hProc
        command: ["schway-defender", "history", "60"]
        stdout: StdioCollector {
            onStreamFinished: root.history = root.rows(text).map(r => ({ time: r[0], kind: r[1], action: r[2], detail: r[3] || "", path: r[4] || "" }))
        }
    }
    Process {
        id: tProc
        command: ["schway-defender", "threats"]
        stdout: StdioCollector {
            onStreamFinished: root.threats = root.rows(text).map(r => ({ path: r[0], sig: r[1], time: r[2] }))
        }
    }
    Process {
        id: aProc
        command: ["schway-defender", "allowed", "list"]
        stdout: StdioCollector {
            onStreamFinished: root.allowed = root.rows(text).map(r => ({ hash: r[0], path: r[1] || "", sig: r[2] || "", time: r[3] }))
        }
    }
    Process {
        id: iProc
        command: ["schway-defender", "integrity", "list"]
        stdout: StdioCollector {
            onStreamFinished: root.integrity = root.rows(text).map(r => ({ pkg: r[0], path: r[1] || "", problem: r[2] || "" }))
        }
    }
    Process {
        id: eProc
        command: ["schway-defender", "exclude", "list"]
        stdout: StdioCollector {
            onStreamFinished: root.exclusions = text.split("\n").filter(l => l.trim() !== "" && l.indexOf("(dışlama yok)") < 0)
        }
    }

    // Eylemden kısa süre sonra durum ve listeler yenilenir
    Timer { id: afterTimer; interval: 1500; onTriggered: { root.refresh(); root.loadLists() } }
    Timer { id: updTimer; interval: 20000; onTriggered: { root.updating = false; root.refresh() } }

    // Pencere açıkken ya da tarama sürerken sık, değilse seyrek yokla
    Timer {
        interval: (root.scanning || Ui.securityOpen) ? 2000 : 30000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: { root.refresh(); if (root.scanning || Ui.securityOpen) root.loadLists() }
    }
    Connections {
        target: Ui
        function onSecurityOpenChanged() { if (Ui.securityOpen) { root.refresh(); root.loadLists() } }
    }
}
