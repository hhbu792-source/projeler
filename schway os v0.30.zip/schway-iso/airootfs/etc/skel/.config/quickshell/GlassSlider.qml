import QtQuick

// Kaydırıcı. segmented: kademeli gösterge (ses/parlaklık), değilse ince ray + tutamaç.
Item {
    id: root
    property real value: 0
    property bool segmented: false
    property int ticks: 30
    signal moved(real v)
    implicitHeight: 24
    readonly property real v: Math.max(0, Math.min(1, value))

    // Sürekli kip
    Item {
        visible: !root.segmented
        anchors.fill: parent
        Rectangle {
            y: (parent.height - height) / 2
            width: parent.width
            height: 4
            radius: 2
            color: Theme.track
            Rectangle { width: parent.width * root.v; height: parent.height; radius: 2; color: Theme.accent }
        }
        Rectangle {
            anchors.verticalCenter: parent.verticalCenter
            x: Math.max(0, Math.min(root.width - width, root.width * root.v - width / 2))
            width: 8
            height: area.pressed ? 22 : 20
            radius: 3
            color: area.pressed ? Theme.accentDark : Theme.text
            Behavior on height { NumberAnimation { duration: 80 } }
        }
    }

    // Kademeli kip
    TickMeter {
        visible: root.segmented
        anchors.fill: parent
        value: root.v
        ticks: root.ticks
    }

    MouseArea {
        id: area
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        function setFrom(mx) { root.moved(Math.max(0, Math.min(1, mx / width))) }
        onPressed: mouse => setFrom(mouse.x)
        onPositionChanged: mouse => { if (pressed) setFrom(mouse.x) }
    }
}
