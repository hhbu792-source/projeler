import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

PanelWindow {
    id: win
    visible: Ui.welcomeOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-welcome"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.welcomeOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property int page: 0
    // Canlı ISO'da mı (kurulum öncesi) yoksa kurulu sistemde mi?
    property bool live: false
    readonly property var steps: live
        ? ["Hoş geldin", "Tercihler", "Paket setleri", "Disk ve kurulum"]
        : ["Hoş geldin", "Sürücüler", "Erişim engelleri", "Paket setleri", "Oyun modu", "Sistem yedekleri", "Görünüm", "Ek uygulamalar", "Hazırsın"]
    readonly property int lastPage: steps.length - 1
    // Kurulum tercihleri (canlıda seçilir, kurulan sisteme aktarılır)
    property bool optZapret: false
    property bool optGame: false
    property bool setGaming: false
    property bool setOffice: false
    property bool setServer: false
    property bool setApps: false
    property var diskRows: []

    Component.onCompleted: Quickshell.execDetached(["schway-choices", "set", "set_gaming", "1"])

    function setChoice(key, value) {
        Quickshell.execDetached(["schway-choices", "set", key, value ? "1" : "0"])
    }

    function term(args) { Quickshell.execDetached(["foot", "-e"].concat(args)) }
    function finish() {
        Quickshell.execDetached(["sh", "-c", "mkdir -p \"$HOME/.config/schway\" && touch \"$HOME/.config/schway/.welcome-done\""])
        Ui.welcomeOpen = false
        if (!live) Quickshell.execDetached(["schway-firstlogin", "all"])
    }

    // Canlı ISO: karşılama menüsü (seçimler) kapanınca kurulum sihirbazı kendiliğinden açılır
    Connections {
        target: Ui
        function onWelcomeOpenChanged() { if (!Ui.welcomeOpen && win.live) Quickshell.execDetached(["schway-install", "auto"]) }
    }

    Process {
        id: liveProc
        running: true
        command: ["sh", "-c", "test -d /run/archiso"]
        onExited: (code, status) => { win.live = (code === 0) }
    }
    Process {
        id: choiceProc
        command: ["sh", "-c", "if test -d /run/archiso; then schway-choices dump; else test -f \"$HOME/.config/schway/advanced-game\" && echo ADVANCED_GAME=1; grep -x ZAPRET=1 /var/lib/schway/install-choices.conf; fi 2>/dev/null; true"]
        stdout: StdioCollector {
            onStreamFinished: {
                win.optZapret = text.indexOf("ZAPRET=1") >= 0
                win.optGame = text.indexOf("ADVANCED_GAME=1") >= 0
                win.setGaming = text.indexOf("SET_GAMING=1") >= 0
                win.setOffice = text.indexOf("SET_OFFICE=1") >= 0
                win.setServer = text.indexOf("SET_SERVER=1") >= 0
                win.setApps = text.indexOf("SET_APPS=1") >= 0
            }
        }
    }
    // Disk listesi (canlı ISO, disk sayfası)
    Process {
        id: diskProc
        command: ["schway-disks"]
        stdout: StdioCollector {
            onStreamFinished: {
                var rows = []
                var lines = text.split("\n")
                for (var i = 0; i < lines.length; i++) {
                    var f = lines[i].split("|")
                    if (f.length < 4) continue
                    rows.push({ kind: f[0], dev: f[1], size: f[2], a: f[3], b: f[4] || "", c: f[5] || "" })
                }
                win.diskRows = rows
            }
        }
    }
    function refreshDisks() { diskProc.running = false; diskProc.running = true }
    onPageChanged: if (live && page === 3) refreshDisks()

    Connections {
        target: Ui
        function onWelcomeOpenChanged() {
            if (Ui.welcomeOpen) { win.page = 0; choiceProc.running = true; keyItem.forceActiveFocus() }
        }
    }

    Item {
        id: keyItem
        focus: true
        Keys.onEscapePressed: Ui.welcomeOpen = false
        Keys.onRightPressed: if (win.page < win.lastPage) win.page++
        Keys.onLeftPressed: if (win.page > 0) win.page--
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, (Theme.scrim.a + 0.06) * card.opacity)
    }

    Shadow { target: card }

    Rectangle {
        id: card
        width: 860
        height: 600
        anchors.centerIn: parent
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        clip: true
        opacity: Ui.welcomeOpen ? 1 : 0
        transform: Translate { y: Ui.welcomeOpen ? 0 : 10; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // ---- Sol: adımlar ----
            Rectangle {
                Layout.preferredWidth: 232
                Layout.fillHeight: true
                color: Theme.well
                Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.line }

                ColumnLayout {
                    anchors { fill: parent; topMargin: 26; bottomMargin: 22; leftMargin: 24; rightMargin: 20 }
                    spacing: 0

                    Image { source: Theme.logo; sourceSize: Qt.size(96, 96); Layout.preferredWidth: 38; Layout.preferredHeight: 38; smooth: true }
                    Text { Layout.topMargin: 12; text: "Schway"; color: Theme.text; font.family: Theme.font; font.pixelSize: 19; font.weight: Font.Medium }
                    Text { text: win.live ? "Canlı oturum" : "İlk açılış"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }

                    Column {
                        Layout.topMargin: 30
                        Layout.fillWidth: true
                        spacing: 0
                        Repeater {
                            model: win.steps
                            delegate: Item {
                                id: step
                                required property string modelData
                                required property int index
                                readonly property bool cur: index === win.page
                                readonly property bool done: index < win.page
                                width: parent.width
                                height: 34

                                // Adımları bağlayan çizgi
                                Rectangle {
                                    visible: step.index < win.lastPage
                                    x: 7; y: 24
                                    width: 2; height: 20
                                    radius: 1
                                    color: step.done ? Theme.accentEdge : Theme.line
                                }
                                Rectangle {
                                    x: 0; y: 9
                                    width: 16; height: 16; radius: 8
                                    color: step.cur ? Theme.accentSoft : "transparent"
                                    Rectangle {
                                        anchors.centerIn: parent
                                        width: step.cur ? 8 : 8; height: width; radius: 4
                                        color: step.cur || step.done ? Theme.accent : Theme.track
                                    }
                                }
                                Text {
                                    anchors { left: parent.left; leftMargin: 28; right: parent.right; verticalCenter: parent.verticalCenter }
                                    text: step.modelData
                                    elide: Text.ElideRight
                                    color: step.cur ? Theme.text : (stepArea.containsMouse ? Theme.text : Theme.muted)
                                    font.family: Theme.font
                                    font.pixelSize: 13
                                    font.weight: step.cur ? Font.Medium : Font.Normal
                                }
                                MouseArea { id: stepArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.page = step.index }
                            }
                        }
                    }

                    Item { Layout.fillHeight: true }

                    Row {
                        spacing: 6
                        Keycap { text: "Super" }
                        Keycap { text: "W" }
                    }
                    Text { Layout.topMargin: 8; text: "ile bu ekranı yeniden aç"; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                }
            }

            // ---- Sağ: sayfa ----
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.topMargin: 30
                Layout.bottomMargin: 22
                Layout.leftMargin: 38
                Layout.rightMargin: 34
                spacing: 14

                // ---- Canlı ISO: kurulum öncesi tercihler ----
                StackLayout {
                    visible: win.live
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    currentIndex: win.page

                    WPage {
                        iconSource: Theme.logo
                        pageTitle: "Schway'e hoş geldin"
                        pageBody: "Şu an Schway'i canlı olarak deniyorsun, hiçbir şey diske yazılmadı. Sonraki adımlarda kurulum tercihlerini seçip diski hazırlayabilirsin."
                    }
                    ColumnLayout {
                        spacing: 10
                        PageHead {
                            title: "Tercihlerin"
                            body: "Seçimlerin kurulan sisteme aktarılır ve ilk girişte uygulanır. Hepsini sonradan da değiştirebilirsin."
                        }
                        Item { Layout.preferredHeight: 8 }
                        Toggle {
                            title: "Gelişmiş oyun modu"
                            body: "Oyun modundayken işlemci performans kipine geçer, split-lock yavaşlatması kapanır. Normal oyun modu (Super+G) bunsuz da vardır. Pil ve ısı biraz artar."
                            checked: win.optGame
                            onToggled: (v) => { win.optGame = v; win.setChoice("advanced_game", v) }
                        }
                        Toggle {
                            title: "Erişim engelleri (zapret)"
                            body: "Discord gibi engelli sitelere erişim için ilk girişte zapret kurulumu başlar. İnternet gerekir; Türksat Kablonet için hazır ayar denenir."
                            checked: win.optZapret
                            onToggled: (v) => { win.optZapret = v; win.setChoice("zapret", v) }
                        }
                        Item { Layout.fillHeight: true }
                    }
                    ColumnLayout {
                        spacing: 8
                        PageHead {
                            title: "Paket setleri"
                            body: "Kurulu sistemde olmasını istediklerini seç. Seçilenler ilk girişte internetten kurulur; sonradan schway-sets ile de eklenebilir."
                        }
                        Item { Layout.preferredHeight: 6 }
                        Toggle {
                            title: "Oyun ve Windows uyumu (zorunlu)"
                            body: "Wine, Steam, Lutris, MangoHud, GameMode, 32 bit sürücüler. Her kurulumda seçili gelir, kapatılamaz."
                            checked: true
                            locked: true
                        }
                        Toggle {
                            title: "Ofis"
                            body: "LibreOffice (Türkçe)."
                            checked: win.setOffice
                            onToggled: (v) => { win.setOffice = v; win.setChoice("set_office", v) }
                        }
                        Toggle {
                            title: "Sunucu ve geliştirici"
                            body: "ssh, docker, nginx, postgresql, ufw. Servisler schway-server ile başlatılır."
                            checked: win.setServer
                            onToggled: (v) => { win.setServer = v; win.setChoice("set_server", v) }
                        }
                        Toggle {
                            title: "Ek uygulamalar"
                            body: "Spotify, Prism Launcher (Minecraft), Bottles, ProtonUp-Qt (Flathub)."
                            checked: win.setApps
                            onToggled: (v) => { win.setApps = v; win.setChoice("set_apps", v) }
                        }
                        Item { Layout.fillHeight: true }
                    }
                    ColumnLayout {
                        spacing: 10
                        PageHead {
                            title: "Disk ve kurulum"
                            body: "Kurulum aracında tüm diski silebilir, Windows'un yanına kurabilir ya da elle bölebilirsin. Bölümleri önceden düzenlemek istersen GParted'ı aç."
                        }
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 176
                            radius: Theme.rGroup
                            color: Theme.well
                            border.width: 1
                            border.color: Theme.line
                            clip: true
                            ListView {
                                anchors { fill: parent; margins: 6 }
                                spacing: 1
                                clip: true
                                model: win.diskRows
                                boundsBehavior: Flickable.StopAtBounds
                                delegate: Item {
                                    id: dr
                                    required property var modelData
                                    readonly property bool disk: modelData.kind === "D"
                                    width: ListView.view.width
                                    height: disk ? 30 : 26
                                    Row {
                                        anchors { left: parent.left; leftMargin: dr.disk ? 10 : 28; verticalCenter: parent.verticalCenter }
                                        spacing: 14
                                        Text {
                                            text: dr.modelData.dev
                                            color: dr.disk ? Theme.text : Theme.muted
                                            font.family: Theme.mono
                                            font.pixelSize: 12
                                            font.weight: dr.disk ? Font.Medium : Font.Normal
                                        }
                                        Text { text: dr.modelData.size; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                        Text {
                                            text: dr.disk ? dr.modelData.a : (dr.modelData.a || "biçimsiz")
                                            color: Theme.muted
                                            font.family: Theme.font
                                            font.pixelSize: 13
                                        }
                                        Text {
                                            visible: dr.disk ? dr.modelData.c === "usb" : dr.modelData.a === "ntfs"
                                            text: dr.disk ? "canlı USB, buraya kurma" : "Windows olabilir"
                                            color: dr.disk ? Theme.warn : Theme.accentDark
                                            font.family: Theme.font
                                            font.pixelSize: 12
                                        }
                                        Text {
                                            visible: !dr.disk && dr.modelData.b !== ""
                                            text: dr.modelData.b
                                            color: Theme.faint
                                            font.family: Theme.font
                                            font.pixelSize: 12
                                        }
                                    }
                                }
                            }
                        }
                        RowLayout {
                            spacing: 10
                            Chip { text: "Yenile"; onClicked: win.refreshDisks() }
                            Chip { text: "Diski GParted ile bölümle"; onClicked: Quickshell.execDetached(["schway-partition"]) }
                            Chip {
                                text: "Kurulumu başlat"
                                primary: true
                                onClicked: { Quickshell.execDetached(["schway-install"]); win.finish() }
                            }
                        }
                        Text {
                            Layout.fillWidth: true
                            text: "Şimdi kurmak istemiyorsan \"Bitir\" ile kapat; kurulum aracı masaüstündeki \"Schway'i Kur\" simgesinde ve panelde durur."
                            wrapMode: Text.Wrap
                            color: Theme.muted
                            font.family: Theme.font
                            font.pixelSize: 13
                        }
                        Item { Layout.fillHeight: true }
                    }
                }

                // ---- Kurulu sistem: ilk açılış ----
                StackLayout {
                    visible: !win.live
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    currentIndex: win.page

                    WPage {
                        iconSource: Theme.logo
                        pageTitle: "Schway'e hoş geldin"
                        pageBody: "Kurulum tamamlandı. Birkaç adımda sistemi tamamlayalım. İstediğin adımı atlayabilirsin."
                    }
                    WPage {
                        pageTitle: "Sürücüler"
                        pageBody: "Ekran kartı, Wi-Fi ve Bluetooth sürücüleri tespit edilip kurulur. İnternet gerekir. NVIDIA kartlarda derleme birkaç dakika sürer. Çoğu sistemde bu zaten ilk açılışta kendiliğinden yapılır."
                        actionText: "Sürücüleri tespit et ve kur"
                        onAction: win.term(["sudo", "schway-drivers"])
                    }
                    WPage {
                        pageTitle: "Erişim engelleri (zapret)"
                        pageBody: "Discord gibi engelli sitelere erişim için zapret kurulur. Türksat Kablonet için topluluğun bildirdiği hazır ayar sırayla denenir ve her denemede Discord erişimi test edilir. Hiçbiri olmazsa resmi kuruluma geçilir; birkaç soru sorar (nftables, systemd, blockcheck)."
                        actionText: "zapret kurulumunu başlat"
                        onAction: win.term(["sudo", "schway-dpi-setup"])
                    }
                    ColumnLayout {
                        spacing: 14
                        PageHead {
                            title: "Paket setleri"
                            body: "İstediğin setleri şimdi kur (internet gerekir). Durumu görmek için terminalde schway-sets list yaz."
                        }
                        Flow {
                            Layout.fillWidth: true
                            spacing: 10
                            Chip { text: "Oyun ve Windows uyumu"; onClicked: win.term(["sudo", "schway-sets", "install", "gaming"]) }
                            Chip { text: "Ofis"; onClicked: win.term(["sudo", "schway-sets", "install", "office"]) }
                            Chip { text: "Sunucu ve geliştirici"; onClicked: win.term(["sudo", "schway-sets", "install", "server"]) }
                            Chip { text: "Ek uygulamalar"; onClicked: win.term(["sudo", "schway-sets", "install", "apps"]) }
                        }
                        Item { Layout.fillHeight: true }
                    }
                    ColumnLayout {
                        spacing: 14
                        PageHead {
                            title: "Oyun modu"
                            body: "Super+G ile oyun modu açılır; Steam, gamescope ve Wine oyunlarında kendiliğinden açılır. Gelişmiş modda ayrıca işlemci performans kipine geçer."
                        }
                        Toggle {
                            title: "Gelişmiş oyun modu"
                            body: "Oyun modundayken işlemci performans kipine geçer, split-lock yavaşlatması kapanır. Pil ve ısı biraz artar."
                            checked: win.optGame
                            onToggled: (v) => {
                                win.optGame = v
                                Quickshell.execDetached(["schway-game", "advanced", v ? "on" : "off"])
                            }
                        }
                        Item { Layout.fillHeight: true }
                    }
                    WPage {
                        pageTitle: "Sistem yedekleri"
                        pageBody: "Her sistem güncellemesinden önce otomatik anlık görüntü alınır. Bir şey bozulursa terminalde schway-snapshot list ile görüntüleri listele, schway-snapshot rollback <ad> ile geri dön ve yeniden başlat. İlk görüntüyü şimdi alabilirsin."
                        actionText: "İlk anlık görüntüyü al"
                        onAction: win.term(["sudo", "schway-snapshot", "create", "ilk-kurulum"])
                    }
                    ColumnLayout {
                        spacing: 18
                        PageHead {
                            title: "Görünüm"
                            body: "Vurgu rengini seç. Panel ve pencere kenarları hemen değişir; GTK ve Qt uygulamaları yeniden açılınca. Sonra Super+A ile hızlı ayarlardan da değiştirebilirsin."
                        }
                        Row {
                            spacing: 22
                            Repeater {
                                model: [
                                    { n: "blue", c: "#5980FA", t: "Mavi" },
                                    { n: "violet", c: "#8F7CFF", t: "Mor" },
                                    { n: "green", c: "#3DDC97", t: "Yeşil" },
                                    { n: "pink", c: "#FF6FAE", t: "Pembe" },
                                    { n: "orange", c: "#FF9F43", t: "Turuncu" }
                                ]
                                delegate: Column {
                                    id: sw
                                    required property var modelData
                                    readonly property bool current: Theme.accent.toString().toLowerCase() === modelData.c.toLowerCase()
                                    spacing: 8
                                    Item {
                                        width: 44; height: 44
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        Rectangle {
                                            anchors.fill: parent
                                            radius: 22
                                            color: "transparent"
                                            border.width: 2
                                            border.color: sw.current ? Theme.text : "transparent"
                                        }
                                        Rectangle { anchors.centerIn: parent; width: 32; height: 32; radius: 16; color: sw.modelData.c }
                                        MouseArea {
                                            anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: Quickshell.execDetached(["schway-theme", "accent", sw.modelData.n])
                                        }
                                    }
                                    Text {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        text: sw.modelData.t
                                        color: sw.current ? Theme.text : Theme.muted
                                        font.family: Theme.font
                                        font.pixelSize: 13
                                    }
                                }
                            }
                        }
                        Item { Layout.fillHeight: true }
                    }
                    WPage {
                        pageTitle: "Ek uygulamalar"
                        pageBody: "Spotify, Prism Launcher (Minecraft için), Bottles ve ProtonUp-Qt Flathub'dan kurulur. İnternet gerekir. Minecraft'ın kendisi için hesap ve lisans gerekir. Sonra tek tek kurmak için schway-apps install <ad> yaz."
                        actionText: "Dördünü birden kur"
                        onAction: win.term(["sudo", "schway-apps", "install", "all"])
                    }
                    ColumnLayout {
                        spacing: 16
                        PageHead { title: "Hazırsın"; body: "En çok işine yarayacak kısayollar:" }
                        Column {
                            spacing: 10
                            Repeater {
                                model: [
                                    { k: ["Super", "D"], t: "Uygulama paneli" },
                                    { k: ["Super", "A"], t: "Hızlı ayarlar" },
                                    { k: ["Super", "I"], t: "Ayarlar" },
                                    { k: ["Super", "G"], t: "Oyun modu" },
                                    { k: ["Super", "Enter"], t: "Terminal" },
                                    { k: ["Super", "E"], t: "Dosyalar" }
                                ]
                                delegate: Row {
                                    id: kr
                                    required property var modelData
                                    spacing: 14
                                    Row {
                                        width: 130
                                        spacing: 5
                                        Repeater {
                                            model: kr.modelData.k
                                            delegate: Keycap { required property string modelData; text: modelData }
                                        }
                                    }
                                    Text { anchors.verticalCenter: parent.verticalCenter; text: kr.modelData.t; color: Theme.text; font.family: Theme.font; font.pixelSize: 14 }
                                }
                            }
                        }
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.topMargin: 4
                            implicitHeight: cmds.implicitHeight + 24
                            radius: Theme.rGroup
                            color: Theme.well
                            border.width: 1
                            border.color: Theme.line
                            Column {
                                id: cmds
                                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
                                spacing: 7
                                Repeater {
                                    model: [
                                        ["schway-update", "Güncelleme"],
                                        ["schway-ram", "Bellek özeti"],
                                        ["schway-server start", "Sunucu servisleri"],
                                        ["schway-winfonts", "Windows yazı tipleri"]
                                    ]
                                    delegate: Row {
                                        required property var modelData
                                        spacing: 16
                                        Text { width: 160; text: modelData[0]; color: Theme.text; font.family: Theme.mono; font.pixelSize: 12 }
                                        Text { text: modelData[1]; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13 }
                                    }
                                }
                            }
                        }
                        Item { Layout.fillHeight: true }
                    }
                }

                // ---- Alt şerit ----
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Text {
                        text: (win.page + 1) + " / " + (win.lastPage + 1)
                        color: Theme.faint
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                    Item { Layout.fillWidth: true }
                    Chip { visible: win.page > 0; text: "Geri"; onClicked: win.page-- }
                    Chip { visible: win.page < win.lastPage; text: "İleri"; primary: true; onClicked: win.page++ }
                    Chip { visible: win.page === win.lastPage; text: "Bitir"; primary: true; onClicked: win.finish() }
                }
            }
        }
    }
}
