import QtQuick
import QtQuick.Layouts

// Ayarlar satırı. rd: SettingsPages satırı, st: Settings penceresi, last: gruptaki son satır
Item {
    id: root
    property var rd: ({})
    property var st: null
    property bool last: false
    readonly property string kind: rd.t || "note"
    readonly property string key: rd.key || ""
    readonly property string val: st ? String(st.getVal(key)) : ""
    readonly property var optList: rd.opts ? rd.opts : (st ? st.getChoices(key) : [])

    Layout.fillWidth: true
    implicitHeight: content.implicitHeight + 28

    // Satır ayracı
    Rectangle {
        visible: !root.last
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 16 }
        height: 1
        color: Theme.line
    }

    ColumnLayout {
        id: content
        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
        spacing: 10

        RowLayout {
            visible: root.rd.title !== undefined
            Layout.fillWidth: true
            spacing: 16
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 3
                Text {
                    text: root.rd.title || ""
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 14
                    font.weight: Font.Medium
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                }
                Text {
                    visible: !!root.rd.body
                    text: root.rd.body || ""
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 13
                    lineHeight: 1.25
                }
            }
            Text {
                visible: root.kind === "slider"
                text: root.val + (root.rd.suffix || "")
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: 13
                font.weight: Font.Medium
            }
            Flip {
                visible: root.kind === "toggle"
                on: root.val === "1"
                hot: area.containsMouse
            }
        }

        Flow {
            visible: root.kind === "choice" && root.optList.length > 0
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: root.optList
                delegate: Chip {
                    required property var modelData
                    text: modelData[1]
                    fontSize: 13
                    implicitHeight: 28
                    highlighted: root.val === String(modelData[0])
                    onClicked: root.st.setChoice(root.rd, String(modelData[0]))
                }
            }
        }
        Text {
            visible: root.kind === "choice" && root.optList.length === 0
            text: "Kullanılabilir seçenek bulunamadı."
            color: Theme.muted
            font.family: Theme.font
            font.pixelSize: 13
        }

        GlassSlider {
            visible: root.kind === "slider"
            Layout.fillWidth: true
            readonly property real lo: root.rd.min || 0
            readonly property real hi: root.rd.max || 100
            value: hi > lo ? (parseFloat(root.val || "0") - lo) / (hi - lo) : 0
            onMoved: v => root.st.slide(root.rd, lo + v * (hi - lo))
        }

        // Sistem bilgisi: gerçek veri, bu yüzden tek aralıklı yazı
        Rectangle {
            visible: root.kind === "info"
            Layout.fillWidth: true
            implicitHeight: infoText.implicitHeight + 20
            radius: Theme.rCtl
            color: Theme.well
            Text {
                id: infoText
                anchors { fill: parent; margins: 10 }
                text: root.st ? (root.st.getInfo(root.rd.name) || "\u2014") : ""
                wrapMode: Text.WrapAnywhere
                textFormat: Text.PlainText
                color: Theme.muted
                font.family: Theme.mono
                font.pixelSize: 12
                lineHeight: 1.25
            }
        }

        Chip {
            visible: root.kind === "action"
            text: root.rd.text || ""
            highlighted: !!root.rd.confirm
            onClicked: root.st.doAction(root.rd)
        }
    }

    MouseArea {
        id: area
        anchors.fill: parent
        enabled: root.kind === "toggle"
        hoverEnabled: true
        cursorShape: root.kind === "toggle" ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: root.st.setToggle(root.rd, root.val !== "1")
    }
}
