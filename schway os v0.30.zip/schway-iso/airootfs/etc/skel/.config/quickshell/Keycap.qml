import QtQuick

// Klavye tuşu görünümü (kısayol gösterimi)
Rectangle {
    id: root
    property alias text: label.text
    implicitWidth: Math.max(24, label.implicitWidth + 14)
    implicitHeight: 24
    radius: Theme.rSm
    color: Theme.surface
    border.width: 1
    border.color: Theme.border

    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 4; rightMargin: 4; bottomMargin: 1 }
        height: 1
        color: Theme.press
    }
    Text {
        id: label
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -1
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: 12
        font.weight: Font.Medium
    }
}
