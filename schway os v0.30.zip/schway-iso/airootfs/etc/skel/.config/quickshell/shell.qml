import Quickshell
import Quickshell.Io
import QtQuick

ShellRoot {
    TopBar {}
    Dock {}
    DesktopIcons {}
    Launcher {}
    ControlCenter {}
    NotificationPopups {}
    OSD {}
    Welcome {}
    Settings {}
    Security {}
    PasswordSetup {}

    // İlk girişte karşılama ekranını aç: canlı ISO'da kurulum tercihleri, kurulu sistemde ilk açılış sayfaları
    Process {
        running: true
        command: ["sh", "-c", "[ ! -f \"$HOME/.config/schway/.welcome-done\" ] && ! grep -qw schway.direct /proc/cmdline"]
        onExited: (code, status) => { if (code === 0) Ui.welcomeOpen = true }
    }

    // Hyprland kısayolları bunları çağırır:  qs ipc call launcher toggle
    IpcHandler {
        target: "launcher"
        function toggle(): void { Ui.launcherOpen = !Ui.launcherOpen }
    }
    IpcHandler {
        target: "controlcenter"
        function toggle(): void { Ui.controlOpen = !Ui.controlOpen }
    }
    IpcHandler {
        target: "settings"
        function toggle(): void { Ui.settingsOpen = !Ui.settingsOpen }
    }
    IpcHandler {
        target: "password"
        function open(): void { Ui.passwordOpen = true }
    }
    IpcHandler {
        target: "security"
        function toggle(): void { Ui.securityOpen = !Ui.securityOpen }
        function open(page: int): void { Ui.securityPage = page; Ui.securityOpen = true }
    }
    IpcHandler {
        target: "welcome"
        function toggle(): void { Ui.welcomeOpen = !Ui.welcomeOpen }
    }
}
