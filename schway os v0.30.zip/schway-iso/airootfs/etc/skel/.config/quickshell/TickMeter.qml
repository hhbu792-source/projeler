import QtQuick

// Kademeli gösterge: Schway'in imza öğesi (ses, parlaklık, bellek, OSD). Yalnızca gösterir; tıklamayı üstündeki öğe yönetir.
Row {
    id: root
    property real value: 0
    property int ticks: 30
    property int gap: 3
    property color lit: Theme.accent
    property color unlit: Theme.track
    spacing: gap

    Repeater {
        model: root.ticks
        Rectangle {
            required property int index
            width: Math.max(1, (root.width - (root.ticks - 1) * root.gap) / root.ticks)
            height: root.height
            radius: Math.min(1.5, width / 2)
            color: (index + 0.5) / root.ticks <= root.value ? root.lit : root.unlit
            Behavior on color { ColorAnimation { duration: 90 } }
        }
    }
}
