import QtQuick
import QtQuick.Layouts

// Güvenlik uygulaması için açma/kapama satırı. Durum dışarıdan bağlanır, tıklama toggled(yeniDeğer) yollar.
Item {
    id: root
    property string title: ""
    property string body: ""
    property string status: ""          // örn. "3.412 alan adı engelli"; boşsa gösterilmez
    property color statusColor: Theme.ok
    property bool on: false
    property bool last: false
    signal toggled(bool value)

    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 28

    Rectangle {
        visible: !root.last
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 16 }
        height: 1
        color: Theme.line
    }
    RowLayout {
        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 16; rightMargin: 16 }
        spacing: 16
        ColumnLayout {
            id: col
            Layout.fillWidth: true
            spacing: 3
            Text { text: root.title; color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.Medium; Layout.fillWidth: true; wrapMode: Text.Wrap }
            Text { visible: root.body !== ""; text: root.body; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; lineHeight: 1.25; Layout.fillWidth: true; wrapMode: Text.Wrap }
            Row {
                visible: root.status !== ""
                spacing: 6
                Layout.topMargin: 2
                Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 6; height: 6; radius: 3; color: root.statusColor }
                Text { text: root.status; color: root.statusColor; font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Medium }
            }
        }
        Flip { on: root.on; hot: area.containsMouse }
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.toggled(!root.on)
    }
}
