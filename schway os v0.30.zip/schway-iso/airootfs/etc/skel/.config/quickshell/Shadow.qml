import QtQuick

// Yumuşak gölge: üst üste binen yarı saydam yuvarlak dikdörtgenler (shader yok, RAM dostu).
// Kullanım: kartın kardeşi olarak, kartın altına:  Shadow { target: card }
Item {
    id: root
    property Item target
    property real radius: Theme.rWin
    property real spread: 26
    property real strength: 0.26
    property real yOffset: 10
    readonly property int steps: 9

    x: target ? target.x : 0
    y: target ? target.y : 0
    width: target ? target.width : 0
    height: target ? target.height : 0
    opacity: target ? target.opacity : 0
    scale: target ? target.scale : 1
    visible: opacity > 0.01

    Repeater {
        model: root.steps
        Rectangle {
            required property int index
            readonly property real grow: (index + 1) * root.spread / root.steps
            x: -grow
            y: -grow + root.yOffset
            width: root.width + grow * 2
            height: root.height + grow * 2
            radius: root.radius + grow
            color: "black"
            opacity: root.strength / root.steps * 1.5
        }
    }
}
