import QtQuick

// Hızlı ayar düğmesi: simge + ad + durum
Rectangle {
    id: root
    property string label: ""
    property string glyph: ""
    property string status: ""
    property bool on: false
    signal clicked()

    implicitHeight: 58
    radius: Theme.rGroup
    color: on ? (area.pressed ? Theme.accentDark : Theme.accent) : (area.pressed ? Theme.press : (area.containsMouse ? Theme.hover : Theme.surface))
    border.width: 1
    border.color: on ? "transparent" : Theme.line
    Behavior on color { ColorAnimation { duration: 130 } }

    Row {
        anchors { left: parent.left; leftMargin: 14; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
        spacing: 12
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: root.glyph
            color: root.on ? Theme.onAccent : Theme.muted
            font.family: Theme.iconFont
            font.pixelSize: 20
        }
        Column {
            anchors.verticalCenter: parent.verticalCenter
            spacing: 1
            Text {
                text: root.label
                color: root.on ? Theme.onAccent : Theme.text
                font.family: Theme.font
                font.pixelSize: 14
                font.weight: Font.Medium
            }
            Text {
                visible: root.status !== ""
                text: root.status
                color: root.on ? Qt.alpha(Theme.onAccent, 0.72) : Theme.muted
                font.family: Theme.font
                font.pixelSize: 12
            }
        }
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
