import Quickshell
import Quickshell.Wayland
import QtQuick

PanelWindow {
    id: win
    visible: popupModel.count > 0
    anchors { top: true; right: true }
    margins { top: 40; right: 12 }
    implicitWidth: 340
    implicitHeight: Math.max(1, column.implicitHeight)
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-notif"
    WlrLayershell.layer: WlrLayer.Overlay

    readonly property int lifetime: 6000

    ListModel { id: popupModel }

    Connections {
        target: Notifs
        function onPopup(n) {
            popupModel.append({ summary: n.summary, body: n.body, app: n.appName, icon: n.appIcon || "" })
            if (popupModel.count > 4) popupModel.remove(0)
        }
    }

    Column {
        id: column
        width: parent.width
        spacing: 8

        Repeater {
            model: popupModel
            delegate: Rectangle {
                id: item
                required property int index
                required property string summary
                required property string body
                required property string app
                required property string icon
                readonly property string iconPath: icon !== "" ? (Quickshell.iconPath(icon, true) || "") : ""
                width: column.width
                height: content.implicitHeight + 28
                radius: 14
                color: Qt.rgba(0.060, 0.072, 0.100, 0.97)
                border.width: 1
                border.color: Theme.border
                opacity: 0
                transform: Translate { id: slide; x: 14 }

                Component.onCompleted: enter.start()
                ParallelAnimation {
                    id: enter
                    NumberAnimation { target: item; property: "opacity"; to: 1; duration: 160; easing.type: Easing.OutCubic }
                    NumberAnimation { target: slide; property: "x"; to: 0; duration: 200; easing.type: Easing.OutCubic }
                }

                Row {
                    id: content
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                    spacing: 12

                    Image {
                        visible: item.iconPath !== ""
                        width: visible ? 32 : 0
                        height: 32
                        sourceSize: Qt.size(64, 64)
                        source: item.iconPath
                    }
                    Column {
                        width: parent.width - (item.iconPath !== "" ? 44 : 0)
                        spacing: 2
                        Text {
                            text: item.app
                            color: Theme.muted
                            font.family: Theme.font
                            font.pixelSize: 12
                        }
                        Text {
                            width: parent.width
                            text: item.summary
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: 14
                            font.weight: Font.Medium
                            wrapMode: Text.Wrap
                        }
                        Text {
                            width: parent.width
                            visible: item.body !== ""
                            text: item.body
                            color: Theme.muted
                            font.family: Theme.font
                            font.pixelSize: 13
                            wrapMode: Text.Wrap
                            maximumLineCount: 4
                            elide: Text.ElideRight
                        }
                    }
                }

                // Kalan süre: alttaki ince çizgi
                Rectangle {
                    anchors { left: parent.left; bottom: parent.bottom; leftMargin: 14; bottomMargin: 1 }
                    height: 2
                    radius: 1
                    color: Theme.accentEdge
                    width: parent.width - 28
                    NumberAnimation on width { from: item.width - 28; to: 0; duration: win.lifetime }
                }

                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: { if (item.app === "Schway Güvenlik") { Ui.securityPage = 1; Ui.securityOpen = true } popupModel.remove(item.index) } }
                Timer { interval: win.lifetime; running: true; onTriggered: popupModel.remove(item.index) }
            }
        }
    }
}
