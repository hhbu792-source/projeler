pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.Notifications

Singleton {
    id: root
    property bool dnd: false
    property var model: server.trackedNotifications
    signal popup(var n)

    NotificationServer {
        id: server
        keepOnReload: true
        bodySupported: true
        actionsSupported: false
        imageSupported: false
        onNotification: n => {
            n.tracked = true
            if (!root.dnd) root.popup(n)
        }
    }
}
