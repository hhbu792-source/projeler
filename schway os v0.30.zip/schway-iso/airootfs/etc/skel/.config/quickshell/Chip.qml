import QtQuick

// Düğme. highlighted: seçili seçenek, primary: ana eylem, danger: geri dönüşsüz eylem
Rectangle {
    id: root
    property alias text: label.text
    property bool highlighted: false
    property bool primary: false
    property bool danger: false
    property int fontSize: 13
    signal clicked()

    implicitWidth: label.implicitWidth + 28
    implicitHeight: 30
    radius: Theme.rCtl
    color: primary ? (area.pressed ? Theme.accentDark : (area.containsMouse ? Qt.lighter(Theme.accent, 1.1) : Theme.accent))
         : highlighted ? Theme.accentSoft
         : danger && area.containsMouse ? Qt.rgba(Theme.bad.r, Theme.bad.g, Theme.bad.b, 0.16)
         : area.pressed ? Theme.press : (area.containsMouse ? Theme.hover : Theme.surface)
    border.width: 1
    border.color: primary ? "transparent" : (highlighted ? Theme.accentEdge : Theme.line)
    scale: area.pressed ? 0.97 : 1
    Behavior on color { ColorAnimation { duration: 110 } }
    Behavior on scale { NumberAnimation { duration: 80 } }

    Text {
        id: label
        anchors.centerIn: parent
        color: root.primary ? Theme.onAccent : (root.danger ? Theme.bad : (root.highlighted ? Theme.accentDark : Theme.text))
        font.family: Theme.font
        font.pixelSize: root.fontSize
        font.weight: root.primary ? Font.Medium : Font.Normal
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
