import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Services.Pipewire
import Quickshell.Services.SystemTray
import Quickshell.Services.UPower
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts

Variants {
    model: Quickshell.screens

    PanelWindow {
        id: win
        required property var modelData
        screen: modelData
        anchors { top: true; left: true; right: true }
        implicitHeight: 30
        color: "transparent"
        WlrLayershell.namespace: "schway-bar"

        PwObjectTracker { objects: [Pipewire.defaultAudioSink] }
        SystemClock { id: clock; precision: SystemClock.Minutes }

        readonly property var activeTop: ToplevelManager.activeToplevel
        readonly property var activeEntry: (activeTop && activeTop.appId) ? DesktopEntries.heuristicLookup(activeTop.appId) : null
        readonly property string activeName: activeTop ? (activeEntry ? activeEntry.name : activeTop.appId) : "Masaüstü"
        readonly property var audio: Pipewire.defaultAudioSink?.audio
        readonly property var bat: UPower.displayDevice
        readonly property int wsId: Hyprland.focusedWorkspace ? Hyprland.focusedWorkspace.id : 1

        Rectangle {
            anchors.fill: parent
            color: Theme.barColor

            Rectangle {
                anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                height: 1
                color: Theme.line
            }

            // ---- Sol: logo, etkin uygulama, çalışma alanları ----
            RowLayout {
                anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                spacing: 12

                Image {
                    source: Theme.logo
                    sourceSize: Qt.size(40, 40)
                    Layout.preferredWidth: 18
                    Layout.preferredHeight: 18
                    fillMode: Image.PreserveAspectFit
                    smooth: true
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -6
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Ui.launcherOpen = !Ui.launcherOpen
                    }
                }
                Text {
                    Layout.maximumWidth: 360
                    text: win.activeName
                    elide: Text.ElideRight
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 13
                    font.weight: Font.Medium
                }
                Row {
                    spacing: 5
                    Layout.leftMargin: 4
                    Repeater {
                        model: Math.max(4, win.wsId)
                        delegate: Rectangle {
                            required property int index
                            readonly property bool cur: index + 1 === win.wsId
                            anchors.verticalCenter: parent.verticalCenter
                            width: cur ? 18 : 6
                            height: 6
                            radius: 3
                            color: cur ? Theme.accent : (wsArea.containsMouse ? Theme.muted : Theme.track)
                            Behavior on width { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                            Behavior on color { ColorAnimation { duration: 100 } }
                            MouseArea {
                                id: wsArea
                                anchors.fill: parent
                                anchors.margins: -4
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: Hyprland.dispatch("workspace " + (index + 1))
                            }
                        }
                    }
                }
            }

            // ---- Sağ: kurulum, tepsi, durum, saat ----
            RowLayout {
                anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                spacing: 14

                Chip {
                    visible: Stats.live
                    text: "Schway'i kur"
                    primary: true
                    fontSize: 12
                    implicitHeight: 22
                    onClicked: Quickshell.execDetached(["schway-install"])
                }

                Row {
                    spacing: 10
                    Repeater {
                        model: SystemTray.items
                        delegate: Item {
                            id: trayItem
                            required property var modelData
                            width: 16
                            height: 16
                            IconImage { anchors.fill: parent; source: trayItem.modelData.icon }
                            QsMenuAnchor {
                                id: menuAnchor
                                menu: trayItem.modelData.menu
                                anchor.window: win
                            }
                            MouseArea {
                                anchors.fill: parent
                                acceptedButtons: Qt.LeftButton | Qt.RightButton
                                cursorShape: Qt.PointingHandCursor
                                onClicked: mouse => {
                                    if (mouse.button === Qt.LeftButton && !trayItem.modelData.onlyMenu) {
                                        trayItem.modelData.activate()
                                    } else if (trayItem.modelData.hasMenu) {
                                        const p = trayItem.mapToItem(null, 0, 0)
                                        menuAnchor.anchor.rect = Qt.rect(p.x, win.height, trayItem.width, 1)
                                        menuAnchor.open()
                                    }
                                }
                            }
                        }
                    }
                }

                Row {
                    spacing: 12
                    Glyph {
                        text: Theme.g.moon
                        visible: Notifs.dnd
                        tint: Theme.accentDark
                        onClicked: Notifs.dnd = !Notifs.dnd
                    }
                    Glyph {
                        visible: Defender.loaded && (Defender.health !== "ok" || Defender.scanning)
                        text: Defender.scanning ? Defender.glyph.scan : Defender.healthGlyph
                        tint: Defender.scanning ? Theme.accentDark : Defender.healthColor
                        hoverTint: Defender.scanning ? Theme.accent : Defender.healthColor
                        onClicked: Ui.securityOpen = !Ui.securityOpen
                    }
                    Glyph {
                        text: Stats.wifiOn ? Theme.g.wifi : Theme.g.wifiOff
                        onClicked: Ui.controlOpen = !Ui.controlOpen
                    }
                    Glyph {
                        text: Theme.volGlyph(win.audio?.volume ?? 0, win.audio?.muted ?? false)
                        onClicked: Ui.controlOpen = !Ui.controlOpen
                    }
                    Row {
                        visible: win.bat && win.bat.isLaptopBattery
                        spacing: 5
                        Glyph {
                            text: (win.bat && win.bat.state === UPowerDeviceState.Charging) ? Theme.g.charging : Theme.g.battery
                            tint: (win.bat && win.bat.percentage < 0.15 && win.bat.state !== UPowerDeviceState.Charging) ? Theme.bad : Theme.muted
                            onClicked: Ui.controlOpen = !Ui.controlOpen
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: Math.round((win.bat ? win.bat.percentage : 0) * 100) + "%"
                            color: Theme.muted
                            font.family: Theme.font
                            font.pixelSize: 12
                        }
                    }
                }

                // Saat: tıklayınca hızlı ayarlar
                Item {
                    implicitWidth: clockRow.implicitWidth
                    implicitHeight: clockRow.implicitHeight
                    Row {
                        id: clockRow
                        spacing: 8
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: Stats.trDay(clock.date)
                            color: Theme.muted
                            font.family: Theme.font
                            font.pixelSize: 13
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: Qt.formatDateTime(clock.date, "HH:mm")
                            color: Theme.text
                            font.family: Theme.font
                            font.pixelSize: 13
                            font.weight: Font.Medium
                        }
                    }
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -6
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Ui.controlOpen = !Ui.controlOpen
                    }
                }
            }
        }
    }
}
