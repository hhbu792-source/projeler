import QtQuick
import QtQuick.Layouts

// Karşılama sayfası başlığı: başlık + açıklama
ColumnLayout {
    id: root
    property string title: ""
    property string body: ""
    property int titleSize: 26
    spacing: 8

    Text {
        text: root.title
        color: Theme.text
        font.family: Theme.font
        font.pixelSize: root.titleSize
        font.weight: Font.Medium
    }
    Text {
        visible: root.body !== ""
        Layout.fillWidth: true
        Layout.maximumWidth: 520
        text: root.body
        wrapMode: Text.Wrap
        color: Theme.muted
        font.family: Theme.font
        font.pixelSize: 15
        lineHeight: 1.35
    }
}
