pragma Singleton
import QtQuick
import Quickshell

// Ayarlar sayfaları. Her satır gerçek bir komuta bağlı (usr/local/bin/schway-settings).
// t: toggle | choice | slider | info | action | note | group
// cap: yalnızca bu yetenek varsa görünür (donanım yoksa hiç gösterilmez)
Singleton {
    readonly property var onoff: [["1", "Açık"], ["0", "Kapalı"]]
    readonly property var accents: [["blue", "Mavi"], ["violet", "Mor"], ["green", "Yeşil"], ["pink", "Pembe"], ["orange", "Turuncu"]]
    readonly property var mins: [["0", "Hiç"], ["1", "1 dk"], ["2", "2 dk"], ["5", "5 dk"], ["10", "10 dk"], ["15", "15 dk"], ["30", "30 dk"], ["60", "1 saat"]]

    // Sidebar: { section } başlık, { id } sayfa
    readonly property var pages: [
        { section: "Sistem" },
        { id: "look", title: "Görünüm ve Kişiselleştirme", sub: "Tema, renk, duvar kâğıdı", rows: [
            { t: "choice", title: "Vurgu rengi", body: "Panel, pencere kenarları, GTK, Qt ve terminal.", key: "accent", opts: accents },
            { t: "choice", title: "Duvar kâğıdı", body: "~/Pictures/Wallpapers klasöründeki görseller.", key: "wallpaper" },
            { t: "action", text: "Duvar kâğıdı klasörünü aç", run: "wallpaper_dir" },
            { t: "choice", title: "İmleç boyutu", key: "cursor_size", cap: "gsettings", opts: [["16", "16"], ["24", "24"], ["32", "32"], ["48", "48"]] },
            { t: "slider", title: "Pencere köşe yuvarlaklığı", key: "rounding", min: 0, max: 24, step: 1, cap: "hypr" },
            { t: "toggle", title: "Pencere animasyonları", key: "animations", cap: "hypr" },
            { t: "note", text: "Açık tema ve ekran koruyucu şimdilik yok." }
        ] },
        { id: "display", title: "Ekran", sub: "Çözünürlük, ölçek, gece ışığı", rows: [
            { t: "info", title: "Bağlı ekranlar", name: "monitors", cap: "monitors" },
            { t: "choice", title: "Ayarlanan ekran", key: "mon", cap: "monitors" },
            { t: "choice", title: "Çözünürlük ve yenileme hızı", key: "mon_mode", cap: "monitors" },
            { t: "choice", title: "Ölçek", key: "mon_scale", cap: "monitors", opts: [["1", "100%"], ["1.25", "125%"], ["1.5", "150%"], ["1.75", "175%"], ["2", "200%"]] },
            { t: "choice", title: "Döndürme", key: "mon_transform", cap: "monitors", opts: [["0", "Normal"], ["1", "90°"], ["2", "180°"], ["3", "270°"]] },
            { t: "toggle", title: "Gece ışığı", body: "Ekranı sıcak renge çevirir.", key: "nightlight", cap: "nightlight" },
            { t: "choice", title: "Renk sıcaklığı", key: "nightlight_temp", cap: "nightlight", opts: [["3500", "3500K"], ["4000", "4000K"], ["4500", "4500K"], ["5000", "5000K"], ["5500", "5500K"]] },
            { t: "choice", title: "Ekranı kapatma süresi", key: "screen_off", cap: "idle", opts: mins },
            { t: "note", text: "Ekran parlaklığı hızlı ayarlardadır (Super+A). HDR desteği yok." }
        ] },
        { id: "network", title: "Ağ ve İnternet", sub: "Wi-Fi, Bluetooth, DNS, VPN", rows: [
            { t: "toggle", title: "Wi-Fi", key: "wifi", cap: "wifi" },
            { t: "toggle", title: "Bluetooth", key: "bluetooth", cap: "bluetooth" },
            { t: "choice", title: "Kayıtlı ağlar", body: "Seçince o ağa bağlanır.", key: "net_saved" },
            { t: "choice", title: "DNS", body: "Etkin bağlantı için.", key: "dns", opts: [["auto", "Otomatik"], ["cloudflare", "Cloudflare"], ["google", "Google"], ["quad9", "Quad9"]] },
            { t: "info", title: "Bağlantı durumu ve IP bilgileri", name: "network" },
            { t: "info", title: "Çevredeki Wi-Fi ağları", name: "wifi_list", cap: "wifi" },
            { t: "action", text: "Ağ, Wi-Fi şifresi ve VPN düzenleyici", run: "nm_editor", cap: "nmeditor" }
        ] },
        { id: "sound", title: "Ses", sub: "Çıkış, giriş, ses düzeyi", cap: "audio", rows: [
            { t: "slider", title: "Ses düzeyi", key: "volume", min: 0, max: 100, step: 1, suffix: "%" },
            { t: "toggle", title: "Sesi kapat", key: "mute" },
            { t: "choice", title: "Çıkış aygıtı", body: "Hoparlör, kulaklık, HDMI.", key: "sink" },
            { t: "slider", title: "Mikrofon düzeyi", key: "mic_volume", min: 0, max: 100, step: 1, suffix: "%" },
            { t: "toggle", title: "Mikrofonu sessize al", key: "mic_mute" },
            { t: "choice", title: "Giriş aygıtı", key: "source" }
        ] },
        { id: "power", title: "Güç ve Pil", sub: "Profiller, uyku, pil", rows: [
            { t: "choice", title: "Güç profili", key: "powerprofile", cap: "powerprofile" },
            { t: "info", title: "Pil", name: "battery", cap: "battery" },
            { t: "choice", title: "Ekranı kapatma süresi", key: "screen_off", cap: "idle", opts: mins },
            { t: "choice", title: "Otomatik uyku", key: "suspend", cap: "idle", opts: mins },
            { t: "choice", title: "Ekranı otomatik kilitle", body: "Boşta kalınca parola ister. Parola belirlenmemişse kilitlenmez.", key: "lock_after", cap: "lock", opts: mins },
            { t: "action", text: "Şimdi kilitle (Super+L)", run: "lock", cap: "lock" },
            { t: "choice", title: "Kapak kapanınca", body: "Yeniden başlatınca geçerli olur. Yönetici izni ister.", key: "lid", cap: "lid", confirm: true,
              opts: [["suspend", "Uyku"], ["ignore", "Hiçbir şey"], ["poweroff", "Kapat"]] },
            { t: "action", text: "Şimdi uyut", run: "suspend" },
            { t: "note", text: "Hazırda bekletme şimdilik yok (takas bölümü olmadığı için)." }
        ] },
        { id: "perf", title: "Performans", sub: "Kaynaklar, oyun modu", rows: [
            { t: "toggle", title: "Oyun modu", body: "Blur, gölge ve animasyonları kapatır (Super+G).", key: "game" },
            { t: "toggle", title: "Gelişmiş oyun modu", body: "Oyun modundayken işlemci performans kipine geçer.", key: "advanced_game" },
            { t: "info", title: "Kaynak kullanımı", name: "perf" },
            { t: "info", title: "Açılışta başlayan uygulamalar", name: "autostart" },
            { t: "info", title: "Çalışan arka plan hizmetleri", name: "services" }
        ] },
        { id: "apps", title: "Uygulamalar", sub: "Paket setleri ve kaynaklar", rows: [
            { t: "info", title: "Paket setleri", name: "sets" },
            { t: "action", text: "Oyun ve Windows uyumunu kur", term: ["sudo", "schway-sets", "install", "gaming"], confirm: true },
            { t: "action", text: "Ofisi kur", term: ["sudo", "schway-sets", "install", "office"], confirm: true },
            { t: "action", text: "Sunucu ve geliştirici setini kur", term: ["sudo", "schway-sets", "install", "server"], confirm: true },
            { t: "action", text: "Ek uygulamaları kur", term: ["sudo", "schway-sets", "install", "apps"], confirm: true },
            { t: "info", title: "Flatpak uygulamaları", name: "flatpaks", cap: "flatpak" },
            { t: "info", title: "Paket kaynağı ve sürüm", name: "pkgsrc" },
            { t: "note", text: "Uygulama kaldırmak için: sudo pacman -Rns <ad>  (Flatpak: flatpak uninstall <ad>)." }
        ] },
        { id: "security", title: "Gizlilik ve Güvenlik", sub: "Güvenlik duvarı, oturumlar", rows: [
            { t: "toggle", title: "Güvenlik duvarı (ufw)", body: "Yönetici izni ister.", key: "firewall", cap: "firewall", confirm: true },
            { t: "info", title: "Güvenlik durumu", name: "security" },
            { t: "info", title: "Son oturumlar", name: "lastlogin" },
            { t: "action", text: "Hata raporu oluştur (~/schway-debug.txt)", run: "debug" },
            { t: "note", text: "Schway tanılama verisi göndermez; rapor yalnızca bu bilgisayarda oluşur. Kamera/mikrofon izin yönetimi şimdilik yok." }
        ] },
        { id: "defender", title: "Virüs ve Tehdit Koruması", sub: "Tarama, gerçek zamanlı koruma, karantina", cap: "defender", rows: [
            { t: "info", title: "Koruma durumu", name: "av_status" },
            { t: "toggle", title: "Gerçek zamanlı koruma", body: "İndirilenler, Masaüstü, Belgeler ve geçici klasörler yazılırken taranır. Açıkken yaklaşık 1 GB RAM kullanır. Yönetici izni ister.", key: "av_realtime", confirm: true },
            { t: "toggle", title: "Bulunan tehditleri otomatik karantinaya al", body: "Kapalıysa tehdit yalnızca listelenir.", key: "av_autoquarantine" },
            { t: "toggle", title: "Virüs tanımlarını otomatik güncelle", key: "av_autoupdate" },
            { t: "choice", title: "Zamanlanmış tarama", body: "Boştayken ve fişe takılıyken; oyun modunda ertelenir.", key: "av_schedule",
              opts: [["off", "Kapalı"], ["daily", "Her gün (hızlı)"], ["weekly", "Haftalık (hızlı)"], ["weekly-full", "Haftalık (tam)"]] },
            { t: "choice", title: "Tarama saati", key: "av_scantime", opts: [["03:00", "03:00"], ["12:00", "12:00"], ["18:00", "18:00"], ["22:00", "22:00"]] },
            { t: "choice", title: "En büyük taranan dosya", key: "av_maxsize", opts: [["25", "25 MB"], ["100", "100 MB"], ["250", "250 MB"], ["500", "500 MB"]] },
            { t: "toggle", title: "Arşivleri tara (zip, rar, 7z)", key: "av_archives" },
            { t: "toggle", title: "İndirme koruması", body: "İndirilenler klasörüne inen riskli dosyalar (exe, sh, zip, pdf...) taranana kadar açılamaz; tehdit varsa karantinaya alınır. Gerçek zamanlı koruma açıkken çalışır.", key: "av_guard" },
            { t: "toggle", title: "Fidye yazılımı koruması", body: "Belgeler, Masaüstü ve Resimler'e gizli tuzak dosyalar koyar; tuzağa dokunulursa ya da kısa sürede çok dosya değişirse uyarır. Engellemez, erken uyarı verir.", key: "av_ransom" },
            { t: "toggle", title: "Web koruması", body: "Bilinen zararlı alan adlarını tüm uygulamalar için engeller (alan adı bazlı; IP ile bağlanmayı ve tarayıcının DNS-over-HTTPS'ini engellemez).", key: "av_web" },
            { t: "toggle", title: "Çalıştırma öncesi engelleme", body: "İndirilenler, /tmp, USB gibi yerlerden çalıştırılan dosya çalışmadan önce taranır; tehdit varsa açılmaz. Gerçek zamanlı korumayı da açar.", key: "av_prevent" },
            { t: "toggle", title: "USB ve harici diskleri otomatik tara", body: "Takılan USB bellek ya da harici disk bağlanınca taranır.", key: "av_usbscan" },
            { t: "toggle", title: "Bildirimler", key: "av_notify" },
            { t: "action", text: "Hızlı tarama başlat", run: "av_quick" },
            { t: "action", text: "Tam tarama başlat", run: "av_full", confirm: true },
            { t: "action", text: "Taramayı durdur", run: "av_cancel" },
            { t: "action", text: "Sistem dosyası bütünlüğünü denetle", run: "av_integrity_run" },
            { t: "info", title: "Bütünlük denetimi", name: "av_integrity" },
            { t: "info", title: "İzin verilen dosyalar", name: "av_allowed" },
            { t: "info", title: "Ek imza kaynakları", name: "av_sources" },
            { t: "action", text: "Virüs tanımlarını şimdi güncelle", run: "av_update" },
            { t: "info", title: "Karantina", name: "av_quarantine" },
            { t: "info", title: "Koruma geçmişi", name: "av_history" },
            { t: "info", title: "Dışlamalar", name: "av_exclusions" },
            { t: "action", text: "Karantinayı boşalt", run: "av_qclear", confirm: true },
            { t: "action", text: "Schway Güvenlik uygulamasını aç (Super+S)", qml: "openSecurity" },
            { t: "note", text: "ClamAV imza tabanlıdır: bilinen zararlıları yakalar, yeni saldırılara karşı tek başına yeterli değildir. Dışlama eklemek ve tehdit işlemleri için Schway Güvenlik uygulamasını kullan." }
        ] },
        { id: "notif", title: "Bildirimler", sub: "Rahatsız etme, geçmiş", rows: [
            { t: "toggle", title: "Rahatsız etme", body: "Açıkken bildirimler pencere olarak çıkmaz.", key: "qml:dnd" },
            { t: "action", text: "Bildirim geçmişini temizle", qml: "clearNotifs" }
        ] },
        { id: "input", title: "Klavye, Fare ve Dokunmatik Yüzey", sub: "Düzen, hız, kaydırma", rows: [
            { t: "choice", title: "Klavye düzeni ve dil", body: "İki düzen seçersen Alt+Shift ile geçersin.", key: "kb_layout", cap: "hypr",
              opts: [["tr", "Türkçe Q"], ["us", "ABD"], ["tr,us", "Türkçe + ABD"], ["us,tr", "ABD + Türkçe"], ["gb", "İngiltere"], ["de", "Almanca"], ["fr", "Fransızca"], ["es", "İspanyolca"], ["ru", "Rusça"]] },
            { t: "slider", title: "Fare hızı", key: "sensitivity", min: -1, max: 1, step: 0.1, cap: "hypr" },
            { t: "choice", title: "Fare ivmesi", key: "accel_profile", cap: "hypr", opts: [["adaptive", "Uyarlanabilir"], ["flat", "Düz"]] },
            { t: "toggle", title: "Doğal kaydırma", key: "natural_scroll", cap: "touchpad" },
            { t: "toggle", title: "Dokunarak tıklama", key: "tap_click", cap: "touchpad" },
            { t: "choice", title: "İmleç boyutu", key: "cursor_size", cap: "gsettings", opts: [["16", "16"], ["24", "24"], ["32", "32"], ["48", "48"]] },
            { t: "info", title: "Kısayol tuşları", name: "shortcuts" },
            { t: "note", text: "Özel kısayol eklemek için ~/.config/hypr/user.conf dosyasına bind satırı yaz." }
        ] },
        { id: "access", title: "Erişilebilirlik", sub: "Yazı boyutu, hareket", rows: [
            { t: "choice", title: "Metin boyutu", body: "GTK uygulamaları için.", key: "text_scale", cap: "gsettings", opts: [["1.0", "100%"], ["1.1", "110%"], ["1.25", "125%"], ["1.5", "150%"]] },
            { t: "choice", title: "İmleç boyutu", key: "cursor_size", cap: "gsettings", opts: [["16", "16"], ["24", "24"], ["32", "32"], ["48", "48"]] },
            { t: "toggle", title: "Azaltılmış hareket", body: "Tüm pencere animasyonlarını kapatır.", key: "reduce_motion", cap: "hypr" },
            { t: "note", text: "Ekran okuyucu, büyüteç, yüksek kontrast ve renk filtreleri şimdilik yok." }
        ] },
        { id: "locale", title: "Dil ve Bölge", sub: "Saat dilimi, saat eşitleme", rows: [
            { t: "info", title: "Sistem dili", name: "locale" },
            { t: "toggle", title: "Otomatik saat eşitleme", body: "Yönetici izni ister.", key: "ntp", cap: "timedate", confirm: true },
            { t: "choice", title: "Saat dilimi", body: "Yönetici izni ister.", key: "timezone", cap: "timedate", confirm: true },
            { t: "note", text: "Klavye dilleri için Klavye sayfasına bak. Sistem dilini değiştirme şimdilik yok." }
        ] },
        { id: "users", title: "Kullanıcılar ve Hesaplar", sub: "Profil, parola", rows: [
            { t: "info", title: "Hesap ve oturumlar", name: "user" },
            { t: "info", title: "Sudo parolası", name: "sudopw", cap: "harden" },
            { t: "action", text: "Sudo parolasını aç (parola belirle)", qml: "openPassword", cap: "harden" },
            { t: "action", text: "Sudo parolasını kapat", term: ["sudo", "schway-harden", "off"], confirm: true, cap: "harden" },
            { t: "action", text: "Parolayı değiştir", term: ["passwd"], confirm: true },
            { t: "toggle", title: "Otomatik giriş", body: "Açılışta parola sormadan masaüstüne girer. Kapalıyken kullanıcı adı ve parola sorulur. Yönetici izni ister.", key: "autologin", cap: "installed", confirm: true },
            { t: "note", text: "Kullanıcı ekleme/kaldırma şimdilik yok. Kullanıcı adı ve parola kurulumda seçilir." }
        ] },
        { id: "system", title: "Sistem ve Güncellemeler", sub: "Sürüm, güncelleme, yeniden başlat", rows: [
            { t: "info", title: "Sürüm bilgisi", name: "system" },
            { t: "action", text: "Anlık görüntü al ve sistemi güncelle", term: ["sudo", "schway-update"], confirm: true },
            { t: "action", text: "Anlık görüntü al", run: "snapshot", confirm: true, cap: "snapshots" },
            { t: "info", title: "Güncelleme geçmişi", name: "updates" },
            { t: "info", title: "Anlık görüntüler", name: "snapshots", cap: "snapshots" },
            { t: "action", text: "Yeniden başlat", run: "reboot", confirm: true },
            { t: "action", text: "Kapat", run: "poweroff", confirm: true },
            { t: "action", text: "Oturumu kapat", run: "logout", confirm: true }
        ] },
        { id: "storage", title: "Depolama", sub: "Diskler, temizlik", rows: [
            { t: "info", title: "Disk ve bölüm kullanımı", name: "storage" },
            { t: "action", text: "Çöp kutusunu boşalt", run: "empty_trash" },
            { t: "action", text: "Paket önbelleğini temizle", run: "clean_cache", confirm: true },
            { t: "action", text: "Günlük kayıtlarını 200 MB'a indir", run: "clean_logs", confirm: true }
        ] },
        { id: "advanced", title: "Gelişmiş Ayarlar", sub: "Hizmetler, günlükler, yedek", rows: [
            { t: "toggle", title: "Geliştirici modu (ssh, docker, nginx, postgresql)", body: "schway-server ile başlatır/durdurur. Yönetici izni ister.", key: "devservices", cap: "devservices", confirm: true },
            { t: "info", title: "Çalışan hizmetler", name: "services" },
            { t: "info", title: "Son hata günlükleri", name: "logs" },
            { t: "info", title: "Ortam değişkenleri", name: "env" },
            { t: "action", text: "Ayar yedeği al (~/schway-ayar-yedegi-*.tar.gz)", run: "backup" },
            { t: "action", text: "Son yedeği geri yükle", run: "restore", confirm: true },
            { t: "action", text: "Hata raporu oluştur", run: "debug" }
        ] },
        { section: "Schway" },
        { id: "glass", title: "Schway Glass", sub: "Cam, bulanıklık, gölge", rows: [
            { t: "toggle", title: "Bulanıklık (blur)", key: "blur", cap: "hypr" },
            { t: "slider", title: "Bulanıklık boyutu", key: "blur_size", min: 1, max: 16, step: 1, cap: "hypr" },
            { t: "slider", title: "Bulanıklık geçişi", key: "blur_passes", min: 1, max: 5, step: 1, cap: "hypr" },
            { t: "toggle", title: "Gölge", key: "shadow", cap: "hypr" },
            { t: "toggle", title: "Pencere animasyonları", key: "animations", cap: "hypr" },
            { t: "slider", title: "Köşe yuvarlaklığı", key: "rounding", min: 0, max: 24, step: 1, cap: "hypr" },
            { t: "note", text: "Panel şeffaflığı şimdilik sabit (Theme.qml). Efektleri kapatmak oyunda performansı artırır." }
        ] },
        { id: "themes", title: "Schway Themes", sub: "Renk, imleç, yedek", rows: [
            { t: "choice", title: "Vurgu rengi", key: "accent", opts: accents },
            { t: "choice", title: "İmleç boyutu", key: "cursor_size", cap: "gsettings", opts: [["16", "16"], ["24", "24"], ["32", "32"], ["48", "48"]] },
            { t: "choice", title: "Duvar kâğıdı", key: "wallpaper" },
            { t: "action", text: "Tema ve ayar yedeği al", run: "backup" },
            { t: "action", text: "Son yedeği geri yükle", run: "restore", confirm: true }
        ] },
        { id: "control", title: "Schway Control", sub: "Kaynaklar ve oyun", rows: [
            { t: "toggle", title: "Oyun modu", key: "game" },
            { t: "toggle", title: "Gelişmiş oyun modu", key: "advanced_game" },
            { t: "choice", title: "Güç profili", key: "powerprofile", cap: "powerprofile" },
            { t: "info", title: "Kaynak kullanımı", name: "perf" },
            { t: "info", title: "Açılışta başlayanlar", name: "autostart" }
        ] },
        { id: "update", title: "Schway Update", sub: "Güncelleme ve geri dönüş", rows: [
            { t: "info", title: "Sürüm", name: "system" },
            { t: "action", text: "Güncelle (önce anlık görüntü alır)", term: ["sudo", "schway-update"], confirm: true },
            { t: "action", text: "Schway masaüstü ayarlarını güncelle", term: ["sudo", "schway-update", "--configs"], confirm: true },
            { t: "action", text: "Geri dönüş noktası oluştur", run: "snapshot", confirm: true, cap: "snapshots" },
            { t: "info", title: "Geri dönüş noktaları", name: "snapshots", cap: "snapshots" },
            { t: "info", title: "Güncelleme geçmişi", name: "updates" },
            { t: "note", text: "Geri alma: schway-snapshot rollback <ad> ya da GRUB menüsündeki Schway anlık görüntüleri." }
        ] }
    ]
}
