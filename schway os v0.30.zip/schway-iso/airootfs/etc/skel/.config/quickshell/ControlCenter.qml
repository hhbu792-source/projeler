import Quickshell
import Quickshell.Wayland
import Quickshell.Services.Pipewire
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

PanelWindow {
    id: win
    visible: Ui.controlOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-cc"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.controlOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property bool wifi: false
    property bool bt: false
    property bool game: false
    property bool hasBacklight: false
    property real brightness: 0.5
    property string armed: ""
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var audio: sink ? sink.audio : null

    PwObjectTracker { objects: [Pipewire.defaultAudioSink] }
    SystemClock { id: clock; precision: SystemClock.Minutes }

    function refresh() {
        wifiProc.running = true
        btProc.running = true
        gameProc.running = true
        briProc.running = true
    }
    function run(cmd) {
        Quickshell.execDetached(cmd)
        refreshTimer.restart()
    }
    // Geri dönüşsüz eylemler iki adımlı: ilk tıklama onay ister
    function arm(id, cmd) {
        if (armed === id) { armed = ""; Quickshell.execDetached(cmd) }
        else { armed = id; armTimer.restart() }
    }

    Connections {
        target: Ui
        function onControlOpenChanged() {
            win.armed = ""
            if (Ui.controlOpen) { win.refresh(); keyItem.forceActiveFocus() }
        }
    }
    Timer { id: refreshTimer; interval: 500; onTriggered: win.refresh() }
    Timer { id: armTimer; interval: 3000; onTriggered: win.armed = "" }

    Process { id: wifiProc; command: ["sh", "-c", "nmcli radio wifi"]
        stdout: StdioCollector { onStreamFinished: win.wifi = text.trim() === "enabled" } }
    Process { id: btProc; command: ["sh", "-c", "bluetoothctl show | grep -q 'Powered: yes' && echo on || echo off"]
        stdout: StdioCollector { onStreamFinished: win.bt = text.trim() === "on" } }
    Process { id: gameProc; command: ["sh", "-c", "test -f \"$XDG_RUNTIME_DIR/schway-game\" && echo on || echo off"]
        stdout: StdioCollector { onStreamFinished: win.game = text.trim() === "on" } }
    Process { id: briProc; command: ["sh", "-c", "brightnessctl -m | cut -d, -f4 | tr -d %"]
        stdout: StdioCollector {
            onStreamFinished: {
                const v = parseInt(text.trim())
                win.hasBacklight = !isNaN(v)
                if (!isNaN(v)) win.brightness = v / 100
            }
        } }

    Item { id: keyItem; focus: true; Keys.onEscapePressed: Ui.controlOpen = false }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, Theme.scrim.a * 0.6 * card.opacity)
        MouseArea { anchors.fill: parent; onClicked: Ui.controlOpen = false }
    }

    Shadow { target: card }

    Rectangle {
        id: card
        width: 380
        anchors { right: parent.right; top: parent.top; bottom: parent.bottom; topMargin: 40; bottomMargin: 12 }
        anchors.rightMargin: Ui.controlOpen ? 12 : -16
        Behavior on anchors.rightMargin { NumberAnimation { duration: 190; easing.type: Easing.OutCubic } }
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        opacity: Ui.controlOpen ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 150 } }

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 16

            // ---- Saat ve tarih ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 12
                Text {
                    text: Qt.formatDateTime(clock.date, "HH:mm")
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 30
                    font.weight: Font.Medium
                }
                Text {
                    Layout.alignment: Qt.AlignBottom
                    Layout.bottomMargin: 4
                    text: Stats.trDate(clock.date)
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 13
                }
                Item { Layout.fillWidth: true }
            }

            // ---- Bellek ve DPI ----
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 7
                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "Bellek"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; Layout.fillWidth: true }
                    Text {
                        text: Stats.ramTotal > 0 ? Stats.ram + " / " + Stats.ramTotal.toFixed(1) + " GB" : "-"
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                }
                TickMeter {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 6
                    ticks: 40
                    gap: 2
                    value: Stats.ramFrac
                    lit: Stats.ramFrac > 0.85 ? Theme.warn : Theme.accent
                }
                RowLayout {
                    spacing: 7
                    Rectangle { Layout.preferredWidth: 6; Layout.preferredHeight: 6; radius: 3; color: Stats.dpi ? Theme.ok : Theme.faint }
                    Text {
                        text: "Erişim engeli aşma " + (Stats.dpi ? "açık" : "kapalı")
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 12
                    }
                }
            }

            // ---- Hızlı düğmeler ----
            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 10
                rowSpacing: 10
                Tile { Layout.fillWidth: true; label: "Wi-Fi"; glyph: win.wifi ? Theme.g.wifi : Theme.g.wifiOff
                    status: win.wifi ? "Açık" : "Kapalı"; on: win.wifi
                    onClicked: win.run(["nmcli", "radio", "wifi", win.wifi ? "off" : "on"]) }
                Tile { Layout.fillWidth: true; label: "Bluetooth"; glyph: Theme.g.bluetooth
                    status: win.bt ? "Açık" : "Kapalı"; on: win.bt
                    onClicked: win.run(["bluetoothctl", "power", win.bt ? "off" : "on"]) }
                Tile { Layout.fillWidth: true; label: "Oyun modu"; glyph: Theme.g.game
                    status: win.game ? "Açık" : "Kapalı"; on: win.game
                    onClicked: win.run(["schway-game", "toggle"]) }
                Tile { Layout.fillWidth: true; label: "Rahatsız etme"; glyph: Theme.g.moon
                    status: Notifs.dnd ? "Açık" : "Kapalı"; on: Notifs.dnd
                    onClicked: Notifs.dnd = !Notifs.dnd }
                Tile { Layout.fillWidth: true; label: "Güvenlik"; glyph: Defender.healthGlyph
                    status: Defender.scanning ? "Taranıyor" : (Defender.health === "ok" ? "Korunuyor" : "Dikkat"); on: Defender.health === "ok"
                    onClicked: { Ui.controlOpen = false; Ui.securityOpen = true } }
            }

            // ---- Ses ve parlaklık ----
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 12
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Glyph {
                        text: Theme.volGlyph(win.audio ? win.audio.volume : 0, win.audio ? win.audio.muted : false)
                        font.pixelSize: 19
                        Layout.preferredWidth: 24
                        horizontalAlignment: Text.AlignHCenter
                        onClicked: { if (win.audio) win.audio.muted = !win.audio.muted }
                    }
                    GlassSlider {
                        Layout.fillWidth: true
                        segmented: true
                        ticks: 28
                        value: (win.audio && !win.audio.muted) ? win.audio.volume : 0
                        onMoved: v => { if (win.audio) { win.audio.muted = false; win.audio.volume = v } }
                    }
                    Text {
                        Layout.preferredWidth: 38
                        horizontalAlignment: Text.AlignRight
                        text: win.audio ? Math.round(win.audio.volume * 100) + "%" : "-"
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                }
                RowLayout {
                    visible: win.hasBacklight
                    Layout.fillWidth: true
                    spacing: 12
                    Text {
                        text: Theme.g.brightness
                        color: Theme.muted
                        font.family: Theme.iconFont
                        font.pixelSize: 19
                        Layout.preferredWidth: 24
                        horizontalAlignment: Text.AlignHCenter
                    }
                    GlassSlider {
                        Layout.fillWidth: true
                        segmented: true
                        ticks: 28
                        value: win.brightness
                        onMoved: v => {
                            win.brightness = v
                            Quickshell.execDetached(["brightnessctl", "set", Math.max(1, Math.round(v * 100)) + "%"])
                        }
                    }
                    Text {
                        Layout.preferredWidth: 38
                        horizontalAlignment: Text.AlignRight
                        text: Math.round(win.brightness * 100) + "%"
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                }
            }

            // ---- Vurgu rengi ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10
                Text {
                    text: "Vurgu rengi"
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 13
                    Layout.fillWidth: true
                }
                Repeater {
                    model: [
                        { n: "blue", c: "#5980FA" },
                        { n: "violet", c: "#8F7CFF" },
                        { n: "green", c: "#3DDC97" },
                        { n: "pink", c: "#FF6FAE" },
                        { n: "orange", c: "#FF9F43" }
                    ]
                    delegate: Item {
                        id: sw
                        required property var modelData
                        readonly property bool current: Theme.accent.toString().toLowerCase() === modelData.c.toLowerCase()
                        Layout.preferredWidth: 24
                        Layout.preferredHeight: 24
                        Rectangle {
                            anchors.fill: parent
                            radius: 12
                            color: "transparent"
                            border.width: 2
                            border.color: sw.current ? Theme.text : "transparent"
                        }
                        Rectangle {
                            anchors.centerIn: parent
                            width: 16; height: 16; radius: 8
                            color: sw.modelData.c
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Quickshell.execDetached(["schway-theme", "accent", sw.modelData.n])
                        }
                    }
                }
            }

            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.line }

            // ---- Bildirimler ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    text: "Bildirimler"
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 14
                    font.weight: Font.Medium
                }
                Text {
                    visible: Notifs.model.values.length > 0
                    text: Notifs.model.values.length
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 13
                }
                Item { Layout.fillWidth: true }
                Chip {
                    visible: Notifs.model.values.length > 0
                    text: "Temizle"
                    fontSize: 12
                    implicitHeight: 24
                    onClicked: Notifs.model.values.slice().forEach(n => n.dismiss())
                }
            }

            ListView {
                id: nList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 8
                model: Notifs.model
                boundsBehavior: Flickable.StopAtBounds

                Column {
                    visible: nList.count === 0
                    anchors.centerIn: parent
                    spacing: 4
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Bildirim yok"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; font.weight: Font.Medium }
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Yeni bildirimler burada birikir."; color: Theme.faint; font.family: Theme.font; font.pixelSize: 12 }
                }

                delegate: Rectangle {
                    id: nItem
                    required property var modelData
                    width: ListView.view.width
                    height: nCol.implicitHeight + 24
                    radius: 10
                    color: Theme.surface
                    border.width: 1
                    border.color: Theme.line

                    Column {
                        id: nCol
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12; rightMargin: 34 }
                        spacing: 2
                        Text { text: nItem.modelData.appName; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                        Text { width: parent.width; text: nItem.modelData.summary; color: Theme.text; font.family: Theme.font; font.pixelSize: 13; font.weight: Font.Medium; wrapMode: Text.Wrap }
                        Text { width: parent.width; visible: nItem.modelData.body !== ""; text: nItem.modelData.body; color: Theme.muted; font.family: Theme.font; font.pixelSize: 13; wrapMode: Text.Wrap; maximumLineCount: 3; elide: Text.ElideRight }
                    }
                    Text {
                        anchors { right: parent.right; top: parent.top; rightMargin: 12; topMargin: 8 }
                        text: "\u00D7"
                        color: closeArea.containsMouse ? Theme.text : Theme.faint
                        font.family: Theme.font
                        font.pixelSize: 18
                        MouseArea { id: closeArea; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: nItem.modelData.dismiss() }
                    }
                }
            }

            // ---- Oturum ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Chip { Layout.fillWidth: true; text: win.armed === "exit" ? "Emin misin?" : "Çıkış"; danger: win.armed === "exit"
                    onClicked: win.arm("exit", ["hyprctl", "dispatch", "exit"]) }
                Chip { Layout.fillWidth: true; text: win.armed === "reboot" ? "Emin misin?" : "Yeniden başlat"; danger: win.armed === "reboot"
                    onClicked: win.arm("reboot", ["systemctl", "reboot"]) }
                Chip { Layout.fillWidth: true; text: win.armed === "off" ? "Emin misin?" : "Kapat"; danger: win.armed === "off"
                    onClicked: win.arm("off", ["systemctl", "poweroff"]) }
            }
        }
    }
}
