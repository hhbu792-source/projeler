import QtQuick

Text {
    id: root
    property color tint: Theme.muted
    property color hoverTint: Theme.text
    signal clicked()
    color: area.containsMouse ? hoverTint : tint
    font.family: Theme.iconFont
    font.pixelSize: 15
    verticalAlignment: Text.AlignVCenter
    Behavior on color { ColorAnimation { duration: 100 } }
    MouseArea {
        id: area
        anchors.fill: parent
        anchors.margins: -5
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
