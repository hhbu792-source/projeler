import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

PanelWindow {
    id: win
    visible: Ui.launcherOpen || card.opacity > 0.01
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-launcher"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.launcherOpen ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    function launch(entry) {
        if (!entry) return
        entry.execute()
        Ui.launcherOpen = false
    }

    Connections {
        target: Ui
        function onLauncherOpenChanged() {
            if (Ui.launcherOpen) {
                search.text = ""
                grid.currentIndex = 0
                search.forceActiveFocus()
            }
        }
    }

    // Arka plan: hafif karartma, tıklayınca kapanır
    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(Theme.scrim.r, Theme.scrim.g, Theme.scrim.b, Theme.scrim.a * card.opacity)
        MouseArea { anchors.fill: parent; onClicked: Ui.launcherOpen = false }
    }

    ScriptModel {
        id: apps
        values: {
            const q = search.text.toLowerCase().trim()
            const all = DesktopEntries.applications.values
            const r = all.filter(a => !a.noDisplay && (q === ""
                || a.name.toLowerCase().includes(q)
                || (a.genericName || "").toLowerCase().includes(q)
                || (a.comment || "").toLowerCase().includes(q)))
            r.sort((a, b) => {
                const as = a.name.toLowerCase().startsWith(q)
                const bs = b.name.toLowerCase().startsWith(q)
                if (as !== bs) return as ? -1 : 1
                return a.name.localeCompare(b.name)
            })
            return r
        }
    }

    Shadow { target: card }

    Rectangle {
        id: card
        width: 760
        height: 520
        anchors.centerIn: parent
        radius: Theme.rWin
        color: Theme.base
        border.width: 1
        border.color: Theme.border
        opacity: Ui.launcherOpen ? 1 : 0
        transform: Translate { y: Ui.launcherOpen ? 0 : 10; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        Behavior on opacity { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }   // karta tıklayınca kapanmasın

        ColumnLayout {
            anchors.fill: parent
            spacing: 0

            // ---- Arama ----
            Item {
                Layout.fillWidth: true
                Layout.preferredHeight: 60

                Text {
                    id: lens
                    anchors { left: parent.left; leftMargin: 24; verticalCenter: parent.verticalCenter }
                    text: Theme.g.search
                    color: search.activeFocus ? Theme.accentDark : Theme.muted
                    font.family: Theme.iconFont
                    font.pixelSize: 18
                }
                TextInput {
                    id: search
                    anchors { left: lens.right; leftMargin: 14; right: parent.right; rightMargin: 24; verticalCenter: parent.verticalCenter }
                    height: 30
                    verticalAlignment: TextInput.AlignVCenter
                    color: Theme.text
                    font.family: Theme.font
                    font.pixelSize: 18
                    selectByMouse: true
                    selectionColor: Theme.accentSoft
                    selectedTextColor: Theme.text
                    onTextChanged: grid.currentIndex = 0

                    Keys.onEscapePressed: Ui.launcherOpen = false
                    Keys.onReturnPressed: win.launch(apps.values[grid.currentIndex])
                    Keys.onEnterPressed: win.launch(apps.values[grid.currentIndex])
                    Keys.onLeftPressed: grid.moveCurrentIndexLeft()
                    Keys.onRightPressed: grid.moveCurrentIndexRight()
                    Keys.onUpPressed: grid.moveCurrentIndexUp()
                    Keys.onDownPressed: grid.moveCurrentIndexDown()

                    Text {
                        visible: search.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Uygulama ara"
                        color: Theme.faint
                        font: search.font
                    }
                }
            }
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.line }

            // ---- Uygulamalar ----
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                GridView {
                    id: grid
                    anchors { fill: parent; leftMargin: 14; rightMargin: 14; topMargin: 10; bottomMargin: 6 }
                    cellWidth: width / 5
                    cellHeight: 104
                    clip: true
                    model: apps
                    currentIndex: 0
                    highlightFollowsCurrentItem: true
                    highlightMoveDuration: 90
                    highlight: Rectangle {
                        radius: 12
                        color: Theme.hover
                        border.width: 1
                        border.color: Theme.accentEdge
                    }
                    boundsBehavior: Flickable.StopAtBounds

                    delegate: Item {
                        id: cell
                        required property var modelData
                        required property int index
                        width: grid.cellWidth
                        height: grid.cellHeight

                        Column {
                            anchors.centerIn: parent
                            spacing: 9
                            Image {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: 44
                                height: 44
                                sourceSize: Qt.size(88, 88)
                                source: Quickshell.iconPath(cell.modelData.icon, true) || Quickshell.iconPath("application-x-executable")
                            }
                            Text {
                                width: cell.width - 18
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                                text: cell.modelData.name
                                color: grid.currentIndex === cell.index ? Theme.text : Qt.alpha(Theme.text, 0.82)
                                font.family: Theme.font
                                font.pixelSize: 13
                            }
                        }
                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onEntered: grid.currentIndex = cell.index
                            onClicked: win.launch(cell.modelData)
                        }
                    }
                }

                // Sonuç yok
                Column {
                    visible: apps.values.length === 0
                    anchors.centerIn: parent
                    spacing: 6
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "\u201C" + search.text.trim() + "\u201D için sonuç yok"
                        color: Theme.text
                        font.family: Theme.font
                        font.pixelSize: 15
                        font.weight: Font.Medium
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "Yazımı kontrol et ya da adın bir kısmını yaz."
                        color: Theme.muted
                        font.family: Theme.font
                        font.pixelSize: 13
                    }
                }
            }

            // ---- Alt şerit: sayı ve tuşlar ----
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.line }
            Item {
                Layout.fillWidth: true
                Layout.preferredHeight: 40

                Text {
                    anchors { left: parent.left; leftMargin: 24; verticalCenter: parent.verticalCenter }
                    text: apps.values.length + (search.text.trim() === "" ? " uygulama" : " sonuç")
                    color: Theme.muted
                    font.family: Theme.font
                    font.pixelSize: 12
                }
                Row {
                    anchors { right: parent.right; rightMargin: 20; verticalCenter: parent.verticalCenter }
                    spacing: 16
                    Row {
                        spacing: 6
                        Keycap { text: "Enter" }
                        Text { anchors.verticalCenter: parent.verticalCenter; text: "Aç"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                    }
                    Row {
                        spacing: 6
                        Keycap { text: "Esc" }
                        Text { anchors.verticalCenter: parent.verticalCenter; text: "Kapat"; color: Theme.muted; font.family: Theme.font; font.pixelSize: 12 }
                    }
                }
            }
        }
    }
}
