import Quickshell
import Quickshell.Wayland
import QtQuick

PanelWindow {
    id: win
    anchors { top: true; left: true; bottom: true }
    margins { top: 40; left: 10; bottom: 84 }
    implicitWidth: 108
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.namespace: "schway-desktop"
    WlrLayershell.layer: WlrLayer.Bottom

    readonly property string home: Quickshell.env("HOME")
    property int selected: -1
    readonly property var entries: [
        { name: "Ev", icon: "user-home", path: home },
        { name: "Çöp kutusu", icon: "user-trash", path: "trash:///" },
        { name: "Belgeler", icon: "folder-documents", path: home + "/Documents" },
        { name: "İndirilenler", icon: "folder-download", path: home + "/Downloads" },
        { name: "Masaüstü", icon: "user-desktop", path: home + "/Desktop" },
        { name: "Dosya sistemi", icon: "drive-harddisk", path: "/" }
    ]

    MouseArea { anchors.fill: parent; onClicked: win.selected = -1 }

    Column {
        spacing: 4
        Repeater {
            model: win.entries
            delegate: Rectangle {
                id: item
                required property var modelData
                required property int index
                width: 98
                height: 88
                radius: 10
                color: win.selected === index ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.30)
                     : (area.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent")
                border.width: win.selected === index ? 1 : 0
                border.color: Theme.accentEdge

                Column {
                    anchors.centerIn: parent
                    spacing: 6
                    Image {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 46
                        height: 46
                        sourceSize: Qt.size(92, 92)
                        source: Quickshell.iconPath(item.modelData.icon, true) || Quickshell.iconPath("folder")
                    }
                    Item {
                        width: 90
                        height: lbl.implicitHeight
                        // Yumuşak gölge: aynı yazı bir piksel aşağıda, koyu
                        Text {
                            x: 0; y: 1; width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: item.modelData.name
                            color: Qt.rgba(0, 0, 0, 0.65)
                            font.family: Theme.font
                            font.pixelSize: 12
                        }
                        Text {
                            id: lbl
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: item.modelData.name
                            color: "#F4F6FA"
                            font.family: Theme.font
                            font.pixelSize: 12
                        }
                    }
                }
                MouseArea {
                    id: area
                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: win.selected = item.index
                    onDoubleClicked: Quickshell.execDetached(["thunar", item.modelData.path])
                }
            }
        }
    }
}
