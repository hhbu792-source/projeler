import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

PanelWindow {
    id: dock
    anchors { bottom: true }
    margins { bottom: 10 }
    implicitWidth: row.implicitWidth + 24
    implicitHeight: 62
    color: "transparent"
    WlrLayershell.namespace: "schway-dock"

    // Sabitlenen uygulamalar (kurulu olmayanlar görünmez)
    readonly property var pinned: [
        { id: "firefox", match: ["firefox"] },
        { id: "schway-files", match: ["schway-files"], title: "schway dosyalar" },
        { id: "foot", match: ["foot"] },
        { id: "discord", match: ["discord"] },
        { id: "com.spotify.Client", match: ["spotify", "com.spotify.client"] },
        { id: "steam", match: ["steam"] },
        { id: "schway-security", match: ["schway-security"] },
        { id: "schway-feedback", match: ["schway-feedback", "org.schway.feedback"] },
        { id: "org.prismlauncher.PrismLauncher", match: ["org.prismlauncher.prismlauncher", "prismlauncher"] }
    ]

    // Bağımsız Quickshell pencereleri (Dosyalar, Görev Yöneticisi, Mağaza) Wayland app_id olarak "org.quickshell" bildirir;
    // bu yüzden pencere başlığına göre de eşleştirilir (başlık -> masaüstü girişi).
    readonly property var titleApps: ({ "schway dosyalar": "schway-files", "schway görev yöneticisi": "schway-tasks", "schway mağaza": "schway-store" })
    function titleKey(t) { return (t.title || "").toLowerCase() }
    function belongs(p, t) {
        const id = (t.appId || "").toLowerCase()
        return (id !== "" && p.match.includes(id)) || (!!p.title && titleKey(t) === p.title)
    }
    function buildItems(tops) {
        const res = []
        const used = []
        for (const p of pinned) {
            const e = DesktopEntries.heuristicLookup(p.id)
            if (!e) continue
            const t = tops.filter(x => belongs(p, x))
            t.forEach(x => used.push(x))
            res.push({ key: p.id, entry: e, tops: t })
        }
        for (const t of tops) {
            if (used.includes(t)) continue
            const mapped = titleApps[titleKey(t)]
            if (!t.appId && !mapped) continue
            const id = mapped || t.appId
            res.push({ key: id, entry: DesktopEntries.heuristicLookup(id), tops: [t] })
        }
        return res
    }

    ScriptModel {
        id: items
        values: dock.buildItems(ToplevelManager.toplevels.values)
    }

    Rectangle {
        anchors.fill: parent
        radius: Theme.rWin
        color: Theme.barColor
        border.width: 1
        border.color: Theme.border

        // Üst kenarda ince ışık çizgisi: yüzey hissi
        Rectangle {
            anchors { top: parent.top; topMargin: 1; horizontalCenter: parent.horizontalCenter }
            width: parent.width - Theme.rWin * 1.6
            height: 1
            color: Qt.rgba(1, 1, 1, 0.10)
        }
    }

    RowLayout {
        id: row
        anchors.centerIn: parent
        spacing: 4

        // Uygulama paneli
        Rectangle {
            Layout.preferredWidth: 44
            Layout.preferredHeight: 44
            radius: 11
            color: gridArea.pressed ? Theme.press : (gridArea.containsMouse || Ui.launcherOpen ? Theme.hover : "transparent")
            Behavior on color { ColorAnimation { duration: 100 } }
            Text {
                anchors.centerIn: parent
                text: Theme.g.apps
                color: Ui.launcherOpen ? Theme.accentDark : Theme.text
                font.family: Theme.iconFont
                font.pixelSize: 21
            }
            MouseArea {
                id: gridArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Ui.launcherOpen = !Ui.launcherOpen
            }
        }

        Rectangle { Layout.preferredWidth: 1; Layout.preferredHeight: 26; Layout.leftMargin: 4; Layout.rightMargin: 4; color: Theme.border }

        Repeater {
            model: items
            delegate: Item {
                id: app
                required property var modelData
                readonly property bool running: modelData.tops.length > 0
                readonly property bool focused: modelData.tops.some(t => t.activated)
                Layout.preferredWidth: 46
                Layout.preferredHeight: 50

                Rectangle {
                    anchors { horizontalCenter: parent.horizontalCenter; top: parent.top }
                    width: 44
                    height: 44
                    radius: 11
                    color: appArea.pressed ? Theme.press : (appArea.containsMouse ? Theme.hover : "transparent")
                    Behavior on color { ColorAnimation { duration: 100 } }
                }
                Image {
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: appArea.containsMouse ? 3 : 6
                    width: 32
                    height: 32
                    sourceSize: Qt.size(64, 64)
                    source: Quickshell.iconPath(app.modelData.entry ? app.modelData.entry.icon : app.modelData.key, true)
                            || Quickshell.iconPath("application-x-executable")
                    Behavior on y { NumberAnimation { duration: 110; easing.type: Easing.OutCubic } }
                }
                // Çalışıyor: küçük çizgi, öndeyse vurgu renginde ve uzun
                Rectangle {
                    visible: app.running
                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 1 }
                    width: app.focused ? 14 : 4
                    height: 3
                    radius: 1.5
                    color: app.focused ? Theme.accent : Theme.faint
                    Behavior on width { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                }
                MouseArea {
                    id: appArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        if (app.running) app.modelData.tops[0].activate()
                        else if (app.modelData.entry) app.modelData.entry.execute()
                    }
                }
            }
        }
    }
}
