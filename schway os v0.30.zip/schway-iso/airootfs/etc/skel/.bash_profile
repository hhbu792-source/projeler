# Giriş yapınca Hyprland kendiliğinden açılır
if [ -z "$WAYLAND_DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    if command -v start-hyprland >/dev/null 2>&1; then exec start-hyprland; else exec Hyprland; fi
fi
