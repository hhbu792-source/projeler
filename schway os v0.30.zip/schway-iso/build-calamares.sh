#!/bin/bash
# Calamares resmi depoda yok (AUR'da). Bu betik onu derleyip yerel bir depoya koyar.
# NORMAL KULLANICIYLA çalıştır (root değil). 10-20 dk sürebilir. Bir kere yapman yeter.
set -e
[ "$EUID" -ne 0 ] || { echo "root ile değil, normal kullanıcıyla çalıştır: bash build-calamares.sh"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)
sudo pacman -S --needed --noconfirm base-devel git
mkdir -p "$HERE/localrepo" "$HERE/aur-build"
rm -f "$HERE"/localrepo/*

for pkg in ckbcomp calamares; do
    rm -rf "$HERE/aur-build/$pkg"
    git clone --depth 1 "https://aur.archlinux.org/$pkg.git" "$HERE/aur-build/$pkg"
    (cd "$HERE/aur-build/$pkg" && makepkg -sf --noconfirm)
    cp "$HERE"/aur-build/$pkg/*.pkg.tar.* "$HERE/localrepo/"
done

rm -f "$HERE"/localrepo/*-debug-*
repo-add "$HERE/localrepo/schway-local.db.tar.gz" "$HERE"/localrepo/*.pkg.tar.*
bash "$HERE/build-extras.sh" || true   # isteğe bağlı paketler (Bibata imleç); hata verirse devam
echo
echo "Hazır. Şimdi ISO'yu derle:  sudo bash build-iso.sh --lite"
