import QtQuick
// Test taklidi: gerçek Quickshell'in ShellRoot'u
QtObject { default property list<QtObject> data }
