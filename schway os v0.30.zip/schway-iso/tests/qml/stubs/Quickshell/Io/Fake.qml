pragma Singleton
import QtQuick
QtObject {
    property var log: []
    property bool failInstall: false
    // Kurulum/kaldırma/güncelleme gerçekte uzun sürer: işlem sürerken arayüz durumunu denetleyebilmek için yavaş taklit edilir
    function delay(cmd) { return (cmd[1] === "install" || cmd[1] === "remove" || cmd[1] === "update") ? 500 : 5 }
    function run(cmd) {
        log.push(cmd.join(" "))
        const v = cmd[1]
        if (v === "featured") return { out: "F\torg.mozilla.firefox\tFirefox\tWeb tarayıcı\nF\torg.videolan.VLC\tVLC\tVideo oynatıcı\nF\tcom.spotify.Client\tSpotify\tMüzik\n", err: "", code: 0 }
        if (v === "installed") return { out: "I\torg.videolan.VLC\tVLC\t3.0\n", err: "", code: 0 }
        if (v === "updates") return { out: "U\torg.videolan.VLC\tVLC\t3.1\n", err: "", code: 0 }
        if (v === "search") return cmd[2] === "yokyok" ? { out: "", err: "", code: 0 } : { out: "S\tcom.example.Foo\tFoo Editor\tMetin düzenleyici\nS\tcom.example.Bar\tBar\tBaşka\n", err: "", code: 0 }
        if (v === "install" || v === "remove" || v === "update") return failInstall ? { out: "", err: "hata", code: 1 } : { out: "", err: "", code: 0 }
        return { out: "", err: "bilinmeyen", code: 2 }
    }
}
