import QtQuick
import QtQuick.Window
// Test taklidi: gerçek FloatingWindow yalnızca visible/title/implicitWidth/implicitHeight/color kullanılarak taklit edilir
Window {
    id: self
    property int implicitWidth: 400
    property int implicitHeight: 300
    width: implicitWidth
    height: implicitHeight
    Component.onCompleted: Registry.win = self
}
