pragma Singleton
import QtQuick
QtObject { property var win: null }
