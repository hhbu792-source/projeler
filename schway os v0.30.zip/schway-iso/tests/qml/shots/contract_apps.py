#!/usr/bin/env python3
"""Arayüz <-> arka uç SÖZLEŞME testi (Dosyalar ve Görev Yöneticisi).
Gerçek arka uç çıktısı arayüze verilir; arayüzün ürettiği komutlar yakalanıp GERÇEK arka uçta çalıştırılır, sonuç denetlenir.
Kullanım: python3 contract_apps.py   (çıkış 0 = tüm denetimler geçti)"""
import json, os, re, shutil, subprocess, sys, tempfile, time
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QUICK_BACKEND", "software")
from PySide6.QtCore import QUrl, QTimer, QEventLoop, QMetaObject, Qt, Q_ARG, QPoint, QPointF, QObject, qInstallMessageHandler
from PySide6.QtTest import QTest
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickWindow

here = os.path.dirname(os.path.abspath(__file__))
repo = os.path.abspath(os.path.join(here, "..", "..", ".."))
bin_ = os.path.join(repo, "airootfs/usr/local/bin")
qs_theme = os.path.join(repo, "airootfs/etc/skel/.config/quickshell/Theme.qml")
app = QGuiApplication(sys.argv)
fails, passes = [], 0
logs = []

def check(cond, msg):
    global passes
    if cond:
        passes += 1; print("  ok    " + msg)
    else:
        fails.append(msg); print("  HATA  " + msg)

def handler(mode, ctx, msg):
    if msg.startswith("RUN\t"):
        logs.append(json.loads(msg[4:]))
qInstallMessageHandler(handler)

def pump(ms):
    loop = QEventLoop(); QTimer.singleShot(ms, loop.quit); loop.exec()

def backend(env, *args):
    r = subprocess.run([sys.executable] + list(args), capture_output=True, text=True, env=env)
    return r.stdout, r.returncode, r.stderr

def load(appdir, mp, env_extra=None):
    work = tempfile.mkdtemp()
    for f in os.listdir(appdir):
        if f.endswith(".qml") or f == "qmldir":
            shutil.copy(os.path.join(appdir, f), work)
    shutil.copy(qs_theme, os.path.join(work, "Theme.qml"))
    stubs = os.path.join(work, "_stubs"); shutil.copytree(os.path.join(here, "stubs"), stubs)
    fake = """pragma Singleton
import QtQuick
QtObject {
    readonly property var map: (%s)
    function run(cmd) {
        console.log("RUN\\t" + JSON.stringify(cmd))
        const mk = cmd.join(" ")
        if (map[mk] !== undefined) return { out: map[mk], err: "", code: 0 }
        return { out: "", err: "", code: 0 }
    }
}
""" % json.dumps(mp, ensure_ascii=False)
    open(os.path.join(stubs, "Quickshell/Io/Fake.qml"), "w", encoding="utf-8").write(fake)
    before = set(id(w) for w in app.allWindows())
    e = QQmlApplicationEngine(); e.addImportPath(stubs)
    e.load(QUrl.fromLocalFile(os.path.join(work, "shell.qml")))
    ws = [w for w in app.allWindows() if isinstance(w, QQuickWindow) and id(w) not in before]
    return e, ws[0]

def call(win, name, *args):
    QMetaObject.invokeMethod(win, name, Qt.DirectConnection, *[Q_ARG("QVariant", a) for a in args])

def prop(win, name):
    v = win.property(name)
    return v.toVariant() if hasattr(v, "toVariant") else v

def last(cmd0, verb):
    for c in reversed(logs):
        if c[0] == cmd0 and len(c) > 1 and c[1] == verb:
            return c
    return None

# ======================================================== DOSYALAR
print("== Dosyalar: arayüz <-> schway-files")
T = tempfile.mkdtemp(); H = os.path.join(T, "home"); os.makedirs(H + "/Documents/alt"); os.makedirs(H + "/Downloads"); os.makedirs(H + "/.config")
open(H + "/Documents/a.txt", "w").write("a"); open(H + "/Documents/b.pdf", "w").write("bb"); open(H + "/Documents/.gizli", "w").write("g"); open(H + "/Documents/c.txt", "w").write("c")
open(T + "/mi", "w").write("")
fenv = dict(os.environ, HOME=H, XDG_DATA_HOME=H + "/.local/share", XDG_CONFIG_HOME=H + "/.config", SCHWAY_FILES_MOUNTINFO=T + "/mi")
F = os.path.join(bin_, "schway-files")
mp = {}
for args in (["places"], ["list", H + "/Documents"], ["list", H + "/Documents", "--hidden"], ["list", H + "/Downloads"], ["list", H], ["trashlist"]):
    out, rc, _ = backend(fenv, F, *args)
    mp["schway-files " + " ".join(args)] = out
e, win = load(os.path.join(repo, "airootfs/usr/share/schway/files"), mp)
win.setProperty("startPath", H + "/Documents")
pump(700)
rows = prop(win, "rows") or []
names = [r["ename"] for r in rows]
check(names == ["alt", "a.txt", "b.pdf", "c.txt"], "gerçek list çıktısı arayüzde doğru ayrışır ve sıralanır (klasör önce): %s" % names)
check(prop(win, "cwd") == H + "/Documents", "başlangıç klasörü açılır")
check([p["label"] for p in (prop(win, "places") or [])][:3] == ["Ev", "Belgeler", "İndirilenler"], "gerçek places çıktısı ayrışır")
win.setProperty("showHidden", True); pump(300)
check(last("schway-files", "list") and "--hidden" in last("schway-files", "list"), "Gizli dosyalar anahtarı --hidden ile yeniden listeler")
win.setProperty("showHidden", False); pump(300)
# çöpe at
win.setProperty("sel", {"a.txt": True}); pump(50)
call(win, "trashSel"); pump(100)
c = last("schway-files", "trash")
check(c == ["schway-files", "trash", H + "/Documents/a.txt"], "Çöpe at doğru komutu üretir: %s" % c)
out, rc, err = backend(fenv, F, *c[1:])
check(rc == 0 and not os.path.exists(H + "/Documents/a.txt") and os.path.exists(H + "/.local/share/Trash/files/a.txt"), "üretilen komut gerçek arka uçta dosyayı çöpe taşır")
# kopyala -> başka klasöre yapıştır
win.setProperty("sel", {"b.pdf": True}); pump(50)
call(win, "copySel", False); call(win, "go", H + "/Downloads", False); pump(300)
check(prop(win, "cwd") == H + "/Downloads", "klasöre gitme (go) çalışır")
call(win, "paste"); pump(100)
c = last("schway-files", "copy")
check(c == ["schway-files", "copy", H + "/Downloads", H + "/Documents/b.pdf"], "Yapıştır (kopya) doğru komutu üretir: %s" % c)
out, rc, err = backend(fenv, F, *c[1:])
check(rc == 0 and os.path.exists(H + "/Downloads/b.pdf") and os.path.exists(H + "/Documents/b.pdf"), "kopya gerçek arka uçta çalışır, özgün kalır")
# kes -> yapıştır
call(win, "go", H + "/Documents", False); pump(300)
win.setProperty("sel", {"b.pdf": True}); pump(50)
call(win, "copySel", True); call(win, "go", H + "/Downloads", False); pump(300); call(win, "paste"); pump(100)
c = last("schway-files", "move")
check(c == ["schway-files", "move", H + "/Downloads", H + "/Documents/b.pdf"], "Kes + Yapıştır 'move' komutunu üretir")
out, rc, err = backend(fenv, F, *c[1:])
check(rc == 0 and os.path.exists(H + "/Downloads/b (2).pdf") and not os.path.exists(H + "/Documents/b.pdf"), "taşıma çakışmada 'b (2).pdf' yapar, kaynağı siler")
check(prop(win, "clip")["paths"] == [] if isinstance(prop(win, "clip"), dict) else True, "kesme sonrası pano temizlenir")
# yeniden adlandır
call(win, "go", H + "/Documents", False); pump(300)
win.setProperty("sel", {"c.txt": True}); pump(50)
call(win, "renameSel"); pump(50)
dlg = win.property("dlg")
check(dlg is not None and dlg.property("kind").toString() == "name" and dlg.property("value").toString() == "c.txt", "F2 / Yeniden adlandır, mevcut adla iletişim kutusunu açar")
dlg.property("fn").call(["rapor.txt"]); pump(100)
c = last("schway-files", "rename")
check(c == ["schway-files", "rename", H + "/Documents/c.txt", "rapor.txt"], "yeniden adlandırma doğru komutu üretir: %s" % c)
out, rc, err = backend(fenv, F, *c[1:])
check(rc == 0 and os.path.exists(H + "/Documents/rapor.txt"), "ad gerçek arka uçta değişir")
# çöp görünümü: gerçek trashlist çıktısı
mp2 = dict(mp); mp2["schway-files trashlist"] = backend(fenv, F, "trashlist")[0]
call(win, "go", "trash://", False); pump(100)
check(any(c[1:2] == ["trashlist"] for c in logs), "Çöp Kutusu görünümü trashlist komutunu çağırır")
shutil.rmtree(T, ignore_errors=True)

# ======================================================== GÖREV YÖNETİCİSİ
print("== Görev Yöneticisi: arayüz <-> schway-tasks")
tenv = dict(os.environ, SCHWAY_TASKS_RUN=tempfile.mkdtemp(), SCHWAY_SYSTEMCTL=os.path.join(here, "fake-systemctl"), SCHWAY_POLICY=os.path.join(repo, "airootfs/usr/share/schway/services.policy"))
TK = os.path.join(bin_, "schway-tasks")
sleeper = subprocess.Popen(["sleep", "300"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
import atexit; atexit.register(lambda: sleeper.poll() is None and sleeper.kill())
time.sleep(0.2)
tmp = {}
for args in (["summary"], ["list"], ["services"]):
    tmp["schway-tasks " + " ".join(args)] = backend(tenv, TK, *args)[0]
logs.clear()
e2, w2 = load(os.path.join(repo, "airootfs/usr/share/schway/tasks"), tmp)
pump(700)
raw = prop(w2, "rawProcs") or ""
check(len([l for l in raw.split("\n") if l.count("\t") >= 7]) > 3, "gerçek list çıktısı (8 sütun) arayüze ulaşır")
check(prop(w2, "shownCount") > 0, "süzülmüş işlem listesi doluyor (%s işlem)" % prop(w2, "shownCount"))
summ = prop(w2, "sum") or {}
check(float(summ.get("mem_total_mb", 0)) > 0 and "cores" in summ, "gerçek summary çıktısı ayrışır (RAM %s MB, %s çekirdek)" % (summ.get("mem_total_mb"), summ.get("cores")))
w2.setProperty("allProcs", True); pump(100)
# işlemi sonlandır
w2.setProperty("selPid", sleeper.pid); w2.setProperty("selName", "sleep"); w2.setProperty("selFlags", "m"); pump(50)
call(w2, "endTask", False); pump(100)
c = last("schway-tasks", "kill")
check(c == ["schway-tasks", "kill", str(sleeper.pid), "term"], "İşlemi sonlandır doğru komutu üretir: %s" % c)
out, rc, err = backend(tenv, TK, *c[1:]); time.sleep(0.3)
check(rc == 0 and sleeper.poll() is not None, "üretilen komut gerçek işlemi kapatır")
# kritik işlem onay ister
w2.setProperty("selPid", 99999); w2.setProperty("selName", "Hyprland"); w2.setProperty("selFlags", "mc"); logs.clear()
call(w2, "endTask", False); pump(50)
check(w2.property("ask") is not None and last("schway-tasks", "kill") is None, "kritik işlem (c bayrağı) onay istemeden kapatılmaz")
w2.setProperty("ask", None)
# hizmetler
w2.setProperty("tab", 2); pump(400)
svc = prop(w2, "svcs") or []
check(any(s["unit"] == "sshd.service" for s in svc) and any(s["pol"] == "essential" for s in svc), "gerçek services çıktısı ayrışır (politika alanı dahil): %d hizmet" % len(svc))
logs.clear()
call(w2, "svcAct", "disable", "sshd.service"); pump(50)
ask = w2.property("ask")
check(ask is not None and last("schway-tasks", "service") is None, "hizmeti kapatmadan önce onay istenir")
ask.property("fn").call([]); pump(100)
c = last("schway-tasks", "service")
check(c == ["schway-tasks", "service", "disable", "sshd.service"], "hizmet kapatma doğru komutu üretir: %s" % c)
out, rc, err = backend(tenv, TK, *c[1:])
check(rc == 0, "komut gerçek arka uçta başarılı (sahte systemctl): %s" % out.strip())
out, rc, err = backend(tenv, TK, "service", "stop", "NetworkManager.service")
check(rc != 0 and "zorunlu" in err, "zorunlu hizmet arka uçta da reddedilir (arayüz kilidi yetmezse son savunma)")
try:
    sleeper.kill()
except Exception:
    pass

# ======================================================== DOSYALAR: etkileşimler (önizleme, sağ tık, sürükle-bırak)
print("== Dosyalar: önizleme, sağ tık menüsü, sürükle-bırak (gerçek fare olaylarıyla)")
T2 = tempfile.mkdtemp(); H2 = os.path.join(T2, "home"); os.makedirs(H2 + "/Documents/alt"); os.makedirs(H2 + "/.config"); open(T2 + "/mi", "w").write("")
open(H2 + "/Documents/a.txt", "w").write("birinci satır\nikinci satır ğüş\n"); open(H2 + "/Documents/b.txt", "w").write("bbb"); open(H2 + "/Documents/c.txt", "w").write("ccc")
from PySide6.QtGui import QImage, QColor
_im = QImage(32, 32, QImage.Format_RGB32); _im.fill(QColor("#3a7bd5")); _im.save(H2 + "/Documents/p.png")
fenv2 = dict(os.environ, HOME=H2, XDG_DATA_HOME=H2 + "/.local/share", XDG_CONFIG_HOME=H2 + "/.config", SCHWAY_FILES_MOUNTINFO=T2 + "/mi")
mp3 = {}
for args in (["places"], ["list", H2 + "/Documents"], ["list", H2 + "/Documents/alt"], ["trashlist"],
             ["preview", H2 + "/Documents/a.txt"], ["preview", H2 + "/Documents/p.png"], ["preview", H2 + "/Documents/alt"]):
    mp3["schway-files " + " ".join(args)] = backend(fenv2, F, *args)[0]
logs.clear()
e3, w3 = load(os.path.join(repo, "airootfs/usr/share/schway/files"), mp3)
w3.setProperty("width", 1100); w3.setProperty("height", 760); w3.setProperty("visible", True)
w3.setProperty("startPath", H2 + "/Documents"); pump(800)

def obj(name, root=None):
    """Görsel ağaçta objectName ile ara (ListView delegeleri QObject ağacında bulunmaz; childItems() gerekir)."""
    stack = [root or w3.contentItem()]
    while stack:
        it = stack.pop()
        if it.objectName() == name:
            return it
        stack.extend(it.childItems())
    return None

def center(o):
    pt = o.mapToScene(QPointF(o.width() / 2, o.height() / 2))
    return QPoint(int(pt.x()), int(pt.y()))

# --- önizleme: gerçek preview çıktısı
call(w3, "selectAll"); win_sel = {"a.txt": True}; w3.setProperty("sel", win_sel); w3.setProperty("previewOn", True); pump(700)
pv = prop(w3, "prev") or {}
check(pv.get("kind") == "text" and "ikinci satır" in (w3.property("prevText") or ""), "metin önizlemesi gerçek preview çıktısından dolar (%s, %s)" % (pv.get("kind"), pv.get("detail")))
w3.setProperty("sel", {"p.png": True}); pump(700)
pv = prop(w3, "prev") or {}
check(pv.get("kind") == "image" and (w3.property("prevPath") or "").endswith("p.png"), "resim önizlemesi (kind=image, yol ayarlanır)")
w3.setProperty("sel", {"alt": True}); pump(700)
check((prop(w3, "prev") or {}).get("kind") == "dir", "klasör önizlemesi (öğe sayısı)")
w3.setProperty("sel", {"a.txt": True, "b.txt": True}); pump(400)
check((prop(w3, "prev") or {}).get("kind") == "multi", "çoklu seçimde 'N öğe seçili' gösterilir")
w3.setProperty("previewOn", False); w3.setProperty("sel", {}); pump(100)

# --- sağ tık menüsü
row = obj("row_b.txt")
QTest.mouseClick(w3, Qt.RightButton, Qt.NoModifier, center(row)); pump(200)
menu = prop(w3, "menu")
labels = [i.get("label") for i in (menu or {}).get("items", []) if not i.get("sep")]
check(menu is not None and "Çöpe at" in labels and "Yeniden adlandır" in labels and "Kes" in labels, "satıra sağ tıklayınca menü açılır: %s" % labels)
check(prop(w3, "sel") == {"b.txt": True}, "sağ tıklanan (seçili olmayan) satır seçilir")
logs.clear()
item = obj("menu_trash")
QTest.mouseClick(w3, Qt.LeftButton, Qt.NoModifier, center(item)); pump(200)
c = last("schway-files", "trash")
check(c == ["schway-files", "trash", H2 + "/Documents/b.txt"], "menüden 'Çöpe at' doğru komutu üretir: %s" % c)
check(prop(w3, "menu") is None, "menü komuttan sonra kapanır")
out, rc, err = backend(fenv2, F, *c[1:])
check(rc == 0 and not os.path.exists(H2 + "/Documents/b.txt"), "menü komutu gerçek arka uçta dosyayı çöpe taşır")
# boş alana sağ tık -> yeni klasör/yapıştır menüsü
QTest.mouseClick(w3, Qt.RightButton, Qt.NoModifier, QPoint(700, 640)); pump(200)
labels = [i.get("label") for i in (prop(w3, "menu") or {}).get("items", []) if not i.get("sep")]
check("Yeni klasör" in labels and "Yapıştır" in labels and not "Çöpe at" in labels, "boş alana sağ tık: klasör düzeyi menü (%s)" % labels)
QTest.mouseClick(w3, Qt.LeftButton, Qt.NoModifier, QPoint(100, 620)); pump(100)
check(prop(w3, "menu") is None, "menü dışına tıklayınca kapanır")

# --- sürükle-bırak
def drag(src_name, dst_obj, mods=Qt.NoModifier):
    start = center(obj(src_name)); end = center(dst_obj)
    QTest.mousePress(w3, Qt.LeftButton, Qt.NoModifier, start); pump(30)
    steps = 8
    for i in range(1, steps + 1):
        QTest.mouseMove(w3, QPoint(start.x() + (end.x() - start.x()) * i // steps, start.y() + (end.y() - start.y()) * i // steps)); pump(20)
    started = prop(w3, "dragging")
    QTest.mouseRelease(w3, Qt.LeftButton, mods, end); pump(150)
    return started

w3.setProperty("sel", {}); logs.clear()
started = drag("row_a.txt", obj("row_alt"))
c = last("schway-files", "move")
check(started is True, "satırı fareyle sürüklemek sürüklemeyi başlatır")
check(c == ["schway-files", "move", H2 + "/Documents/alt", H2 + "/Documents/a.txt"], "dosyayı klasör satırına bırakmak 'move' komutunu üretir: %s" % c)
out, rc, err = backend(fenv2, F, *c[1:])
check(rc == 0 and os.path.exists(H2 + "/Documents/alt/a.txt") and not os.path.exists(H2 + "/Documents/a.txt"), "bırakma komutu gerçek arka uçta dosyayı taşır")
check(prop(w3, "dragging") is False, "bırakınca sürükleme durumu kapanır")
logs.clear(); w3.setProperty("sel", {}); pump(100)
call(w3, "reload"); pump(500)
drag("row_c.txt", obj("row_alt"), Qt.ControlModifier)
c = last("schway-files", "copy")
check(c == ["schway-files", "copy", H2 + "/Documents/alt", H2 + "/Documents/c.txt"], "Ctrl basılıyken bırakmak 'copy' komutunu üretir: %s" % c)
logs.clear(); w3.setProperty("sel", {}); pump(100)
drag("row_c.txt", obj("place_Çöp Kutusu"))
c = last("schway-files", "trash")
check(c == ["schway-files", "trash", H2 + "/Documents/c.txt"], "Çöp Kutusu yerine bırakmak çöpe atar: %s" % c)
logs.clear(); w3.setProperty("sel", {}); pump(100)
drag("row_p.png", obj("row_alt"))
before = len([x for x in logs if x[1:2] == ["move"]])
logs.clear(); w3.setProperty("sel", {}); pump(100)
drag("row_alt", obj("row_alt"))
check(last("schway-files", "move") is None, "klasörü kendi üzerine bırakmak komut üretmez")
logs.clear(); w3.setProperty("sel", {}); pump(100)
sel_before = prop(w3, "sel")
QTest.mouseClick(w3, Qt.LeftButton, Qt.NoModifier, center(obj("row_p.png"))); pump(100)
check(prop(w3, "sel") == {"p.png": True}, "kısa tık (sürükleme değil) satırı seçer")
shutil.rmtree(T2, ignore_errors=True)

# ======================================================== DOCK
print("== Dock: pin ve pencere eşleştirme")
work = tempfile.mkdtemp(); qsdir = os.path.join(repo, "airootfs/etc/skel/.config/quickshell")
for f in os.listdir(qsdir):
    if f.endswith(".qml") or f == "qmldir":
        t = open(os.path.join(qsdir, f), encoding="utf-8").read()
        t = re.sub(r"^\s*WlrLayershell\.\w+:.*$", "", t, flags=re.M)
        t = re.sub(r"^\s*(anchors|margins)\s*\{[^}\n]*\}\s*$", "", t, flags=re.M)
        if f == "Dock.qml":
            t = t.replace("model: items\n", "model: items.values\n")
        open(os.path.join(work, f), "w", encoding="utf-8").write(t)
open(os.path.join(work, "dockwrap.qml"), "w", encoding="utf-8").write("""import QtQuick
Item {
    property var d: Dock { id: dock }
    property string out: ""
    function run(tops) {
        out = JSON.stringify(dock.buildItems(tops).map(i => ({ key: i.key, entry: i.entry ? i.entry.id : null, titles: i.tops.map(t => t.title) })))
    }
}
""")
shutil.copytree(os.path.join(here, "stubs"), os.path.join(work, "_stubs"))
open(os.path.join(work, "_stubs/Quickshell/Io/Fake.qml"), "w", encoding="utf-8").write('pragma Singleton\nimport QtQuick\nQtObject { function run(cmd) { return { out: "", err: "", code: 0 } } }\n')
e4 = QQmlApplicationEngine(); e4.addImportPath(os.path.join(work, "_stubs"))
e4.warnings.connect(lambda ws: [print("   QML:", w.toString()) for w in ws])
e4.load(QUrl.fromLocalFile(os.path.join(work, "dockwrap.qml")))
check(len(e4.rootObjects()) == 1, "Dock.qml sahte Quickshell ile yüklenir")
dw = e4.rootObjects()[0] if e4.rootObjects() else sys.exit(1)
tops = [{"appId": "org.quickshell", "title": "Schway Dosyalar"}, {"appId": "firefox", "title": "Mozilla Firefox"}, {"appId": "org.quickshell", "title": "Schway Görev Yöneticisi"},
        {"appId": "org.quickshell", "title": "Schway Mağaza"}, {"appId": "foot", "title": "~"}, {"appId": "", "title": ""}, {"appId": "unknown-app", "title": "x"}]
QMetaObject.invokeMethod(dw, "run", Qt.DirectConnection, Q_ARG("QVariant", tops)); pump(50)
res = json.loads(dw.property("out"))
keys_ = [r["key"] for r in res]
check(keys_ == ["firefox", "schway-files", "foot", "discord", "steam", "schway-security", "schway-tasks", "schway-store", "unknown-app"], "dock sırası: sabitler önce, sonra eşlenen Schway pencereleri: %s" % keys_)
files_item = next(r for r in res if r["key"] == "schway-files")
check(files_item["titles"] == ["Schway Dosyalar"] and files_item["entry"] == "schway-files", "Dosyalar pini 'org.quickshell' app_id'li pencereyi BAŞLIĞA göre sahiplenir (ayrı simge çıkmaz)")
check("org.quickshell" not in keys_ and next(r for r in res if r["key"] == "schway-tasks")["entry"] == "schway-tasks", "Görev Yöneticisi ve Mağaza kendi simgeleriyle görünür (genel 'org.quickshell' öğesi yok)")
check(next(r for r in res if r["key"] == "unknown-app")["entry"] is None, "tanınmayan uygulama eskisi gibi (giriş yok) listelenir")
QMetaObject.invokeMethod(dw, "run", Qt.DirectConnection, Q_ARG("QVariant", [])); pump(50)
res = json.loads(dw.property("out"))
check([r["key"] for r in res] == ["firefox", "schway-files", "foot", "discord", "steam", "schway-security"] and all(r["titles"] == [] for r in res), "pencere yokken yalnızca kurulu sabit uygulamalar görünür (çalışmıyor)")
check("thunar" not in open(os.path.join(qsdir, "Dock.qml"), encoding="utf-8").read().split("readonly property var pinned")[1].split("]")[0], "Thunar pini kaldırıldı, yerine Schway Dosyalar")

print("\nSonuç: %d geçti, %d hata" % (passes, len(fails)))
sys.exit(1 if fails else 0)
