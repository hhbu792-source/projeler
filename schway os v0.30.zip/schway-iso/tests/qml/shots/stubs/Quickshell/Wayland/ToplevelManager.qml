pragma Singleton
import QtQuick
QtObject { readonly property var toplevels: ({ values: [] }) }
