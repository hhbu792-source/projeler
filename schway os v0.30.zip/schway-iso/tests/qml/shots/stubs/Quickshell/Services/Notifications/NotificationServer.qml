import QtQuick
QtObject {
    property bool keepOnReload: false
    property bool bodySupported: false
    property bool actionsSupported: false
    property bool imageSupported: false
    property var trackedNotifications: []
    signal notification(var n)
}
