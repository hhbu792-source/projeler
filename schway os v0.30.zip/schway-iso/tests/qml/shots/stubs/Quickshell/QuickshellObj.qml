pragma Singleton
import QtQuick
QtObject {
    property var screens: []
    function execDetached(c) { console.log("EXEC " + JSON.stringify(c)) }
    function iconPath(n) { return "" }
    function env(k) { return "" }
}
