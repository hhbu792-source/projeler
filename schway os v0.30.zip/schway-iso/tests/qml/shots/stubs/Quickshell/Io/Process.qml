import QtQuick
// Test taklidi: komutu çalıştırmaz, Fake.run() sonucunu verir (asenkron, gerçek Process gibi)
QtObject {
    id: p
    property var command: []
    property bool running: false
    property var stdout: null
    property var stderr: null
    signal exited(int exitCode, int exitStatus)
    property var _t: Timer {
        interval: 1
        onTriggered: {
            const r = Fake.run(p.command)
            if (p.stdout) { p.stdout.text = r.out; p.stdout.streamFinished() }
            if (p.stderr) { p.stderr.text = r.err; p.stderr.streamFinished() }
            p.running = false
            p.exited(r.code, 0)
        }
    }
    onRunningChanged: if (running) { _t.interval = 1; _t.restart() }
}
