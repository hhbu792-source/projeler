pragma Singleton
import QtQuick
// Test taklidi: bilinen masaüstü girişleri; bilinmeyen kimlik için null döner (gerçek heuristicLookup gibi)
QtObject {
    readonly property var known: ["firefox", "schway-files", "schway-tasks", "schway-store", "schway-security", "foot", "steam", "discord"]
    function heuristicLookup(id) { return known.indexOf(id) >= 0 ? { id: id, icon: id, name: id, execute: function () {} } : null }
}
