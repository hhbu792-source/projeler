import QtQuick
import QtQuick.Window
// Görüntü koşucusu taklidi: gerçek PanelWindow yerine düz pencere (anchors/exclusionMode/WlrLayershell koşucu tarafından ayıklanır)
Window {
    property int implicitWidth: 400
    property int implicitHeight: 300
    property bool exclusionMode: false
    default property alias content: holder.data
    Item { id: holder; anchors.fill: parent }
}
