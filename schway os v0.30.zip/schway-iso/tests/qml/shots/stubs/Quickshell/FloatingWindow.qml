import QtQuick
import QtQuick.Window
Window {
    property int implicitWidth: 400
    property int implicitHeight: 300
    width: implicitWidth
    height: implicitHeight
    default property alias content: holder.data
    Item { id: holder; anchors.fill: parent }
}
