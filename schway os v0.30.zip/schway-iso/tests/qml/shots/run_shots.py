#!/usr/bin/env python3
"""Schway arayüzünü sahte Quickshell ile ÇEVRİMDIŞI çizer ve PNG kaydeder (gerçek Quickshell/Hyprland gerekmez).
Kullanım: python3 run_shots.py <quickshell-klasörü> <senaryo: ok|busy|threat> <sayfa-numaraları,virgüllü> <çıktı-klasörü> [Security|Settings]
Yalnızca görsel gözden geçirme içindir: gerçek PanelWindow/Wayland katmanını taklit eder, arka plan (duvar kâğıdı/bulanıklık) çizilmez."""
import os, re, sys, shutil, tempfile, subprocess, time, json
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QUICK_BACKEND", "software")
from PySide6.QtCore import QUrl, QTimer, qInstallMessageHandler
from PySide6.QtGui import QGuiApplication, QImage
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickWindow

here = os.path.dirname(os.path.abspath(__file__))
qs, scenario, pages, outdir = sys.argv[1], sys.argv[2], [int(x) for x in sys.argv[3].split(",")], sys.argv[4]
which = sys.argv[5] if len(sys.argv) > 5 else "Security"
standalone = {"Tasks": "airootfs/usr/share/schway/tasks", "Files": "airootfs/usr/share/schway/files"}   # ayrı Quickshell süreci olan uygulamalar (shell.qml)
extra = json.loads(os.environ.get("SHOT_MAP", "{}"))      # { "komut argümanları": "çıktı" } sahte komut yanıtları
presets = json.loads(os.environ.get("SHOT_PROPS", "{}"))   # yüklemeden sonra pencereye atanacak özellikler
os.makedirs(outdir, exist_ok=True)
repo = os.path.abspath(os.path.join(here, "..", "..", ".."))
defender = os.path.join(repo, "airootfs/usr/local/bin/schway-defender")

# --- sahte veri: gerçek `schway-defender status` çıktısı üzerine senaryo ---
tmp = tempfile.mkdtemp()
env = dict(os.environ, SD_STATE=tmp + "/st", SD_CONF=tmp + "/conf", SD_RUN=tmp + "/run", SD_HOSTS=tmp + "/hosts")
open(tmp + "/hosts", "w").write("127.0.0.1 localhost\n")
st = subprocess.run(["bash", defender, "status"], capture_output=True, text=True, env=env).stdout
kv = dict(l.split("=", 1) for l in st.splitlines() if "=" in l)
now = int(time.time())
kv.update(health="ok", state="idle", engine="ok", realtime="on", defs="ok", defs_version="27712", defs_age="0",
          last_scan_time=str(now - 7200), last_scan_kind="quick", last_scan_result="clean", last_scan_threats="0",
          active_threats="0", quarantined="0", firewall="on", cfg_realtime="1", cfg_guard="1", cfg_ransom="1", cfg_web="1",
          cfg_prevent="0", ransom_state="on", prevent_state="off", web_count="3412", web_time=str(now - 5000), last_integrity_count="0")
hist = [(now - 600, "scan", "clean", "quick", ""), (now - 4000, "update", "ok", "", ""),
        (now - 9000, "scan", "clean", "quick: 8123 dosya, 0 tehdit, 14 sn", "")]
quar = []; thr = []
if scenario in ("busy", "threat"):
    hist = [(now - 300, "execblock", "karantina", "Win.Test.Malware", "/home/schway/Downloads/crack.sh"),
            (now - 1800, "ransom", "uyarı", "Tuzak dosya değiştirildi ya da silindi", "/home/schway/Documents/.~schway-canary.docx"),
            (now - 5000, "guard", "karantina", "Eicar-Test", "/home/schway/Downloads/eicar.com"),
            (now - 7000, "threat", "karantina", "Eicar-Test", "/home/schway/Downloads/eicar.com"),
            (now - 8000, "scan", "threats", "full: 120344 dosya, 1 tehdit, 412 sn", ""), (now - 9000, "integrity", "degisik", "3 sistem dosyası değişmiş", ""),
            (now - 20000, "update", "ok", "", "")]
    quar = [("q1", str(now - 7000), "Eicar-Test", "/home/schway/Downloads/eicar.com", "68"),
            ("q2", str(now - 300), "Win.Test.Malware", "/home/schway/Downloads/crack.sh", "2048")]
    kv.update(quarantined="2", last_ransom_time=str(now - 1800), last_ransom_reason="Tuzak dosya değiştirildi ya da silindi",
              health="warn", cfg_prevent="1", prevent_state="on")
if scenario == "threat":
    kv.update(health="bad", active_threats="1")
    thr = [("/home/schway/Downloads/dropper.exe", "Win.Trojan.Agent", str(now - 120))]
human = subprocess.run(["bash", defender, "status", "--human"], capture_output=True, text=True, env=env).stdout
dump = "".join(f"V av_{k[4:]} {v}\n" for k, v in kv.items() if k.startswith("cfg_")) + "V av_schedule weekly\nV av_scantime 03:00\nV av_maxsize 100\n@@av_status\n" + human
fake = """pragma Singleton
import QtQuick
QtObject {
    readonly property var map: (%s)
    function run(cmd) {
        const v = cmd[1], w = cmd[2]
        const mk = cmd.join(" ")
        if (map[mk] !== undefined) return { out: map[mk], err: "", code: 0 }
        if (map["*" + (cmd[0] || "") + " " + (cmd[1] || "")] !== undefined) return { out: map["*" + cmd[0] + " " + cmd[1]], err: "", code: 0 }
        if (cmd[0] === "sh" && String(cmd[2]).indexOf("dump") >= 0) return { out: %s, err: "", code: 0 }
        if (v === "caps") return { out: "defender\\n", err: "", code: 0 }
        if (v === "dump") return { out: %s, err: "", code: 0 }
        if (v === "status") return { out: %s, err: "", code: 0 }
        if (v === "history") return { out: %s, err: "", code: 0 }
        if (v === "quarantine") return { out: %s, err: "", code: 0 }
        if (v === "threats") return { out: %s, err: "", code: 0 }
        return { out: "", err: "", code: 0 }
    }
}
""" % tuple(json.dumps(x, ensure_ascii=False) for x in (
    extra,
    dump,
    dump,
    "\n".join(f"{k}={v}" for k, v in kv.items()) + "\n",
    "".join("\t".join(map(str, r)) + "\n" for r in hist),
    "".join("\t".join(r) + "\n" for r in quar),
    "".join("\t".join(r) + "\n" for r in thr)))

# --- QML'i kopyala ve gerçek-Quickshell'e özgü satırları ayıkla ---
work = tempfile.mkdtemp()
for f in os.listdir(qs):
    if f.endswith(".qml") or f == "qmldir":
        s = open(os.path.join(qs, f), encoding="utf-8").read()
        s = re.sub(r"^\s*WlrLayershell\.\w+:.*$", "", s, flags=re.M)
        s = re.sub(r"^\s*exclusionMode:.*$", "", s, flags=re.M)
        s = re.sub(r"^\s*anchors\s*\{[^}\n]*(top|bottom|left|right): true[^}\n]*\}\s*$", "", s, flags=re.M)
        if f == "Ui.qml":
            s = s.replace("property bool securityOpen: false", "property bool securityOpen: true").replace("property bool settingsOpen: false", "property bool settingsOpen: true")
        open(os.path.join(work, f), "w", encoding="utf-8").write(s)
if which in standalone:
    sd = os.path.join(repo, standalone[which])
    for f in os.listdir(sd):
        if f.endswith(".qml") or f == "qmldir":
            shutil.copy(os.path.join(sd, f), os.path.join(work, f))
stubs = os.path.join(work, "_stubs"); shutil.copytree(os.path.join(here, "stubs"), stubs)
open(os.path.join(stubs, "Quickshell/Io/Fake.qml"), "w", encoding="utf-8").write(fake)

warns = []
def handler(mode, ctx, msg):
    if not msg.startswith("EXEC"):
        warns.append(msg)
qInstallMessageHandler(handler)
app = QGuiApplication(sys.argv)
e = QQmlApplicationEngine()
e.addImportPath(stubs)
e.load(QUrl.fromLocalFile(os.path.join(work, ("shell" if which in standalone else which) + ".qml")))
if not e.rootObjects():
    print("HATA: yüklenemedi"); [print("  ", w) for w in warns[:15]]; sys.exit(2)
win = e.rootObjects()[0]
if which in standalone:    # ShellRoot bir pencere değildir: içindeki FloatingWindow'u bul
    ws = [w for w in app.allWindows() if isinstance(w, QQuickWindow)]
    if not ws:
        print("HATA: pencere bulunamadı"); sys.exit(2)
    win = ws[0]
for k, v in presets.items():
    win.setProperty(k, v)
win.setProperty("width", 1280); win.setProperty("height", 800); win.setProperty("visible", True)
state = {"i": 0}
def shoot():
    for k, v in presets.items():      # liste yüklendikten sonra yeniden uygula (go() seçimi sıfırlar)
        if k != "startPath":
            win.setProperty(k, v)
    i = state["i"]
    if i >= len(pages):
        app.quit(); return
    names = [win.metaObject().property(k).name() for k in range(win.metaObject().propertyCount())]
    for pn in ("page", "pageIndex", "tab"):
        if pn in names:
            win.setProperty(pn, pages[i])
    QTimer.singleShot(900, lambda: grab(i))
def grab(i):
    img = win.grabWindow()
    path = os.path.join(outdir, f"{which.lower()}_{scenario}_{pages[i]}.png")
    img.save(path); print("kaydedildi:", path, img.width(), "x", img.height())
    state["i"] += 1; QTimer.singleShot(50, shoot)
QTimer.singleShot(1500, shoot)
QTimer.singleShot(60000, lambda: app.exit(3))
app.exec()
errs = [w for w in warns if re.search(r"Error|error|not defined|Unable to assign|ReferenceError|TypeError|Cannot", w)]
errs = [w for w in errs if "usr/share/schway" not in w]   # logo dosyası yalnızca gerçek sistemde var
for w in sorted(set(errs))[:25]: print("QML:", w)
sys.exit(1 if errs or state["i"] < len(pages) else 0)
