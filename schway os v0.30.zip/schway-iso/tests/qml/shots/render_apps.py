#!/usr/bin/env python3
"""Bağımsız uygulamaları (Görev Yöneticisi, Dosya Gezgini) sahte veriyle çizer. Kullanım: python3 render_apps.py <çıktı-klasörü> [Tasks|Files ...]
Çıkış kodu 0: tüm sayfalar QML hatasız çizildi."""
import json, os, subprocess, sys, time
here = os.path.dirname(os.path.abspath(__file__))
repo = os.path.abspath(os.path.join(here, "..", "..", ".."))
qs = os.path.join(repo, "airootfs/etc/skel/.config/quickshell")
out = sys.argv[1]
apps = sys.argv[2:] or ["Tasks", "Files"]

def tasks():
    procs = [  # pid, user, cpu, mem_mb, state, name, cmd, flags
        (812, "schway", 2.1, 182.4, "S", "Hyprland", "Hyprland", "mc"),
        (1034, "schway", 3.4, 311.0, "S", "quickshell", "quickshell -c /home/schway/.config/quickshell", "mc"),
        (2210, "schway", 18.7, 1432.5, "S", "firefox", "/usr/lib/firefox/firefox --name firefox", "m"),
        (2388, "schway", 6.2, 641.8, "S", "firefox", "/usr/lib/firefox/firefox -contentproc -childID 1 -isForBrowser tab", "m"),
        (2590, "schway", 4.4, 523.1, "S", "Discord", "/opt/discord/Discord --type=renderer", "m"),
        (2711, "schway", 1.1, 410.7, "S", "steam", "/home/schway/.local/share/Steam/ubuntu12_32/steam -srt-logger-opened", "m"),
        (905, "schway", 0.8, 24.2, "S", "pipewire", "/usr/bin/pipewire", "mc"),
        (907, "schway", 0.2, 31.9, "S", "wireplumber", "/usr/bin/wireplumber", "mc"),
        (3320, "schway", 0.1, 18.3, "S", "foot", "foot", "mc"),
        (3402, "schway", 0.0, 6.0, "S", "bash", "-bash", "m"),
        (3511, "schway", 0.9, 12.6, "R", "schway-tasks", "python3 /usr/local/bin/schway-tasks list", "m"),
        (640, "root", 0.3, 38.4, "S", "NetworkManager", "/usr/bin/NetworkManager --no-daemon", "c"),
        (655, "root", 0.1, 21.5, "S", "earlyoom", "/usr/bin/earlyoom -r 3600", "-"),
        (1, "root", 0.0, 14.1, "S", "systemd", "/sbin/init", "c"),
        (2, "root", 0.0, 0.0, "S", "kthreadd", "[kthreadd]", "k"),
    ]
    rows = "".join("\t".join(str(x) for x in r) + "\n" for r in procs)
    svcs = [("NetworkManager.service", "active", "enabled", "30.0", "Network Manager", "essential"),
            ("earlyoom.service", "active", "enabled", "1.0", "Early OOM Daemon", "boot"),
            ("systemd-timesyncd.service", "active", "enabled", "3.2", "Network Time Synchronization", "essential"),
            ("systemd-resolved.service", "active", "enabled", "8.7", "Network Name Resolution", "essential"),
            ("power-profiles-daemon.service", "active", "enabled", "6.1", "Power Profiles daemon", "boot"),
            ("bluetooth.service", "active", "enabled", "4.5", "Bluetooth service", "ondemand"),
            ("docker.service", "failed", "enabled", "-", "Docker Application Container Engine", "ondemand"),
            ("sshd.service", "inactive", "disabled", "-", "OpenSSH Daemon", "ondemand"),
            ("ufw.service", "active", "enabled", "2.0", "Uncomplicated firewall", "ondemand")]
    srows = "".join("\t".join(r) + "\n" for r in svcs)
    summ = "cpu=23.4\ncores=8\nmem_used_mb=5120\nmem_total_mb=15872\nswap_used_mb=312\nswap_total_mb=7936\nload1=1.42\nuptime_s=93720\nprocs=287\n"
    cpu = [8, 12, 9, 14, 30, 42, 38, 25, 18, 22, 35, 51, 47, 33, 24, 19, 28, 41, 55, 48, 36, 29, 23, 21, 26, 34, 39, 31, 27, 22, 18, 20, 25, 33, 44, 52, 46, 38, 30, 27, 23, 19, 24, 28, 35, 41, 37, 30, 26, 22, 25, 29, 33, 27, 24, 21, 23, 25, 24, 23]
    mem = [28 + (i % 7) * 0.6 + i * 0.07 for i in range(60)]
    return [("", {"schway-tasks summary": summ, "schway-tasks list": rows, "schway-tasks services": srows}, {"cpuHist": cpu, "memHist": mem}, [0, 1, 2])]

def files():
    import tempfile
    from PySide6.QtGui import QImage, QColor, QPainter, QLinearGradient
    H = tempfile.mkdtemp(prefix="schway-home-")        # gerçek bir resim dosyası da olsun diye ev klasörü gerçek bir geçici klasör
    img = QImage(640, 420, QImage.Format_RGB32)
    g = QLinearGradient(0, 0, 640, 420); g.setColorAt(0, QColor("#2b5fb4")); g.setColorAt(0.55, QColor("#e07a5f")); g.setColorAt(1, QColor("#f2cc8f"))
    pt = QPainter(img); pt.fillRect(0, 0, 640, 420, g); pt.setBrush(QColor("#1d3557")); pt.setPen(QColor("#1d3557")); pt.drawEllipse(80, 250, 480, 360); pt.end()
    img.save(H + "/tatil-0412.jpg")
    places = "\n".join("\t".join(r) for r in [("home", "Ev", H), ("desk", "Masaüstü", H + "/Masaüstü"), ("docs", "Belgeler", H + "/Belgeler"),
              ("down", "İndirilenler", H + "/İndirilenler"), ("pics", "Resimler", H + "/Resimler"), ("music", "Müzik", H + "/Müzik"),
              ("video", "Videolar", H + "/Videolar"), ("root", "Bilgisayar", "/"), ("drive", "FLASH 32GB", "/run/media/schway/FLASH"),
              ("trash", "Çöp Kutusu", "trash://")]) + "\n"
    now = int(time.time())
    ls = [("d", "Belgeler", 0, now - 86400 * 2, "dir", "-"), ("d", "İndirilenler", 0, now - 3600, "dir", "-"), ("d", "Masaüstü", 0, now - 86400 * 9, "dir", "-"),
          ("d", "Resimler", 0, now - 86400 * 30, "dir", "-"), ("d", "projeler", 0, now - 86400 * 5, "dir", "l"),
          ("f", "Rapor-2026.pdf", 2411724, now - 7200, "doc", "-"), ("f", "tatil-0412.jpg", os.path.getsize(H + "/tatil-0412.jpg"), now - 86400 * 3, "image", "-"),
          ("f", "kurulum.sh", 1840, now - 86400 * 11, "code", "x"), ("f", "oyun-kaydi.mp4", 734003200, now - 86400, "video", "-"),
          ("f", "yedek.tar.zst", 2147483648, now - 86400 * 20, "archive", "-"), ("f", "playlist.flac", 31457280, now - 86400 * 40, "audio", "-"),
          ("f", "notlar.txt", 912, now - 600, "doc", "-")]
    lsrows = "".join("\t".join(str(x) for x in r) + "\n" for r in ls)
    FL = "/run/media/schway/FLASH/.Trash-1000/files/"
    tr = ("eski-rapor.docx\t%s/Belgeler/eski-rapor.docx\t2026-10-24T18:21:07\t48211\tf\tdoc\teski-rapor.docx\n"
          "%sdüğün-foto.jpg\t/run/media/schway/FLASH/dcim/düğün-foto.jpg\t2026-10-23T11:05:30\t3811204\tf\timage\tdüğün-foto.jpg\n"
          "screenshot (2).png\t%s/Resimler/screenshot.png\t2026-10-23T09:02:44\t812044\tf\timage\tscreenshot (2).png\n"
          "yeni klasör\t%s/Masaüstü/yeni klasör\t2026-10-20T21:40:10\t4096\td\tdir\tyeni klasör\n") % (H, FL, H, H)
    notes = "satır 1: toplantı notları\nsatır 2: bütçe onaylandı\n- Cuma günü sunum\n- Rapor-2026.pdf güncellenecek\n- yedekleme: yedek.tar.zst\n\n# yapılacaklar\n[ ] fatura\n[x] kargo\n"
    prev_txt = "kind=text\nsize=912\nmodified=%d\ncins=doc\ndetail=9 satır\n@@\n%s" % (now - 600, notes)
    prev_img = "kind=image\nsize=%d\nmodified=%d\ncins=image\ndetail=resim\n@@\n" % (os.path.getsize(H + "/tatil-0412.jpg"), now - 86400 * 3)
    mp = {"schway-files places": places, "schway-files list " + H: lsrows, "schway-files trashlist": tr,
          "schway-files preview " + H + "/notlar.txt": prev_txt, "schway-files preview " + H + "/tatil-0412.jpg": prev_img}
    menu_items = [{"id": "open", "label": "Varsayılan uygulamayla aç"}, {"sep": True}, {"id": "cut", "label": "Kes"}, {"id": "copy", "label": "Kopyala"},
                  {"id": "paste", "label": "Yapıştır", "dim": True}, {"id": "rename", "label": "Yeniden adlandır"}, {"sep": True},
                  {"id": "trash", "label": "Çöpe at", "danger": True}, {"id": "delete", "label": "Kalıcı sil…", "danger": True}, {"sep": True}, {"id": "preview", "label": "Önizleme"}]
    return [("home", mp, {"sel": {"Rapor-2026.pdf": True, "notlar.txt": True}, "clip": {"mode": "cut", "paths": [H + "/oyun-kaydi.mp4"]}, "anchorIdx": 5}, [0]),
            ("trash", mp, {"startPath": "trash://", "sel": {"eski-rapor.docx": True}}, [0]),
            ("dialog", mp, {"sel": {"Rapor-2026.pdf": True}, "dlg": {"kind": "name", "title": "Yeniden adlandır", "value": "Rapor-2026.pdf"}}, [0]),
            ("preview_text", mp, {"previewOn": True, "sel": {"notlar.txt": True}}, [0]),
            ("preview_image", mp, {"previewOn": True, "sel": {"tatil-0412.jpg": True}}, [0]),
            ("menu", mp, {"sel": {"Rapor-2026.pdf": True}, "menu": {"x": 330, "y": 330, "items": menu_items}}, [0])]

jobs = {"Tasks": tasks, "Files": files}
os.makedirs(out, exist_ok=True)
rc = 0
for app in apps:
    if app not in jobs:
        continue
    for name, mp, props, pages in jobs[app]():
        sub = os.path.join(out, app.lower() + ("_" + name if name else ""))
        env = dict(os.environ, SHOT_MAP=json.dumps(mp, ensure_ascii=False), SHOT_PROPS=json.dumps(props, ensure_ascii=False))
        r = subprocess.run([sys.executable, os.path.join(here, "run_shots.py"), qs, "ok", ",".join(map(str, pages)), sub, app], env=env, capture_output=True, text=True, timeout=180)
        print(r.stdout.strip()); print(r.stderr.strip()[-600:])
        rc |= r.returncode
sys.exit(rc)
