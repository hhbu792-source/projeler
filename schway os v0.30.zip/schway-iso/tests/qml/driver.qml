import QtQuick
import Quickshell
import Quickshell.Io

// Mağaza arayüzünü adım adım sürer ve beklentileri denetler. Çıktı: "TEST ok/HATA ..." satırları.
Item {
    id: d
    property int fails: 0
    property int idx: 0
    function check(name, cond) { console.log((cond ? "TEST ok    " : "TEST HATA  ") + name); if (!cond) fails++ }
    function find(item, name) {
        if (!item) return null
        if (item.objectName === name) return item
        const kids = item.children || []
        for (let i = 0; i < kids.length; i++) { const r = find(kids[i], name); if (r) return r }
        return null
    }
    readonly property var w: Registry.win
    function list() { return find(w.contentItem, "storeList") }
    function box() { return find(w.contentItem, "storeSearch") }

    // Her adım: [bekleme (ms), işlev]
    readonly property var steps: [
        [300, function() {
            d.check("öne çıkanlar yüklendi (3)", d.w.featuredList.length === 3)
            d.check("kurulu uygulamalar yüklendi (1)", d.w.installedList.length === 1)
            d.check("kurulu eşlemesi VLC'yi biliyor", d.w.installedMap["org.videolan.VLC"] === true)
            d.check("güncelleme listesi (1)", d.w.updatesList.length === 1)
            d.check("Keşfet sekmesi öne çıkanları gösteriyor", d.w.shown.length === 3 && d.w.heading === "Öne çıkanlar")
            d.check("liste 3 satır çiziyor", d.list().count === 3)
            d.w.pickTab(1)
        }],
        [100, function() { d.check("Kurulu sekmesi 1 satır", d.w.shown.length === 1 && d.list().count === 1); d.w.pickTab(2) }],
        [100, function() { d.check("Güncellemeler sekmesi 1 satır", d.w.shown.length === 1); d.w.pickTab(0); d.box().text = "foo" }],
        [900, function() {
            d.check("arama sonuçları geldi (2)", d.w.searchList.length === 2 && d.w.shown.length === 2)
            d.check("başlık: Arama sonuçları", d.w.heading === "Arama sonuçları")
            d.check("arama komutu doğru", Fake.log.indexOf("schway-store search foo") >= 0)
            d.w.act("install", "com.example.Foo")
        }],
        [150, function() {
            d.check("kurulum sürerken meşgul", d.w.busy && d.w.busyId === "com.example.Foo")
            d.w.act("remove", "x.y")
        }],
        [100, function() { d.check("meşgulken ikinci işlem reddedildi", Fake.log.indexOf("schway-store remove x.y") < 0) }],
        [700, function() {
            d.check("kurulum komutu çalıştı", Fake.log.indexOf("schway-store install com.example.Foo") >= 0)
            d.check("işlem bitince meşgul değil", !d.w.busy)
            d.check("başarı iletisi", d.w.note.indexOf("Kuruldu") === 0)
            Fake.failInstall = true
            d.w.act("install", "com.example.Bar")
        }],
        [900, function() {
            d.check("hatada iletide uyarı", d.w.note.indexOf("tamamlanamadı") >= 0)
            d.check("hatadan sonra tekrar denenebilir", !d.w.busy)
            Fake.failInstall = false
            d.w.pickTab(2)
            d.w.act("update", "")
        }],
        [150, function() { d.check("güncellerken düğme meşgul", d.w.busyWhat === "update") }],
        [800, function() {
            d.check("tümünü güncelle komutu", Fake.log.indexOf("schway-store update") >= 0)
            d.check("güncelleme iletisi", d.w.note.indexOf("Güncellendi") === 0)
            d.w.pickTab(0)
            d.box().text = "yokyok"
        }],
        [900, function() {
            d.check("sonuç yoksa boş liste", d.w.shown.length === 0)
            console.log("RESULT fails=" + d.fails)
            Qt.quit()
        }]
    ]
    Timer {
        id: tick
        interval: 300
        running: Registry.win !== null
        onTriggered: {
            if (d.idx >= d.steps.length) return
            const s = d.steps[d.idx++]
            s[1]()
            if (d.idx < d.steps.length) { tick.interval = d.steps[d.idx][0]; tick.restart() }
        }
    }
}
