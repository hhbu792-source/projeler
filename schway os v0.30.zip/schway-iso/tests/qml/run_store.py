"""Mağaza QML'ini sahte Quickshell katmanıyla çalıştırır. Kullanım: python3 run_store.py <store-klasörü> <Theme.qml>"""
import os, sys, shutil, tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import QUrl, QTimer, qInstallMessageHandler
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine

here = os.path.dirname(os.path.abspath(__file__))
store, theme = sys.argv[1], sys.argv[2]
work = tempfile.mkdtemp()
for f in ("shell.qml", "qmldir"):
    shutil.copy(os.path.join(store, f), work)
shutil.copy(theme, os.path.join(work, "Theme.qml"))

lines, warns = [], []
def handler(mode, ctx, msg):
    if msg.startswith("TEST ") or msg.startswith("RESULT"):
        lines.append(msg); print(msg)
    else:
        warns.append(msg); print("QML:", msg)
qInstallMessageHandler(handler)

app = QGuiApplication(sys.argv)
e = QQmlApplicationEngine()
e.addImportPath(os.path.join(here, "stubs"))
e.load(QUrl.fromLocalFile(os.path.join(work, "shell.qml")))
if not e.rootObjects():
    print("HATA: shell.qml yüklenemedi"); sys.exit(2)
e.load(QUrl.fromLocalFile(os.path.join(here, "driver.qml")))
QTimer.singleShot(15000, lambda: (print("HATA: zaman aşımı"), app.exit(3)))
app.aboutToQuit.connect(lambda: None)
rc = app.exec()
res = [l for l in lines if l.startswith("RESULT")]
bad = [l for l in lines if l.startswith("TEST HATA")]
errs = [w for w in warns if ("Error" in w or "error" in w or "is not defined" in w or "Unable to assign" in w or "ReferenceError" in w or "TypeError" in w)]
for w in errs: print("QML UYARISI:", w)
ok = bool(res) and not bad and not errs and res[0] == "RESULT fails=0"
print("SONUÇ:", "BAŞARILI" if ok else "BAŞARISIZ")
sys.exit(0 if ok else 1)
