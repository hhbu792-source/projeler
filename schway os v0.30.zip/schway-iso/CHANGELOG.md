# Değişiklik günlüğü

## 0.29 (master)
- Dosyalar: **disk çöpü** (USB'deki dosya diskin kendi `.Trash-UID` klasörüne gider, ev ve disk çöpleri birleşik listelenir, geri yükleme/boşaltma ikisinde de çalışır), **sağ tık menüsü**, **önizleme paneli** (`schway-files preview`: metin, resim, klasör, ikili/medya için bilgi), **sürükle-bırak** (taşı, Ctrl ile kopyala, Çöp'e bırak).
- Dosyalar: klasörler için varsayılan uygulama (`mimeapps.list`, `MimeType`, `%U`); açılamazsa (qs/tema yok ya da açılışta çökerse) otomatik Thunar'a geçiş; `file://` URI desteği.
- Dock: Thunar pini yerine Dosyalar; `org.quickshell` app_id'li bağımsız pencereler başlığa göre eşlenir (Dosyalar, Görev Yöneticisi, Mağaza kendi simgeleriyle görünür). Mantık test edilebilir `buildItems()` işlevine çıkarıldı.
- Düzeltmeler: sağ tık menüsü ve iletişim kutuları yarı saydamdı (opak yapıldı); sürükleme için fare düğmesi `pressedButtons`'tan okunur; çöp öğesi kimliği ile görünen ad ayrıldı.
- Testler: gerçek fare olaylarıyla (QTest) sürükle-bırak ve sağ tık, dock eşleştirme, önizleme, disk çöpü, `gui` geri dönüşü. 354 → 378 (sözleşme testi ayrıca kendi içinde 53 denetim yapar).

## 0.28 (master)
- Yeni: **Dosyalar** uygulaması (`schway-files`, Super+E; Thunar yedek olarak Super+Alt+E). Gezinme, arama, çoklu seçim, kes/kopyala/yapıştır, yeniden adlandır, çöp kutusu (FreeDesktop), korunan yollar, çakışmada `ad (2)`.
- Yeni: **Görev Yöneticisi** (`schway-tasks`, Ctrl+Shift+Esc). İşlemler (anlık işlemci), Performans grafikleri, Hizmetler (aç/kapa, bellek); zorunlu hizmetler ve sistem işlemleri korunur.
- Yeni: **hizmet politikası** (`services.policy`) ve derleme denetimi. Güvenlik: releng'in açtığı `sshd` + `PermitRootLogin yes`/parola girişi kaldırıldı (kurulu sisteme kopyalanıyordu), `ModemManager`, `pcscd`, `systemd-time-wait-sync` ve `cloud-init` paketi çıkarıldı, `sshd` için `PermitRootLogin no` varsayılanı eklendi. Doğrulama gerçek archiso `releng` profil dosyalarıyla yapıldı.
- Geliştirici: `tests/qml/shots/contract_apps.py` arayüzün ürettiği komutları gerçek arka uçta çalıştırarak arayüz-arka uç uyumunu denetler; `render_apps.py` iki yeni uygulamayı çizer.
- Testler: 285 → 354.

## 0.27 (master)
- Güvenlik uygulaması (Super+S) arayüzü: ana sayfa 4 → 8 kart (fidye, web, çalıştırma öncesi, karantina eklendi; renk/durum canlı); uyarı bandının düğmesi duruma göre değişir ("Tehditleri gör" / "Geçmişi aç" / "Hızlı tara"); ayarlar sayfası "Gerçek zamanlı ve otomatik / Ek korumalar / Tarama ve bildirimler" bölümlerine ayrıldı, satırlarda canlı durum gösterilir (ör. "3.412 alan adı engelli").
- Hata düzeltmeleri: geçmişte `guard`, `ransom`, `execblock` kayıtları ham İngilizce kelime olarak görünüyordu (Türkçeleştirildi, ciddiyete göre renklenir); tarama kaydındaki `quick:/full:` ön eki çevrildi; kenar çubuğu ve kartlarda simge genişliği yüzünden yazılar birkaç piksel kayıyordu (simge alanı sabitlendi); `schway-defender status --human` ve `history --human` çıktılarında "off", "weekly", "execblock" gibi ham değerler Türkçeleştirildi, yeni korumalar eklendi.
- Geliştirici aracı: `tests/qml/shots/run_shots.py` arayüzü gerçek Quickshell olmadan çevrimdışı çizip PNG kaydeder (sahte veri gerçek `schway-defender status` çıktısından gelir). Testler QML hatası olmadan render edildiğini denetler.
- Testler: 275 → 285.

## 0.26 (master)
- Yeni: **web koruması** (`schway-defender web ...`): URLhaus zararlı alan adı listesi `/etc/hosts` yönetilen bloğuna yazılır; elle engelle/izin listesi, günlük güncelleme, atomik yazım, boş/bozuk listede eskiyi koruma.
- Yeni: **çalıştırma öncesi engelleme** (`schway-execguard`, fanotify, hizmet `schway-defender-exec`, `sudo schway-defender prevent on|off`). Fail-open tasarım; varsayılan kapalı. `python` paketi eklendi.
- Yeni: YARA kuralları 1 → 8 (ters kabuk, PHP webshell, madenci x2, fidye notu, cron indirici, PowerShell indirici, mimikatz); zararlı ve zararsız örneklerle ClamAV motorunda test edildi.
- Yeni: `sudo schway-defender ransom|web|prevent on|off`; Ayarlar ve Güvenlik uygulamasında web ve engelleme anahtarları; sudoers'a yalnızca `web update` parolasız eklendi.
- Testler: 240 → 275 (gerçek fanotify ile engelleme, önbellek, zaman aşımı, SIGKILL'de serbest bırakma, hosts yönetimi, YARA).

## 0.25 (master)
- Yeni: **fidye yazılımı koruması** (Schway Güvenlik, erken uyarı). Belgeler/Masaüstü/Resimler'de gizli tuzak dosya, toplu dosya değişikliği, şüpheli uzantı ve fidye notu adı izlenir (`inotifywait`); uyarı bildirim + geçmiş kaydı + sağlık durumunda "Dikkat gerekiyor". Ayrı hizmet `schway-defender-ransom.service` (RAM şartı yok, 64 MB sınır). Ayarlar'da ve Güvenlik uygulamasında açma/kapama, `schway-defender ransom status|plant|check`. Engellemez, yalnızca uyarır.
- Testler: 227 → 240 kontrol (gerçek `inotifywait` ile tuzak değişimi/silinmesi, toplu değişiklik, uzantı, not ve yanlış alarm yok denetimi).

## 0.24 (master)
- Yeni: **kurulumda kullanıcı adı, parola ve bilgisayar adı seçimi** (Calamares `users` modülü). Eskiden hesap her zaman parolasız "schway" adıyla açılırdı. Artık seçilen kullanıcı kurulur, kurulum bitince sudo parolası hemen devreye girer (`schway-harden apply`) ve ilk girişteki parola sorusu gerekmez. Canlı ISO'daki otomatik giriş kurulu sistemde kaldırılır; isteyen Ayarlar > Kullanıcılar'dan **Otomatik giriş**'i açabilir. Sabit `schway` varsayımı kalktı: `schway-user.sh` yardımcısı kullanıcıyı bulur (update, drivers, sets, harden, priv, firstboot), `clamd.conf` izlenen yolları gerçek ev dizinine çevrilir, Qt ayar yolları oturum açılışında düzeltilir.
- Yeni: **Mağaza** (`schway-store`, uygulama menüsünde "Mağaza"): Flathub'da arama, öne çıkanlar, kurma/kaldırma, güncellemeler. Flatpak `--user` ile kurar, yönetici izni gerekmez. Arayüz ayrı bir Quickshell sürecidir (`qs -p`), hatası masaüstü kabuğunu etkilemez. Uygulama kimliği sıkı doğrulanır.
- Yeni: **Güvenlik duvarı varsayılan açık** (kurulu sistemde ilk açılışta bir kez: gelen bağlantılar reddedilir, giden serbest; kullanıcı kapatırsa tekrar açılmaz). Sunucu seti başlatılınca ssh 22 ve web 80/443 otomatik açılır, durdurulunca kapanır.
- Yeni: **İndirme koruması** (Güvenlik > ayarlar ve Ayarlar > Güvenlik): İndirilenler'e inen riskli dosyalar (exe, sh, zip, pdf, AppImage vb.) taranana kadar erişime kapatılır (chmod 000); temizse eski izni geri verilir, tehditse karantinaya alınır (özgün izin kaydedilir). Tarama yapılamazsa dosya açılır. 100 MB üstü, `.part`/`.crdownload`, dışlananlar ve sembolik bağlar bekletilmez. Çökme sonrası kilitli kalanlar kurtarılır. Gerçek zamanlı korumayla birlikte çalışır (`inotify-tools` eklendi).
- Testler: 176 kontrolden **227**'ye. Kurulum/kullanıcı, harden apply, autologin (canlı ISO dosyasıyla birebir karşılaştırma), güvenlik duvarı, indirme koruması, clamd yolları, Mağaza arka ucu ve Mağaza arayüzü (PySide6 ile sahte Quickshell üzerinde çalıştırılır).

## 0.23.1 (master, hata düzeltmeleri)
- Düzeltme: ISO varsayılan vurgu rengi **mor** derleniyordu (`build-iso.sh` `accent violet`), oysa arayüz 0.21'den beri mavi (`#5980FA`) tasarlandı. Artık `accent blue`.
- Düzeltme: `schway-settings`, `schway-sets` ve `schway-disks` ISO'nun `file_permissions` listesinde yoktu; çalıştırma izni kaynak dosyadaki bite kalıyordu (zip/Windows'tan GitHub'a yüklenince kaybolur; Ayarlar uygulaması ve paket setleri çalışmazdı). İzin listesi artık `usr/local/bin` altındaki her dosyadan **otomatik üretiliyor** (yeni `schway-lock` dahil), böylece yeni betik unutulmaz.
- Düzeltme: `schway-sets` ve `schway-update --configs` `pacman -Sy` ile paket kuruyordu. Arch'ta kısmi güncelleme desteklenmez ve sistemi bozabilir; `-Syu` yapıldı.
- Testler: bu üç hata için regresyon testleri eklendi (toplam 176 kontrol).

## 0.23 (master)
- Yeni: **kilit ekranı** (hyprlock, Schway temalı). Super+L, Ayarlar > Güç ve Pil'de "Şimdi kilitle" ve "Ekranı otomatik kilitle" (boşta süresi), uykuya girmeden önce kilitleme. `schway-lock` hesabın parolası yoksa (canlı ISO ya da parola belirlenmemiş sistem) kilitlemez; kullanıcı kendi oturumundan dışarıda kalmaz.
- Yeni: **şifreli disk (LUKS)** seçeneği kurulum sihirbazında açıldı (`cryptsetup` eklendi). Kök bölüm LUKS ise `encrypt` kancası initramfs'a, yoksa sigorta olarak, eklenir ve `/boot` ayrı değilse GRUB `GRUB_ENABLE_CRYPTODISK=y` alır. Betikler sahte dosyalarla sınandı; gerçek donanımda denenmedi.
- Güvenlik: **Geri Bildirim Merkezi** sertleştirildi. Yönetim ucu artık IP listesine ek olarak yönetici anahtarı ister (zamanlama saldırısına dayanıklı karşılaştırma; ilk açılışta `data/admin-token` üretilir), 10 hatalı denemede 10 dk engel, CSP + `X-Frame-Options` + `nosniff` başlıkları, CORS yalnızca gönderme ucunda, varsayılan olarak yalnızca `127.0.0.1` dinler, rapor sayısı sınırı (`maxReports`), HSTS (HTTPS vekil arkasında). `nginx.conf.example` (HTTPS) ve sertleştirilmiş `schway-feedback-center.service.example` eklendi.
- Yeni: **otomatik testler** (`bash tests/run.sh`, GitHub Actions'ta `Test` iş akışı): bash söz dizimi ve shellcheck, JSON, paket listeleri, systemd birimleri, Hyprland kısayolu/IPC/komut tutarlılığı, QML parantez dengesi, .desktop ve README komut tablosu, Calamares kancaları, boşta kalma/kilit yapılandırma üretici, `schway-lock` kapısı ve geri bildirim sunucusu (Node testleri).
- Düzeltme: `schway-theme` içindeki tırnaksız komut yerine koymaları ve `build-extras.sh` shellcheck uyarıları giderildi.

## 0.22 (master)
- Yeni: **Schway Güvenlik** (virüs ve tehdit koruması, ClamAV). Uygulama (Super+S, dock, uygulama paneli): ana sayfa durum özeti, hızlı/tam/özel
  tarama + canlı ilerleme + iptal, etkin tehditler (karantina/sil/yoksay), karantina (geri yükle/sil), koruma geçmişi, koruma ayarları
  (gerçek zamanlı koruma, otomatik karantina, otomatik güncelleme, zamanlanmış tarama, dosya boyutu sınırı, dışlamalar) ve güvenlik duvarı.
- Ayarlar'a "Virüs ve Tehdit Koruması" sayfası, hızlı ayarlara "Güvenlik" karosu, üst şeride (yalnızca dikkat gerekince) durum simgesi.
- Thunar sağ tık menüsü ("Schway Güvenlik ile tara"), USB/harici disk otomatik taraması (udiskie kancası, ayarlanabilir), tehdit bildirimine tıklayınca uygulamanın açılması, virüs tanımlarının ISO'ya gömülmesi (`SCHWAY_NO_DEFS=1` ile atlanır).
- **Sudo parolası**: kurulu sistemde ilk girişte parola belirletilir ve sudo parola ister (`schway-harden`; Ayarlar'dan açılıp kapanır). Antivirüsü kapatmak/ayarlamak, güvenlik duvarı, saat dilimi vb. parola ister; tarama, tanım güncelleme ve oyun modu CPU geçişi parolasız kalır. Ayarlar/oyun modu/sunucu işlemleri artık serbest `sudo` yerine doğrulayan `schway-priv` yardımcısını kullanır; grafikte parola penceresi polkit ile gelir. Canlı ISO parolasız kalır.
- Kurulum sihirbazı (Calamares) canlı ISO'da karşılama menüsü kapanınca kendiliğinden başlar (`schway.noauto` açılış parametresiyle kapanır).
- Antivirüs: tehdit için "İzin ver" (içerik özetiyle), tarama saati seçimi, sistem dosyası bütünlüğü denetimi (`pacman -Qkk`), YARA kuralı dosyası ve ek imza kaynağı desteği (`schway-defender sources`).
- Parola: ilk girişte terminal yerine parola penceresi (`schway-harden on-stdin`); açılış parametresi `schway.direct` karşılama menüsünü atlayıp kurulumu doğrudan başlatır.
- Arka uç `schway-defender`; hizmetler: `schway-defender-rt` (gerçek zamanlı, clamd + clamonacc), `schway-defender-scan.timer`
  (zamanlanmış tarama), `clamav-freshclam` (tanım güncelleme; canlı ISO'da kapalı). `clamav` paketi eklendi. Gerçek zamanlı koruma ilk girişte
  yalnızca RAM >= 7 GB ise açılır (~1 GB RAM yer).

## 0.21 (master)
- Arayüz yenilemesi: üst şerit, dock, uygulama paneli, hızlı ayarlar, bildirimler, Ayarlar, Karşılama, masaüstü simgeleri,
  GTK/Qt/terminal/rofi/waybar temaları, GRUB, Plymouth, Calamares, tanıtım sitesi, Geri Bildirim uygulaması ve merkezi
  tek bir görsel dille yeniden tasarlandı: ink mavisi zemin, logodaki mavi vurgu (`#5980FA`, varsayılan artık mor değil),
  yazı tipi IBM Plex Sans (`ttf-ibm-plex` paketi eklendi), kademeli göstergeler (ses, parlaklık, bellek) imza öğe.
- Yeni: ses ve parlaklık göstergesi (OSD, `OSD.qml`). Ses değişince kendiliğinden, parlaklık tuşlarında
  `qs ipc call osd brightness` ile görünür (hyprland.conf güncellendi).
- Düzeltme: `State` tekilinin adı `Ui` oldu; `State` adı QtQuick'in kendi `State` türüyle çakışıp paneller açılmıyordu.
- Düzeltme: `font.pixelSize` için kesirli değerler kullanılmıyor (QML tamsayı ister).
- Ayarlar: satırlar tek yüzeyde gruplanır, bölüm başlıkları büyük harfsiz. Hızlı ayarlar: bellek göstergesi, durum yazıları,
  Çıkış/Yeniden başlat/Kapat için iki adımlı onay. Karşılama: sol tarafta adım listesi, kısayollar tuş görünümünde.
  Üst şeritte çalışma alanı göstergesi, dock'ta yalnızca uygulamalar (durum simgeleri üst şeritte).
- Terminalde ANSI macenta artık vurgu rengine bağlı değil (vurgu mavi olunca maviyle karışıyordu). rofi açık mordan koyuya döndü.

## 0.20 (master)
- Geri Bildirim uygulaması sisteme bütünleşti: Super+F1 kısayolu, dock'a sabit simge, uygulama panelinde giriş. Canlı ISO'dan
  Calamares ile kurulan sisteme de aynen geçer (unpackfs).
- Geri Bildirim uygulaması Electron'dan Tauri 2'ye taşındı (`feedback-app/`, paket: `repo/schway-feedback`). `electron` paketi kaldırıldı;
  `build-extras.sh` uygulamayı derleyip yerel depoya koyar.
- Qt5 uygulamaları da koyu temayı alıyor: `qt5ct` eklendi, `QT_QPA_PLATFORMTHEME=qt6ct:qt5ct` (Qt6 uygulamaları qt6ct'yi, Qt5
  uygulamaları qt5ct'yi yükler). `schway-theme accent` her iki paleti de günceller.
- Geri Bildirim uygulaması sisteme gömüldü (`schway-feedback`, uygulama panelinde "Geri Bildirim"): Şikayet/Bug, Öneri, Eleştiri
  gönderir; sürüm ve sistem bilgisi otomatik eklenir. Merkez sunucu adresi `/etc/schway/feedback.json` içinde. 
- Karşılama (canlı ISO): "Oyun ve Windows uyumu" seti (Wine, Steam, Lutris, MangoHud) artık hep seçili ve kilitli; Calamares
  ve ilk giriş bunu her kurulumda uygular.
- Yeni Ayarlar uygulaması (Super+I, uygulama panelinde "Ayarlar"): solda sabit kategori menüsü, 16 kategori + Schway Glass /
  Themes / Control / Update. Her ayar gerçek bir komuta bağlı (`schway-settings`: hyprctl, nmcli, wpctl/pactl, timedatectl,
  ufw, hypridle...); donanım/özellik yoksa (pil, kapak, dokunmatik yüzey, Bluetooth...) ilgili satır hiç gösterilmez. Yönetici
  izni isteyen işlemler ayrı onay penceresi açar. Kişisel Hyprland ayarları `~/.config/hypr/user.conf` içinde kalıcıdır.
- Paketler: jq, hyprsunset, hypridle, power-profiles-daemon.

## 0.19 (master)
- Karşılama ekranı (canlı ISO): yeni "Paket setleri" sayfası (Oyun ve Windows uyumu, Ofis, Sunucu ve geliştirici, Ek uygulamalar) ve
  disk listesi gösteren "Disk ve kurulum" sayfası (diskler, bölümler, Windows olabilecek NTFS bölümleri, canlı USB uyarısı;
  GParted ve Kurulumu başlat düğmeleri). Seçimler `install-choices.conf` ile yeni sisteme aktarılır, ilk girişte kurulur
  (`schway-firstlogin sets|all`).
- Yeni `schway-sets list|install <set>...|all` (kurulu sistemde karşılamada "Paket setleri" sayfası da var) ve `schway-disks`.

## 0.18 (master)
- Plymouth açılış animasyonu: koyu zemin, logo, ilerleme çubuğu (kurulu sistemde; canlı ISO'da yok). Kurulum sırasında
  `plymouth` kancası mkinitcpio'ya eklenir, çekirdeğe `quiet splash` verilir.
- Anlık görüntüden önyükleme: grub-btrfs + `grub-btrfs-overlayfs` kancası. `@snapshots` kurulu sistemde `/.snapshots`
  olarak bağlanır (fstab, `nofail`); `schway-snapshot create/delete` ve her pacman işlemi sonrası GRUB menüsü yenilenir
  (`schway-snapshot grub-refresh`). Sistem açılmasa bile GRUB'dan anlık görüntü seçilip açılabilir.
- Bibata imleç teması (AUR, `build-extras.sh` ile yerel depoya derlenir). Derlenemezse otomatik Adwaita'ya dönülür.
- Canlı ISO'da açılışta karşılama ekranı otomatik açılır: gelişmiş oyun modu ve zapret tercihleri (aç/kapat), diski GParted ile
  bölümleme ve kurulumu başlatma ya da canlı denemeye devam etme. Tercihler Calamares ile yeni sisteme aktarılır
  (`/var/lib/schway/install-choices.conf`) ve ilk girişte uygulanır (`schway-firstlogin`). Kurulu sistemde karşılamaya "Oyun modu" sayfası eklendi.
- Gelişmiş oyun modu: `schway-game advanced on|off|status` (oyun modundayken CPU performance, split-lock yavaşlatması kapalı).
- Qt5 uygulamalarının Wayland'da açılması için `qt5-wayland` eklendi (QT_QPA_PLATFORM=wayland ile Qt5 uygulamaları açılmıyordu).

## 0.17 (master)
- Hata düzeltmeleri: rofi-wayland -> rofi (paket birleşti), Hyprland start-hyprland ile başlatılır (yoksa Hyprland),
  depoda bulunmayan paket artık tüm ISO derlemesini bozmaz (atlanır ve UYARI yazılır).
- zapret: Türksat Kablonet için hazır ayar (fake + TTL 4/3/5/6/2) sırayla denenir, her denemede Discord erişimi
  test edilir; olmazsa resmi kuruluma (blockcheck) düşer. DNS 1.1.1.1/1.0.0.1/8.8.8.8 yapılır.
- Derleme betiği sahte Arch profiline karşı kuru çalıştırmayla test edildi.

## 0.16
- schway-apps (Spotify, Prism/Minecraft, Bottles, ProtonUp-Qt - Flatpak), schway-winfonts, schway-ram.
- Karşılama: Görünüm ve Ek uygulamalar sayfaları. Paket deposu GitHub Pages'e yayınlanır.

## 0.15
- GitHub Actions ile otomatik ISO derlemesi (Arch konteyneri).

## 0.14
- Türkçe yerelleştirme (dil, klavye, İstanbul, timesyncd, Firefox TR), GRUB teması.

## 0.13
- GTK/Qt/foot/imleç teması, schway-theme ile vurgu rengi.

## 0.12 ve öncesi
- Schway logosu, koyu Quickshell arayüzü (üst şerit, dock, masaüstü simgeleri, uygulama paneli,
  bildirimler, hızlı ayarlar), Calamares kurulum aracı, btrfs anlık görüntü/geri alma, güncelleme sistemi,
  karşılama ekranı, Zen kernel, zram, earlyoom, otomatik oyun modu, sürücü tespiti, Windows uyumu.
