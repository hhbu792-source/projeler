#!/bin/bash
# Kendi paket depon: schway-config paketini derler ve repo klasörü üretir.
# NORMAL KULLANICIYLA çalıştır:  bash repo/build-repo.sh
set -e
[ "$EUID" -ne 0 ] || { echo "root ile değil, normal kullanıcıyla çalıştır"; exit 1; }
HERE=$(cd "$(dirname "$0")/.." && pwd)
PK="$HERE/repo/schway-config"
OUT="$HERE/repo/out/x86_64"

rm -rf "$PK/files" "$PK"/*.pkg.tar.* "$PK/pkg" "$PK/src"
mkdir -p "$PK/files/skel" "$PK/files/bin" "$OUT"
cp -a "$HERE/airootfs/etc/skel/.config" "$PK/files/skel/.config"
rm -f "$PK/files/skel/.config/hypr/nvidia.conf"      # NVIDIA ayarını güncelleme ezmesin
for f in schway-server schway-dpi-setup schway-game schway-autogame schway-drivers \
         schway-snapshot schway-update schway-apply-config schway-theme schway-keyboard schway-apps schway-winfonts schway-ram schway-choices schway-firstlogin; do
    cp "$HERE/airootfs/usr/local/bin/$f" "$PK/files/bin/"
done

sed -i "s/^pkgver=.*/pkgver=$(cat "$HERE/VERSION")/; s/^pkgrel=.*/pkgrel=$(date +%Y%m%d%H%M)/" "$PK/PKGBUILD"
(cd "$PK" && makepkg -f --noconfirm)
cp "$PK"/*.pkg.tar.* "$OUT/"
repo-add "$OUT/schway.db.tar.gz" "$OUT"/*.pkg.tar.*

echo
echo "Depo hazır: $OUT"
echo "Bu klasörü bir web sunucusuna yükle (GitHub Pages, kendi sunucun vb.)."
echo "Kurulu sistemde bağla:  schway-update set-repo https://SENIN-ADRESIN/schway/\$arch"
echo "Güncelleme:              schway-update --configs"
